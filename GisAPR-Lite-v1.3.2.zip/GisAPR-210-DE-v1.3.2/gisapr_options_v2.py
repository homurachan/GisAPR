"""Shared optional controls; existing optimization commands remain valid."""


def nonnegative_mb(value):
    import argparse
    import math
    value = float(value)
    if not math.isfinite(value) or value < 0:
        raise argparse.ArgumentTypeError('cache size must be finite and >= 0 MiB')
    return value


def add_split_gpu_options(parser):
    parser.add_argument('--split_gpu_mode', choices=('consecutive', 'pool'), default='consecutive',
                        help='With --doSplitDiffGpu: consecutive uses g, g+1, ... for each candidate starting GPU (default); pool restores opt2 shared-pool routing.')
    return parser


def add_projection_options(parser):
    parser.add_argument('--projection_mode', choices=('needed', 'full'), default='needed',
                        help='needed generates only the union of searched orientations, retaining original slice batches; full generates the full angle bank.')
    parser.add_argument('--fixed_density_cache_mb', type=nonnegative_mb, default=128.,
                        help='MiB for fixed density per worker (default: 128). Legacy: CPU ordered-prefix only; round batch: fixed body on the computing device. 0 disables.')
    return parser


def add_runtime_options(parser):
    from orientation_bank_v1 import positive_int
    add_split_gpu_options(parser)
    add_projection_options(parser)
    help_text = {
        '--gpuid': 'Colon-separated candidate starting CUDA IDs. With splitting, each g uses g, g+1, ... by default. Repeats create independent workers.',
        '--SplitParticles': 'Number of particle shards per candidate, balanced by particle count (default: 1). Merge before scoring.',
        '--doSplitDiffGpu': 'Distribute each candidate over SplitParticles consecutive GPUs from its assigned starting ID; use --split_gpu_mode pool for opt2 routing.',
    }
    for action in parser._actions:
        for option in action.option_strings:
            if option in help_text:
                action.help = help_text[option]
    parser.add_argument('--verbose', action='store_true', help='Show detailed per-candidate diagnostics.')
    parser.add_argument('--keep_intermediates', '--keep-intermediates', action='store_true',
                        help='Retain legacy per-pose directories/PDB/search files. Default: one compressed SQLite cache and reusable scratch files.')
    parser.add_argument('--write_model_mrc', action='store_true',
                        help='Use the original disk MRC path and retain model MRC files; implies legacy per-pose directories. Default: in-memory tensor path.')
    parser.add_argument('--no_result_cache', action='store_true',
                        help='Disable reuse of completed scores for this exact pose and orientation bank.')
    parser.add_argument('--ctf_cache_mb', type=nonnegative_mb, default=256.,
                        help='Maximum host RAM MiB for CTF batches per worker; 0 disables (default: 256).')
    parser.add_argument('--search_cache_mb', type=nonnegative_mb, default=64.,
                        help='Maximum host RAM MiB for STAR/local-map metadata per worker; 0 disables (default: 64).')
    parser.add_argument('--evaluation_mode', choices=('auto', 'batch', 'legacy'), default='auto',
                        help='auto: round batching for <=128 particles on CUDA with compact output and SplitParticles=1; batch: force this path (also on CPU); legacy: v1.2 evaluation.')
    parser.add_argument('--batch_candidates', type=positive_int, default=16,
                        help='Maximum candidate templates retained together per device (default: 16). 3-D FFTs run one model at a time.')
    parser.add_argument('--batch_template_mb', type=nonnegative_mb, default=256.,
                        help='Target MiB for the combined candidate template bank; at least one model must fit. 0 processes one candidate at a time.')
    parser.add_argument('--batch_particle_cache_mb', type=nonnegative_mb, default=256.,
                        help='Device memory MiB for reusable particle psi/CTF/Fourier data; 0 disables retention between batches.')
    parser.add_argument('--batch_volume_cache_mb', type=nonnegative_mb, default=1024.,
                        help='Device memory MiB for adaptive screen-to-full density reuse; not retained by PSO/DE.')
    parser.add_argument('--batch_density_mode', choices=('fixed', 'full'), default='fixed',
                        help='fixed reuses the unchanged body density; full rebuilds all atoms. Both retain PDB 8.3 coordinate rounding. Use density_backend torch for reference deposition.')
    parser.add_argument('--density_backend', choices=('auto', 'torch', 'cuda'), default='auto',
                        help='Round batch density: auto uses fused CUDA when NVRTC is available, otherwise PyTorch; cuda requires the fused backend; torch uses reference deposition. Legacy evaluation is unchanged.')
    parser.add_argument('--batch_projection_mode', choices=('batched', 'legacy'), default='batched',
                        help='batched samples only needed directions and batches whitening/FFT; legacy retains v1.2 projection arithmetic.')
    parser.add_argument('--batch_grid_cache_mb', type=nonnegative_mb, default=1024.,
                        help='MiB per device for reusable projection grids/masks; 0 disables (default: 1024).')
    parser.add_argument('--batch_filter_cache_mb', type=nonnegative_mb, default=128.,
                        help='MiB per device for the central sinc-squared filter; 0 disables (default: 128; box256 needs 64).')
    parser.add_argument('--batch_coordinate_prefetch', choices=('on', 'off'), default='on',
                        help='Prepare one next candidate on a CPU thread during CUDA projection (default: on).')
    return parser
