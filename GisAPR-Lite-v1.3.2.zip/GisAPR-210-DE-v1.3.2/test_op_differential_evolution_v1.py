#!/usr/bin/env python3
"""Six-parameter DE with one initial local search and a shared fixed Top-K bank."""
import ast
import json
import os
from pathlib import Path
import sys
import time

import numpy as np

import func_v2 as gisapr_func
from func_v2 import GisAPRObjective
from gisapr_de import DEOptions, differential_evolution
from gisapr_runtime_v2 import SEARCH_SCRIPT, metrics_snapshot, resolve_script, worker_slots
from orientation_bank_v1 import atomic_json, check_bank
from test_op_adaptive_pattern_search_v2 import (
    create_parser as pattern_parser, parse_bounds, parse_vector, file_digest, run_signature)

VERSION = '1.3.2'
SCHEMA = 'GisAPR_DE_rand1bin_v2'


def create_parser():
    parser = pattern_parser()
    parser.description = __doc__
    parser.set_defaults(Pattern_max_iter=300)
    g = parser.add_argument_group('Differential evolution')
    g.add_argument('--DE_population', type=int, default=128,
                   help='Actual requested population, not a dimension multiplier. Sobol rounds up to a power of two.')
    g.add_argument('--DE_mutation', default='(0.5,1.0)', help='Fixed F or (F_min,F_max), dithered once per generation.')
    g.add_argument('--DE_crossover', type=float, default=.7)
    g.add_argument('--DE_init', choices=('sobol', 'latinhypercube', 'random'), default='sobol')
    g.add_argument('--DE_tol', type=float, default=0., help='Optional relative energy-spread tolerance; 0 disables together with DE_atol=0.')
    g.add_argument('--DE_atol', type=float, default=0.)
    g.add_argument('--DE_orientation_mode', choices=('fixed', 'full'), default='fixed',
                   help='fixed (default): calibrate once at the initial pose, then score all candidates with the same Top-K directions. full: v1.1.0 full local search per candidate.')
    # Aliases share destinations: existing Pattern/Adaptive command options work.
    import argparse
    for flag, dest, kind, help_text in [
        ('DE_generations', 'Pattern_max_iter', int, 'Alias for Pattern_max_iter; number of complete generations (default 300).'),
        ('DE_seed', 'Adaptive_seed', int, 'Alias for Adaptive_seed.'),
        ('DE_max_evals', 'Adaptive_max_evals', int, 'Alias for Adaptive_max_evals; 0 is unlimited.'),
        ('DE_continue_file', 'Pattern_continue_file', str, 'Path to this DE run latest.npz.'),
        ('DE_continue_more_generations', 'Pattern_continue_more_rounds', int, 'Additional generations when continuing (default 20).')]:
        g.add_argument('--'+flag, dest=dest, type=kind, default=argparse.SUPPRESS, help=help_text)
    g.add_argument('--DE_continue', dest='Pattern_continue', action='store_true', default=argparse.SUPPRESS)
    g.add_argument('--DE_keep_checkpoints', dest='Adaptive_keep_checkpoints', action='store_true', default=argparse.SUPPRESS)
    return parser


def save_checkpoint(path, state, signature):
    path = Path(path)
    temporary = path.with_name(path.name + '.tmp')
    payload = json.dumps(dict(schema=SCHEMA, version=VERSION, signature=signature, state=state), allow_nan=False)
    with temporary.open('wb') as handle:
        np.savez_compressed(handle, state_json=np.array(payload))
    os.replace(temporary, path)


def load_checkpoint(path, signature):
    with np.load(path, allow_pickle=False) as data:
        payload = json.loads(str(data['state_json'].item()))
    if payload.get('schema') != SCHEMA or payload.get('version') != VERSION:
        raise ValueError('Use a DE v1.2.0 checkpoint; older DE/Pattern checkpoints cannot resume this scoring mode')
    if payload['signature'] != signature:
        raise ValueError('Checkpoint inputs/code/settings/output root differ. Reuse the original command; only budgets/workers/logging may change.')
    return payload['state']


def validate_fixed_bank(bank, objective):
    if bank is None:
        raise ValueError('Initial local search produced no valid orientation bank (geometry rejection or invalid score). Choose a valid Pattern_initial or review the geometry settings.')
    check_bank(bank, objective.context)
    expected = {str(i) for group in objective.groups for i in group}
    if set(bank['rows']) != expected or any(not row.get('directions') for row in bank['rows'].values()):
        raise ValueError('Initial orientation bank must contain at least one valid direction for every particle. Check the angle STAR and local search range.')


def calibrate_once(objective, reference, slot):
    """Called synchronously before submitting any DE population jobs."""
    result = objective.evaluate(reference, slot, None)
    validate_fixed_bank(result.bank, objective)
    if result.bank['pose'] != list(map(float, reference)):
        raise ValueError('Calibration bank belongs to another reference pose')
    calibration = dict(pose=list(map(float, reference)), full_objective=result.value,
                       calls=int(not result.cached), requested=1)
    return dict(stage='calibrated', fixed_orientations=result.bank, calibration=calibration,
                nit=0, nfev=calibration['calls'], requested=1)


def main(argv=None):
    parser = create_parser()
    args = parser.parse_args(argv)
    args.optimizer = 'DE'
    try:
        if args.Pattern_dimensions != 6:
            raise ValueError('GisAPR DE requires Pattern_dimensions=6')
        lb, ub = parse_bounds(args.Pattern_Bounds, 6)
        mutation = ast.literal_eval(args.DE_mutation)
        if isinstance(mutation, (int, float)):
            mutation = (float(mutation), float(mutation))
        opt = DEOptions(population=args.DE_population, generations=args.Pattern_max_iter,
                        mutation=tuple(mutation), crossover=args.DE_crossover, init=args.DE_init,
                        seed=args.Adaptive_seed, max_workers=args.max_workers,
                        max_evals=args.Adaptive_max_evals, tol=args.DE_tol, atol=args.DE_atol)
        opt.validate()
        if args.Pattern_continue_more_rounds < 0:
            raise ValueError('Additional generations must be nonnegative')
        x0 = parse_vector(args.Pattern_initial, 6, 'Pattern_initial') if args.Pattern_given_initial else None
        if x0 is None and args.DE_orientation_mode == 'fixed':
            # The untransformed input model is the natural calibration reference.
            # If bounds exclude zero, use the closest in-bounds reference instead.
            x0 = np.clip(np.zeros(6), lb, ub)
        if x0 is not None and (np.any(x0 < lb) or np.any(x0 > ub)):
            raise ValueError('Pattern_initial must be inside Pattern_Bounds')
        for option in ['PDB_NAME', 'STAR_NAME', 'ang', 'fsc_file']:
            value = getattr(args, option, None)
            if value:
                path = Path(value).expanduser().resolve()
                if not path.is_file():
                    raise ValueError(f'{option} does not exist: {path}')
                setattr(args, option, str(path))
        args.search_script = str(resolve_script(args.search_script))
        if file_digest(args.search_script) != file_digest(SEARCH_SCRIPT):
            raise ValueError('Use the v7 standalone supplied in this package or omit --search_script')
        root = Path(args.output_name_root).expanduser().resolve()
        args.output_name_root = str(root)
        directory = root.with_name(root.name + 'DE_run')
        slots = worker_slots(args.gpuid)
        objective = GisAPRObjective(args, directory)
        signature, provenance = run_signature(args, gisapr_func)
        state = None
        if args.Pattern_continue:
            if not args.Pattern_continue_file:
                raise ValueError('DE_continue requires DE_continue_file (or Pattern_continue_file)')
            state = load_checkpoint(args.Pattern_continue_file, signature)
            saved = json.loads((directory / 'run_config.json').read_text(encoding='utf-8'))
            if saved['signature'] != signature:
                raise ValueError('Run directory signature mismatch')
            if objective.compact and not objective.store.path.is_file():
                raise ValueError('Keep evaluation_cache.sqlite3 together with the DE checkpoint')
            opt.generations = state['nit'] + args.Pattern_continue_more_rounds
        else:
            initial_budget = opt.size + int(args.DE_orientation_mode == 'fixed')
            if opt.max_evals and opt.max_evals < initial_budget:
                raise ValueError('DE_max_evals must cover the initial population plus the one fixed-bank calibration')
            directory.mkdir(parents=True, exist_ok=False)
            atomic_json(directory / 'run_config.json', dict(version=VERSION, signature=signature,
                        provenance=provenance, argv=sys.argv if argv is None else argv,
                        actual_population=opt.size, strategy='rand1bin'))
    except (ValueError, TypeError, SyntaxError, OSError, ImportError) as exc:
        parser.error(str(exc))
    lock_path = directory / 'RUNNING.lock'
    try:
        with lock_path.open('x', encoding='utf-8') as lock:
            lock.write(json.dumps(dict(pid=os.getpid(), started=time.time()))+'\n')
    except FileExistsError:
        parser.error(f'Run lock exists: {lock_path}. Verify its process has stopped before removing a stale lock.')
    latest = directory / 'latest.npz'
    history = directory / 'rounds.jsonl'
    calibration = None if state is None else state.get('calibration')

    def on_round(current, row):
        if calibration is not None:
            current['calibration'] = calibration
        save_checkpoint(latest, current, signature)
        if args.Adaptive_keep_checkpoints:
            save_checkpoint(directory / f'generation_{current["nit"]:06d}.npz', current, signature)
        if current.get('fixed_orientations') is not None:
            pass  # fixed_orientations.json is published once before population work.
        elif current['orientations'] is not None:
            atomic_json(directory / 'current_orientations.json', current['orientations'])
        else:
            (directory / 'current_orientations.json').unlink(missing_ok=True)
        with history.open('a', encoding='utf-8') as handle:
            handle.write(json.dumps(row, allow_nan=False)+'\n')
        print(f'DE generation {current["nit"]}: best={current["fun"]:.12g}, '
              f'calls={current["nfev"]}, accepted={row.get("accepted",0)}, wall={row["wall_s"]:.2f}s', flush=True)
        if args.verbose:
            print(f'  pose={current["x"]}', flush=True)

    print(f'GisAPR DE {VERSION}: rand1bin, population={opt.size}, F={opt.mutation}, CR={opt.crossover}\n'
          f'Orientation mode={args.DE_orientation_mode}, K={args.keep_orientations}; run directory: {directory}\n'
          'Pattern step/shrink/expand/tolerance and Adaptive direction options are accepted but unused by DE.', flush=True)
    try:
        if state is not None:
            if args.DE_orientation_mode == 'fixed':
                validate_fixed_bank(state.get('fixed_orientations'), objective)
            elif state.get('fixed_orientations') is not None:
                raise ValueError('A fixed-orientation checkpoint cannot continue in full mode')
            if state.get('orientations') is not None:
                check_bank(state['orientations'], objective.context)
            if history.exists():
                retained = []
                for line in history.read_text(encoding='utf-8').splitlines():
                    try:
                        row = json.loads(line)
                    except json.JSONDecodeError:
                        break
                    if row['round'] <= state['nit']:
                        retained.append(line)
                tmp = history.with_suffix('.tmp')
                tmp.write_text(''.join(line+'\n' for line in retained), encoding='utf-8')
                os.replace(tmp, history)
        gisapr_func.prepare_workers(args)
        bank = None
        initial_calls = initial_requests = 0
        if args.DE_orientation_mode == 'fixed':
            if state is None:
                print(f'Calibrating fixed Top-{args.keep_orientations} directions once at pose={x0.tolist()} ...', flush=True)
                state = calibrate_once(objective, x0, slots[0])
                # A crash during initial-population evaluation can resume here
                # without another full local search.
                save_checkpoint(latest, state, signature)
            bank = state['fixed_orientations']
            calibration = state['calibration']
            atomic_json(directory / 'fixed_orientations.json', bank)
            print(f'Fixed orientation bank ready: {bank["sha256"]}; shared by all candidates and generations.', flush=True)
            if state.get('stage') == 'calibrated':
                initial_calls = calibration['calls']
                initial_requests = calibration['requested']
                state = None
        state = differential_evolution(objective, (lb, ub), opt, x0=x0, slots=slots,
                                       state=state, on_round=on_round, metrics=metrics_snapshot,
                                       fixed_bank=bank, initial_calls=initial_calls,
                                       initial_requests=initial_requests)
        save_checkpoint(latest, state, signature)
        # Publish the current bank even when resuming an older numbered checkpoint
        # and stopping before completing another generation.
        if state.get('fixed_orientations') is not None:
            atomic_json(directory / 'fixed_orientations.json', state['fixed_orientations'])
        elif state['orientations'] is not None:
            atomic_json(directory / 'current_orientations.json', state['orientations'])
        else:
            (directory / 'current_orientations.json').unlink(missing_ok=True)
        objective.export_best(state, root, 'DE', bank=state.get('fixed_orientations'))
        print(f'DE finished: objective={state["fun"]:.12g}, pose={state["x"]}, '
              f'generations={state["nit"]}, calls={state["nfev"]}, reason={state["stop_reason"]}', flush=True)
    finally:
        try:
            gisapr_func.shutdown_workers(args)
        finally:
            try:
                objective.close()
            finally:
                lock_path.unlink(missing_ok=True)


if __name__ == '__main__':
    main()
