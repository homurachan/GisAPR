#!/usr/bin/env python3
"""PSO ver622 port for GisAPR DE-v1.2.0; fixed Top-K and compact output.

Derived from the user-supplied ver622 script, GPL-3.0. Only new JSON/NPZ
checkpoints are supported. See README_PSO_zh.md for changed file handling.
"""
import argparse
import json
import os
from pathlib import Path
import sys
import time

import numpy as np
import func_v2 as gisapr_func
from func_v2 import GisAPRObjective
from gisapr_pso import PSOOptions, pso_search
from gisapr_runtime_v2 import SEARCH_SCRIPT, metrics_snapshot, resolve_script, worker_slots
from orientation_bank_v1 import atomic_json, check_bank, positive_int
from test_op_adaptive_pattern_search_v2 import parse_bounds, parse_vector, file_digest, run_signature
from test_op_differential_evolution_v1 import calibrate_once, validate_fixed_bank

VERSION = '1.3.2'
SCHEMA = 'GisAPR_PSO_fixed_topk_v1'

def create_PSO_parser():
	parser = argparse.ArgumentParser(description="PSO Parallel Execution")
	parser.add_argument("--max_workers", type=int, default=3)
	parser.add_argument("--PDB_NAME", type=str, required=True)
	parser.add_argument("--STAR_NAME", type=str, required=True)
	parser.add_argument("--rotate_chain", type=str, required=True)
	parser.add_argument("--output_name_root", type=str, default="output")
	parser.add_argument("--gpuid", type=str, default="0")
	parser.add_argument("--ang", type=str, default=os.path.join(os.path.dirname(os.path.abspath(__file__)), "c1_3deg_remove_rotLzero_200kV.star"))
	parser.add_argument("--boxsize", type=int, default=256)
	parser.add_argument("--apix", type=float, default=1.58)
	parser.add_argument("--apix_PDB", type=float, default=1.58)
	parser.add_argument("--newboxsize", type=int, default=160)
	parser.add_argument("--search_script", type=str, default=os.path.join(os.path.dirname(os.path.abspath(__file__)), "test1_with_isspa_weight_varingKK_search_translation_also_v7_torch_optimized_standalone.py"))
	parser.add_argument("--fsc_file", type=str, default=None, help="Optional FSC curve; omit to use uniform Fourier weights.")
	parser.add_argument("--skip_geometric_restraint", action="store_true", help="Skip geometric restraint calculation and its score penalty.")
	parser.add_argument("--transRange", type=int, default=0)
	parser.add_argument("--voltage", type=float, default=300.0)
	parser.add_argument("--cs", type=float, default=2.7)
	parser.add_argument("--psiStep", type=int, default=3)
	parser.add_argument("--kk", type=int, default=3)
	parser.add_argument("--do_local_search", action="store_true")
	parser.add_argument("--local_stepsize", type=float, default=30)
	parser.add_argument("--do_ignoreFSC", action="store_true")
	parser.add_argument("--yflip", action="store_true")
	parser.add_argument("--doEnableGpuProj", action='store_true')
	parser.add_argument("--doSplitDiffGpu", action='store_true', help="If enabled, wrap_to_search will use different gpuid. The inital gpuid is provided by --gpuid. default = False")
	parser.add_argument("--SplitParticles", type=int, default=1, help="Split the starfile into these sections. Default = 1")
	parser.add_argument("--do_run_CC", action="store_true")
	parser.add_argument("--do_simple_sum", action="store_true")
	parser.add_argument("--maskRadius", type=int, default=110)
	parser.add_argument("--Geometric_restrain_Scaling_Factor", type=float, default=1.0)
	parser.add_argument("--chain_MASS_in_residues", type=int, default=275)
	parser.add_argument("--MAXIUM_ALLOWED_overlapped_pixels", type=int, default=300)
	parser.add_argument("--MAX_MinDistance_Allowed", type=float, default=30.)
	# PSO parameters
	parser.add_argument("--PSO_Bounds", type=str, default="(-15,15),(-15,15),(-15,15),(-20,20),(-20,20),(-20,20)")
	parser.add_argument("--PSO_num_particles", type=int, default=3)
	parser.add_argument("--PSO_dimensions", type=int, default=6)
	parser.add_argument("--PSO_iterations", type=int, default=30)
	parser.add_argument("--PSO_wmax", type=float, default=0.9)
	parser.add_argument("--PSO_wmin", type=float, default=0.4)
	parser.add_argument("--PSO_add_noise_velocities", action="store_true")
	parser.add_argument("--PSO_noise_strength", type=float, default=1.0)
	parser.add_argument("--PSO_noise_decay_per_round", type=float, default=0.99)
	parser.add_argument("--PSO_continue", "--continue_run", action="store_true")
	parser.add_argument("--PSO_continue_file", "--continue_file", type=str, default=None)
	parser.add_argument("--PSO_continue_more_rounds", "--continue_more_rounds", type=int, default=20)
	parser.add_argument("--PSO_continue_reset_velocities", action="store_true")
	parser.add_argument("--PSO_pivot_point", type=str, default=None, help="Attraction point in pose parameter space: rotation-vector rx,ry,rz (degrees),tx,ty,tz (angstrom). Default all zeros; this is not a physical rotation center.")
	# mlp model parameters
	parser.add_argument("--PSO_use_surrogate", action="store_true")
	parser.add_argument("--PSO_surrogate_start_round", type=int, default=5, help="Start training surrogate after this many completed PSO rounds.")
	parser.add_argument("--PSO_surrogate_update_every", type=int, default=5, help="Retrain surrogate every N rounds.")
	parser.add_argument("--PSO_surrogate_min_points", type=int, default=20, help="Minimum number of real evaluated points before training surrogate.")
	parser.add_argument("--PSO_surrogate_weight", type=float, default=0.5, help="Strength of surrogate guidance term.")
	parser.add_argument("--PSO_surrogate_hidden", type=str, default="128,128,64", help="Hidden layer sizes for surrogate MLP, e.g. 128,128,64")
	parser.add_argument("--PSO_surrogate_random_state", type=int, default=0)
	parser.add_argument("--PSO_SKIP_surrogate_THRESHOLD", type=float, default=1.0)
	from gisapr_options_v2 import add_runtime_options
	parser.set_defaults(do_local_search=True)
	parser.add_argument('--keep-orientations', type=positive_int, default=3)
	parser.add_argument('--PSO_orientation_mode', choices=('fixed','full'), default='fixed')
	parser.add_argument('--PSO_given_initial', action='store_true')
	parser.add_argument('--PSO_initial', default='[0,0,0,0,0,0]', help='Calibration pose and first particle when PSO_given_initial is set.')
	parser.add_argument('--PSO_seed', type=int, default=0)
	parser.add_argument('--PSO_c1', type=float, default=2.)
	parser.add_argument('--PSO_c2', type=float, default=2.)
	parser.add_argument('--PSO_max_evals', type=int, default=0, help='Cumulative actual objective budget including calibration; 0 is unlimited.')
	parser.add_argument('--PSO_converge_velocities', type=float, default=0., help='Stop when every final velocity component of every particle has absolute value strictly below this threshold (degrees/angstrom per round); 0 disables (default).')
	parser.add_argument('--PSO_keep_checkpoints', action='store_true')
	return add_runtime_options(parser)


def save_checkpoint(path, state, signature):
    path = Path(path)
    tmp = path.with_name(path.name+'.tmp')
    text = json.dumps(dict(schema=SCHEMA,version=VERSION,signature=signature,state=state),allow_nan=False)
    with tmp.open('wb') as handle:
        np.savez_compressed(handle,state_json=np.array(text))
    os.replace(tmp,path)


def load_checkpoint(path, signature):
    with np.load(path,allow_pickle=False) as data:
        if 'state_json' not in data:
            raise ValueError('Only new PSO-port checkpoints are supported; legacy PSO NPZ files cannot resume here')
        payload = json.loads(str(data['state_json'].item()))
    if payload.get('schema') != SCHEMA or payload.get('version') != VERSION:
        raise ValueError(f'Use a PSO port v{VERSION} checkpoint, not a DE/Pattern/legacy PSO checkpoint')
    if payload['signature'] != signature:
        raise ValueError('PSO checkpoint inputs/code/settings/output root differ; reuse the original command and add continuation flags')
    return payload['state']


def pso_signature(args):
    ignored = {'PSO_continue','PSO_continue_file','PSO_continue_more_rounds',
               'PSO_continue_reset_velocities','PSO_keep_checkpoints','PSO_max_evals','PSO_converge_velocities'}
    signed = argparse.Namespace(**{k:v for k,v in vars(args).items() if k not in ignored})
    return run_signature(signed,gisapr_func)


def main(argv=None):
    parser = create_PSO_parser()
    args = parser.parse_args(argv)
    args.optimizer = 'PSO'
    try:
        if args.PSO_dimensions != 6:
            raise ValueError('GisAPR rigid-body PSO requires PSO_dimensions=6')
        lb,ub = parse_bounds(args.PSO_Bounds,6)
        pivot = np.zeros(6) if args.PSO_pivot_point is None else parse_vector(args.PSO_pivot_point,6,'PSO_pivot_point')
        x0 = parse_vector(args.PSO_initial,6,'PSO_initial') if args.PSO_given_initial else None
        if x0 is not None and (np.any(x0<lb) or np.any(x0>ub)):
            raise ValueError('PSO_initial must be inside PSO_Bounds')
        opt = PSOOptions(particles=args.PSO_num_particles,iterations=args.PSO_iterations,
            wmax=args.PSO_wmax,wmin=args.PSO_wmin,c1=args.PSO_c1,c2=args.PSO_c2,
            seed=args.PSO_seed,max_workers=args.max_workers,max_evals=args.PSO_max_evals,
            converge_velocities=args.PSO_converge_velocities,
            add_noise=args.PSO_add_noise_velocities,noise_strength=args.PSO_noise_strength,
            noise_decay=args.PSO_noise_decay_per_round,skip_geometry=args.skip_geometric_restraint,
            geometry_threshold=args.MAXIUM_ALLOWED_overlapped_pixels,use_surrogate=args.PSO_use_surrogate,
            surrogate_start=args.PSO_surrogate_start_round,surrogate_every=args.PSO_surrogate_update_every,
            surrogate_min_points=args.PSO_surrogate_min_points,surrogate_weight=args.PSO_surrogate_weight,
            surrogate_hidden=tuple(int(x.strip()) for x in args.PSO_surrogate_hidden.split(',') if x.strip()),
            surrogate_seed=args.PSO_surrogate_random_state,surrogate_skip_threshold=args.PSO_SKIP_surrogate_THRESHOLD)
        opt.validate()
        # Match the first particle created by pso_search. A separate RNG with
        # the same seed previews its position without consuming the swarm RNG
        # or changing any particle's initial position/velocity.
        reference = (np.random.RandomState(opt.seed).uniform(lb,ub,size=(opt.particles,6))[0]
                     if x0 is None else x0.copy())
        if args.PSO_continue_more_rounds < 0:
            raise ValueError('PSO_continue_more_rounds must be nonnegative')
        if args.PSO_continue_reset_velocities and not args.PSO_continue:
            raise ValueError('PSO_continue_reset_velocities requires PSO_continue')
        if args.PSO_use_surrogate:
            from gisapr_pso_surrogate import require_sklearn
            require_sklearn()
        for key in ('PDB_NAME','STAR_NAME','ang','fsc_file'):
            if getattr(args,key,None):
                path = Path(getattr(args,key)).expanduser().resolve()
                if not path.is_file():
                    raise ValueError(f'{key} does not exist: {path}')
                setattr(args,key,str(path))
        args.search_script = str(resolve_script(args.search_script))
        if file_digest(args.search_script) != file_digest(SEARCH_SCRIPT):
            raise ValueError('Use the DE-v1.2.0 v7 search supplied here; omit an old v606 --search_script argument')
        root = Path(args.output_name_root).expanduser().resolve()
        args.output_name_root = str(root)
        directory = root.with_name(root.name+'PSO_run')
        slots = worker_slots(args.gpuid)
        objective = GisAPRObjective(args,directory)
        signature,provenance = pso_signature(args)
        state = None
        limit = opt.iterations
        if args.PSO_continue:
            if not args.PSO_continue_file:
                raise ValueError('PSO_continue requires PSO_continue_file')
            state = load_checkpoint(args.PSO_continue_file,signature)
            config = json.loads((directory/'run_config.json').read_text(encoding='utf-8'))
            if config['signature'] != signature:
                raise ValueError('Run directory signature mismatch')
            if objective.compact and not objective.store.path.is_file():
                raise ValueError('Keep evaluation_cache.sqlite3 with the checkpoint')
            limit = state['nit']+args.PSO_continue_more_rounds
            if state.get('stage') == 'calibrated' and (limit < 1 or args.PSO_continue_reset_velocities):
                raise ValueError('Calibration-only checkpoint needs at least one swarm round; velocity reset needs an initialized swarm')
        else:
            required = opt.particles+int(args.PSO_orientation_mode=='fixed')
            if opt.max_evals and opt.max_evals < required:
                raise ValueError('PSO_max_evals must cover calibration and the first full swarm')
            directory.mkdir(parents=True,exist_ok=False)
            atomic_json(directory/'run_config.json',dict(version=VERSION,signature=signature,provenance=provenance,
                        argv=sys.argv if argv is None else argv,particles=opt.particles,
                        orientation_mode=args.PSO_orientation_mode,inertia_schedule_iterations=opt.iterations))
    except (ValueError,TypeError,OSError,ImportError) as exc:
        parser.error(str(exc))
    lock_path = directory/'RUNNING.lock'
    try:
        with lock_path.open('x',encoding='utf-8') as handle:
            handle.write(json.dumps(dict(pid=os.getpid(),started=time.time()))+'\n')
    except FileExistsError:
        parser.error(f'Run lock exists: {lock_path}. Verify the original process has stopped before removing a stale lock.')
    latest,history = directory/'latest.npz',directory/'rounds.jsonl'
    calibration = None if state is None else state.get('calibration')

    def on_round(current,row):
        if calibration is not None:
            current['calibration'] = calibration
        save_checkpoint(latest,current,signature)
        if args.PSO_keep_checkpoints:
            save_checkpoint(directory/f'round_{current["nit"]:06d}.npz',current,signature)
        if current.get('fixed_orientations') is None:
            if current.get('orientations') is None:
                (directory/'current_orientations.json').unlink(missing_ok=True)
            else:
                atomic_json(directory/'current_orientations.json',current['orientations'])
        with history.open('a',encoding='utf-8') as handle:
            handle.write(json.dumps(row,allow_nan=False)+'\n')
        print(f'PSO round {current["nit"]}: best={current["fun"]:.12g}, '
              f'called={row["called"]}, total_calls={current["nfev"]}, '
              f'pbest_improved={row.get("pbest_improved",0)}, max_abs_v={current["max_abs_velocity"]:.6g}, '
              f'event={row["event"]}, wall={row["wall_s"]:.2f}s',flush=True)
        if args.verbose:
            print(f'  best_pose={current["x"]}; sigma={current["sigma"]:.6g}',flush=True)

    def on_progress(iteration,completed,total,elapsed,heartbeat):
        if args.verbose or heartbeat:
            print(f'[PSO] round {iteration}: completed={completed}/{total}, elapsed={elapsed:.1f}s '
                  '(queued/evaluating candidates)',flush=True)

    print(f'GisAPR PSO port {VERSION}: particles={opt.particles}, orientation_mode={args.PSO_orientation_mode}, '
          f'K={args.keep_orientations}, w={opt.wmax}->{opt.wmin}, c1={opt.c1}, c2={opt.c2}, '
          f'converge_velocities={opt.converge_velocities}\n'
          f'Run directory: {directory}',flush=True)
    try:
        if state is not None:
            if args.PSO_orientation_mode == 'fixed':
                validate_fixed_bank(state.get('fixed_orientations'),objective)
            elif state.get('fixed_orientations') is not None:
                raise ValueError('Cannot resume a fixed-bank PSO checkpoint in full mode')
            if history.exists():
                retained = []
                for line in history.read_text(encoding='utf-8').splitlines():
                    try:
                        row = json.loads(line)
                    except json.JSONDecodeError:
                        break
                    if row['round'] <= state['nit']:
                        retained.append(line)
                tmp = history.with_suffix('.tmp')
                tmp.write_text(''.join(line+'\n' for line in retained),encoding='utf-8')
                os.replace(tmp,history)
        gisapr_func.prepare_workers(args)
        bank = None
        initial_calls = initial_requests = 0
        if args.PSO_orientation_mode == 'fixed':
            if state is None:
                print(f'Calibrating fixed Top-{args.keep_orientations} once at {reference.tolist()} ...',flush=True)
                state = calibrate_once(objective,reference,slots[0])
                save_checkpoint(latest,state,signature)
            bank,calibration = state['fixed_orientations'],state['calibration']
            atomic_json(directory/'fixed_orientations.json',bank)
            print(f'Fixed orientation bank ready: {bank["sha256"]}; shared by all PSO particles and rounds.',flush=True)
            if state.get('stage') == 'calibrated':
                initial_calls,initial_requests = calibration['calls'],calibration['requested']
                state = None
        state = pso_search(objective,(lb,ub),opt,pivot=pivot,x0=x0,slots=slots,state=state,
                           fixed_bank=bank,initial_calls=initial_calls,initial_requests=initial_requests,
                           total_rounds=limit,reset_velocities=args.PSO_continue_reset_velocities,
                           on_round=on_round,on_progress=on_progress,metrics=metrics_snapshot)
        save_checkpoint(latest,state,signature)
        if state.get('fixed_orientations') is not None:
            atomic_json(directory/'fixed_orientations.json',state['fixed_orientations'])
        elif state.get('orientations') is not None:
            atomic_json(directory/'current_orientations.json',state['orientations'])
        else:
            (directory/'current_orientations.json').unlink(missing_ok=True)
        objective.export_best(state,root,'PSO',bank=state.get('fixed_orientations'))
        print(f'PSO finished: best={state["fun"]:.12g}, pose={state["x"]}, rounds={state["nit"]}, '
              f'total_calls={state["nfev"]}, max_abs_v={state["max_abs_velocity"]:.6g}, '
              f'reason={state["stop_reason"]}',flush=True)
    finally:
        try:
            gisapr_func.shutdown_workers(args)
        finally:
            try:
                objective.close()
            finally:
                lock_path.unlink(missing_ok=True)


if __name__ == '__main__':
    main()
