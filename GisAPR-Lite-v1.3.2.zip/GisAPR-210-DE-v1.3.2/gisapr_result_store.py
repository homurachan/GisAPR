"""One transactional, compressed result cache instead of per-pose directories.

The optimizer owns the run lock. SQLite access is serialized across evaluation
threads, uses the rollback journal (not WAL), and commits complete batches.
Scratch directories are reused by controller threads, never by pose.
"""
import json
from pathlib import Path
import shutil
import sqlite3
import threading
import zlib


class ResultStore:
    def __init__(self, directory):
        self.directory = Path(directory).resolve()
        self.path = self.directory / 'evaluation_cache.sqlite3'
        self.lock = threading.RLock()
        self.connection = None
        self.scratch = {}

    def _connect(self):
        if self.connection is None:
            self.connection = sqlite3.connect(self.path, timeout=60, check_same_thread=False)
            self.connection.execute('PRAGMA journal_mode=DELETE')
            self.connection.execute('PRAGMA synchronous=FULL')
            self.connection.execute('CREATE TABLE IF NOT EXISTS evaluations '
                                    '(pose TEXT, bank TEXT, payload BLOB NOT NULL, '
                                    'PRIMARY KEY (pose, bank))')
            self.connection.commit()
        return self.connection

    @staticmethod
    def key(pose_hex, bank):
        return pose_hex, '' if bank is None else bank['sha256']

    def contains(self, pose_hex, bank):
        with self.lock:
            return self._connect().execute(
                'SELECT 1 FROM evaluations WHERE pose=? AND bank=?',
                self.key(pose_hex, bank)).fetchone() is not None

    def get(self, pose_hex, bank):
        with self.lock:
            row = self._connect().execute(
                'SELECT payload FROM evaluations WHERE pose=? AND bank=?',
                self.key(pose_hex, bank)).fetchone()
        return None if row is None else json.loads(zlib.decompress(row[0]))

    def put(self, pose_hex, bank, meta, ranked, search_text):
        self.put_many([(pose_hex, bank, meta, ranked, search_text)])

    def put_many(self, evaluations):
        # Serialize/validate everything before opening the transaction. An
        # interrupted batch rolls back; the round checkpoint is written later.
        rows = []
        for pose_hex, bank, meta, ranked, search_text in evaluations:
            payload = zlib.compress(json.dumps(dict(meta=meta, ranked=ranked, search_text=search_text),
                                              allow_nan=False, separators=(',', ':')).encode(), 3)
            rows.append((*self.key(pose_hex, bank), payload))
        if not rows:
            return
        with self.lock:
            connection = self._connect()
            with connection:
                connection.executemany('INSERT OR REPLACE INTO evaluations VALUES (?,?,?)', rows)

    def workspace(self):
        with self.lock:
            thread = threading.get_ident()
            if thread not in self.scratch:
                self.scratch[thread] = self.directory / '_scratch' / f'worker_{len(self.scratch):03d}'
            path = self.scratch[thread]
            path.mkdir(parents=True, exist_ok=True)
            return path

    def close(self):
        with self.lock:
            if self.connection is not None:
                self.connection.close()
                self.connection = None
            path = self.directory / '_scratch'
            # Delete only the fixed scratch child of this exact run directory.
            if path.exists():
                if path.is_symlink() or path.resolve().parent != self.directory:
                    raise ValueError(f'Unsafe scratch path: {path}')
                shutil.rmtree(path)
