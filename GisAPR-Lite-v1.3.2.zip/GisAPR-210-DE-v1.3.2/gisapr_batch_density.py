"""Fixed-body density reuse, with the original first-model/PDB rounding rules.

Fixed atoms are accumulated once, then moving atoms are added to a copy.
Optional fused CUDA deposition retains the same formula and boundary rules.
This changes floating-point accumulation order;
it is mathematically equivalent, not a promise of bitwise equality.
"""
import numpy as np
import time
from functools import partial

from gisapr_cache import file_key
from pdb_text import (read_pdb_cached, transform_coordinates, quantize_coordinates)
from pdb2mrc_gpu_ver_fp32_v4 import (atoms_to_atomic_numbers_and_masses,
                                   density_from_coords, generate_volume, yflip_vectorized)


class RigidDensityCache:
    def __init__(self):
        self.key = None
        self.fixed = None
        self.last_metrics = {}

    def clear(self):
        self.key = self.fixed = None
        self.first = self.moving_coords = self.moving_numbers = self.transform_rows = None

    @staticmethod
    def source_key(kwargs, max_mb, mode, backend):
        source = kwargs.get('source_pdb')
        box = int(kwargs['boxsize'])
        if (mode != 'fixed' or not source or kwargs.get('do_center', False)
                or box**3 * 4 > max_mb * 1024**2):
            return None
        return (file_key(source), str(kwargs['chain_id']), box, float(kwargs['apix']),
                float(kwargs['res']), str(kwargs.get('device', 'cpu')),
                bool(kwargs.get('include_hetatm', False)), backend)

    @staticmethod
    def _coordinates(coords, rows, pose, key):
        # Pure CPU function: snapshots are held by this job, never cache fields.
        t0 = time.perf_counter()
        transformed = transform_coordinates(coords, pose)
        t1 = time.perf_counter()
        quantized = quantize_coordinates(transformed)[rows]
        t2 = time.perf_counter()
        return dict(key=key, pose=pose, coordinates=quantized,
                    transform_s=t1-t0, quantize_s=t2-t1)

    def coordinate_job(self, kwargs, max_mb=128., mode='fixed', backend='auto'):
        key = self.source_key(kwargs, max_mb, mode, backend)
        if key is None or key != self.key or self.fixed is None:
            return None
        return partial(self._coordinates, self.moving_coords, self.transform_rows,
                       tuple(kwargs['pose']), key)

    def generate(self, kwargs, max_mb=128., mode='fixed', backend='auto', prepared=None):
        import torch
        started = time.perf_counter()
        source = kwargs.get('source_pdb')
        box = int(kwargs['boxsize'])
        self.last_metrics = dict(fixed_density_hits=0, fixed_density_cached_atoms=0)
        if (mode != 'fixed' or not source or kwargs.get('do_center', False)
                or box ** 3 * 4 > max_mb * 1024 ** 2):
            self.clear()
            return generate_volume(**kwargs, density_backend=backend, backend_metrics=self.last_metrics)
        chain = str(kwargs['chain_id'])
        include = bool(kwargs.get('include_hetatm', False))
        key = (file_key(source), chain, box, float(kwargs['apix']), float(kwargs['res']),
               str(kwargs.get('device', 'cpu')), include, backend)
        hit = key == self.key and self.fixed is not None
        if not hit:
            self.clear()
            self.first = read_pdb_cached(source)
            density = read_pdb_cached(source, include_hetatm=include, first_model_only=False)
            selected = self.first.chains == chain
            if not selected.any():
                raise ValueError(f'Chain {chain!r} has no atoms in the first PDB model')
            moving_lines = self.first.atom_line_indices[selected]
            self.moving_coords = self.first.coords[selected]
            positions = {int(line): i for i, line in enumerate(moving_lines)}
            moving = np.isin(density.atom_line_indices, moving_lines)
            self.transform_rows = np.asarray([positions[int(line)] for line in
                                              density.atom_line_indices[moving]], dtype=np.int64)
            numbers, _ = atoms_to_atomic_numbers_and_masses(density.elements)
            self.moving_numbers = torch.as_tensor(numbers[moving], dtype=torch.float32,
                                                  device=kwargs.get('device', 'cpu'))
            self.fixed_atom_count = int((~moving).sum())
            self.fixed = density_from_coords(density.coords[~moving], numbers[~moving],
                box, kwargs['apix'], kwargs['res'], device=kwargs.get('device', 'cpu'),
                backend=backend, backend_metrics=self.last_metrics)
            if self.fixed.is_cuda:
                torch.cuda.synchronize(self.fixed.device)
            self.key = key
        prepared_at = time.perf_counter()
        # Exactly the same 8.3 formatting, finite/width checks and HETATM pivot
        # participation as transformed_density_atoms / write_transformed_chain.
        prefetched = (prepared is not None and prepared['key'] == key
                      and prepared['pose'] == tuple(kwargs['pose']))
        if not prefetched:
            prepared = self._coordinates(self.moving_coords, self.transform_rows,
                                         tuple(kwargs['pose']), key)
        deposit_started = time.perf_counter()
        volume = density_from_coords(prepared['coordinates'], self.moving_numbers,
            box, kwargs['apix'], kwargs['res'], device=kwargs.get('device', 'cpu'),
            _initial_volume=self.fixed, backend=backend, backend_metrics=self.last_metrics)
        if kwargs.get('do_yflip', False):
            volume = yflip_vectorized(volume)
        if volume.is_cuda:
            torch.cuda.synchronize(volume.device)
        self.last_metrics.update(fixed_density_hits=int(hit),
            fixed_density_cached_atoms=self.fixed_atom_count,
            density_moving_atoms=len(self.moving_numbers),
            density_prepare_s=prepared_at-started, density_transform_s=prepared['transform_s'],
            density_quantize_s=prepared['quantize_s'], density_prefetch_hits=int(prefetched),
            density_deposit_s=time.perf_counter()-deposit_started)
        return volume
