"""Portable Top-K direction banks for an immutable particle STAR and angle grid."""
import argparse
from functools import lru_cache
import hashlib
import json
import math
import os
from pathlib import Path
from tempfile import NamedTemporaryFile

from gisapr_cache import file_key


def positive_int(value):
    number = int(value)
    if number < 1:
        raise argparse.ArgumentTypeError("must be >= 1")
    return number


def atomic_json(path, obj):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with NamedTemporaryFile('w', encoding='utf-8', dir=path.parent, delete=False) as file:
        temporary = Path(file.name)
        try:
            json.dump(obj, file, allow_nan=False, ensure_ascii=False, indent=2)
            file.write('\n')
        except BaseException:
            file.close()
            temporary.unlink(missing_ok=True)
            raise
    try:
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)


@lru_cache(maxsize=16)
def file_hash(identity):
    h = hashlib.sha256()
    with open(identity[0], 'rb') as file:
        for chunk in iter(lambda: file.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def settings(particles, angles, keep, local, angular_range, psi_step):
    return dict(schema='gisapr-orientations-v1', particle_sha256=file_hash(file_key(particles)),
                angle_sha256=file_hash(file_key(angles)), keep=keep, local=bool(local),
                local_range=float(angular_range), psi_step=float(psi_step))


def pack_bank(context, rows, **origin):
    bank = dict(settings=context, rows=rows, **origin)
    bank['sha256'] = bank_digest(bank)
    return bank


def bank_digest(bank):
    content = {k:v for k,v in bank.items() if k != 'sha256'}
    return hashlib.sha256(json.dumps(content, sort_keys=True, allow_nan=False,
                                      separators=(',', ':')).encode()).hexdigest()


def check_bank(bank, context):
    if bank.get('settings') != context or bank.get('sha256') != bank_digest(bank):
        raise ValueError('Orientation bank digest or input/K/search settings mismatch')


def restricted_indices(row, rec, allowed, angles, keep):
    """Validate the STAR identity and real grid coordinates before mapping a shard."""
    if row is None or row['image'] != rec.image_name:
        raise ValueError(f'Missing or mismatched bank entry at STAR line {rec.line_index}')
    directions = row['directions']
    if (not directions and allowed) or len(directions) > min(keep, len(allowed)):
        raise ValueError(f'Invalid direction count at STAR line {rec.line_index}')
    seen = set()
    indices = []
    allowed = set(allowed)
    for i, rot, tilt, score in directions:
        if (type(i) is not int or i not in allowed or (rot, tilt) in seen
                or (rot, tilt) != (angles.rot[i], angles.tilt[i]) or not math.isfinite(score)):
            raise ValueError(f'Invalid bank direction at STAR line {rec.line_index}')
        seen.add((rot, tilt))
        indices.append(i)
    return sorted(indices)  # tie ordering in the search always follows the original angle file


def ranked_row(rec, indices, angles, scores, keep):
    # The translation peak has already been taken. Maximize over psi BEFORE
    # ranking different rot/tilt directions. Stable sorting breaks ties by grid order.
    import numpy as np
    peaks = scores.amax(dim=1).detach().cpu().numpy()
    if np.isinf(peaks).any():
        raise ValueError(f'Infinite directional peak at STAR line {rec.line_index}')
    if np.isnan(peaks).any():
        return dict(image=rec.image_name, directions=[], invalid_rawcc=True)
    directions, seen = [], set()
    for j in np.argsort(-peaks, kind='stable'):
        i = indices[j]
        pair = (angles.rot[i], angles.tilt[i])
        if pair not in seen:
            seen.add(pair)
            directions.append([int(i), *pair, float(peaks[j])])
            if len(directions) == keep:
                break
    return dict(image=rec.image_name, directions=directions)
