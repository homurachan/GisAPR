"""Strict CPU reuse of a fixed prefix of the original atom accumulation.

Adding separately accumulated body/subunit volumes or projections is NOT
bitwise equivalent. Instead, retain the accumulator at an original atom-chunk
boundary before the first movable atom, then resume exactly the old sequence.
No small-volume FFT, independent whitening, or changed projection arithmetic is
used. CUDA falls back to the original generator because atomic-add ordering
cannot be promised bitwise identical there.
"""
import numpy as np

from gisapr_cache import HostCache, file_key


class FixedDensityCache:
    def __init__(self, max_mb=128.):
        self.cache = HostCache(float(max_mb) * 1024 ** 2, max_entries=1)
        self.last_metrics = {}

    def generate(self, **kwargs):
        import torch
        from pdb2mrc_gpu_ver_fp32_v4 import (generate_volume, density_from_coords,
            atoms_to_atomic_numbers_and_masses, _round_away_from_zero,
            _voxel_offsets, yflip_vectorized)
        from pdb_text import read_pdb_cached, transformed_density_atoms

        self.last_metrics = dict(fixed_density_hits=0, fixed_density_cached_atoms=0)
        device = torch.device(kwargs.get('device', 'cpu'))
        source = kwargs.get('source_pdb')
        if (device.type != 'cpu' or not source or kwargs.get('do_center', False)
                or self.cache.max_bytes <= 0):
            return generate_volume(**kwargs)

        box = int(kwargs['boxsize'])
        apix, res = float(kwargs['apix']), float(kwargs['res'])
        if box < 1 or not np.isfinite(apix) or not np.isfinite(res) or apix <= 0 or res <= 0:
            return generate_volume(**kwargs)
        # PyTorch canonicalizes cpu:0 tensors to cpu. Use that same canonical
        # device for the private accumulator-resume API.
        device = torch.device('cpu')
        include_hetatm = bool(kwargs.get('include_hetatm', False))
        chain = str(kwargs['chain_id'])
        volume_bytes = box ** 3 * 4
        if not self.cache.can_store_bytes(volume_bytes + 4096):
            return generate_volume(**kwargs)
        key = (file_key(source), chain, box, apix, res, include_hetatm,
               'ordered-prefix-v1', torch.get_num_threads())
        prepared = self.cache.get(key)
        hit = prepared is not None
        coordinates, elements = transformed_density_atoms(
            source, chain, kwargs['pose'], include_hetatm)
        numbers, _ = atoms_to_atomic_numbers_and_masses(elements)
        if prepared is None:
            first = read_pdb_cached(source)
            density = read_pdb_cached(source, include_hetatm=include_hetatm,
                                      first_model_only=False)
            moving_lines = first.atom_line_indices[first.chains == chain]
            moving = np.flatnonzero(np.isin(density.atom_line_indices, moving_lines))
            first_moving = int(moving[0]) if len(moving) else len(coordinates)

            # Match baseline filtering and chunk boundaries before caching. An
            # invalid/unsupported atom must not count towards a density chunk.
            width = int(round(res * 3.0 / apix))
            if width < 3:
                return generate_volume(**kwargs)
            prefix_xyz = torch.as_tensor(coordinates[:first_moving], dtype=torch.float32)
            positions = (prefix_xyz.to(torch.float64) / apix + box // 2).to(torch.float32)
            lower = _round_away_from_zero(positions - width)
            upper = _round_away_from_zero(positions + width)
            valid = ((lower < box).all(dim=1) & (upper >= 0).all(dim=1)
                     & (torch.as_tensor(numbers[:first_moving]) != 0))
            valid_rows = torch.nonzero(valid).flatten()
            chunk_size = max(1, 524288 // len(_voxel_offsets(width, str(device))))
            count = len(valid_rows) // chunk_size * chunk_size
            if count == 0:
                return generate_volume(**kwargs)
            stop = int(valid_rows[count - 1]) + 1
            prefix = density_from_coords(coordinates[:stop], numbers[:stop],
                                         box, apix, res, device=device)
            prepared = (stop, count, prefix)
            self.cache.clear()
            self.cache.put(key, prepared)

        stop, count, prefix = prepared
        volume = density_from_coords(coordinates[stop:], numbers[stop:],
                                     box, apix, res, device=device,
                                     _initial_volume=prefix)
        if kwargs.get('do_yflip', False):
            volume = yflip_vectorized(volume)
        self.last_metrics = dict(fixed_density_hits=int(hit),
                                 fixed_density_cached_atoms=int(count))
        return volume
