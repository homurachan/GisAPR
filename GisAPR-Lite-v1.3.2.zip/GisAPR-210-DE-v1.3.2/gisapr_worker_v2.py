"""Persistent, authenticated local worker for GisAPR refinement.

The optimized search program imports this module only for its worker mode.
Keeping the controller out of this process lets each GPU import PyTorch once;
geometry checks, PDB density generation and particle searches then reuse it.
The wire protocol uses standard-library multiprocessing connections and Python
dictionaries, and deliberately does not change any search result files.
"""

from __future__ import annotations

import argparse
from collections import OrderedDict
import os
from pathlib import Path
import sys
import traceback
import time
from multiprocessing.connection import Client


def create_worker_parser():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--worker-connect", nargs=2, metavar=("HOST", "PORT"), required=True)
    parser.add_argument("--worker-auth", required=True, help="Local connection authentication key in hexadecimal")
    parser.add_argument("--worker-gpuid", default="0", help="GPU index, or cpu")
    return parser


def _geometry_cache_key(kwargs):
    """Invalidate prepared geometry when either its model or settings change."""
    path = Path(kwargs["pdb_path"]).expanduser().resolve()
    stat = path.stat()
    kwargs["pdb_path"] = str(path)
    settings = tuple(sorted(kwargs.items()))
    return settings, stat.st_size, stat.st_mtime_ns, stat.st_ctime_ns


def run_worker(create_search_parser, run_search, choose_device, argv=None):
    """Connect to the controller, execute requests in order, and remain alive.

    Requests:
      geometry: geometry_kwargs, pose, optional pivot
      generate_mrc: mrc_kwargs
      search: argv (the existing standalone search argument list)
      search_from_pdb: argv, model_kwargs (density and search in one request)
      ping / shutdown: no additional arguments

    Any request may supply cwd.  Each job starts in the worker's initial cwd
    unless an explicit cwd is supplied.  The assigned GPU overrides any
    per-request device, so a persistent process cannot switch GPUs.
    """
    import torch

    args = create_worker_parser().parse_args(argv)
    host, port = args.worker_connect
    if host not in ("127.0.0.1", "localhost"):
        raise ValueError("The GisAPR worker must connect to a loopback host")
    authkey = bytes.fromhex(args.worker_auth)
    if not authkey:
        raise ValueError("Worker authentication key cannot be empty")
    gpu = str(args.worker_gpuid).strip().lower()
    if gpu != "cpu":
        gpu = int(gpu)
        if gpu < 0:
            raise ValueError("worker-gpuid must be a nonnegative GPU index or cpu")
    device = choose_device(gpu)
    search_gpuid = device.index if device.type == "cuda" else "cpu"
    initial_cwd = os.getcwd()
    geometry_cache = OrderedDict()
    geometry_cache_limit = 2
    from gisapr_cache import SearchCache
    search_cache = None
    search_cache_settings = None
    density_cache = None
    density_cache_mb = None
    batch_engine = None

    with Client((host, int(port)), family="AF_INET", authkey=authkey) as connection:
        connection.send({"ok": True, "event": "ready", "pid": os.getpid(), "device": str(device)})
        while True:
            try:
                request = connection.recv()
            except (EOFError, ConnectionError):
                break

            try:
                if not isinstance(request, dict):
                    raise TypeError("Worker request must be a dictionary")
                command = request.get("command")
                os.chdir(request.get("cwd") or initial_cwd)
                if command == "shutdown":
                    connection.send({"ok": True, "result": None})
                    break
                with torch.inference_mode():
                    if command == "geometry":
                        from func_check_boundary_for_testing_v9 import GeometryRestraint

                        kwargs = dict(request["geometry_kwargs"])
                        kwargs["device"] = str(device)
                        key = _geometry_cache_key(kwargs)
                        geometry = geometry_cache.get(key)
                        if geometry is None:
                            geometry = GeometryRestraint(**kwargs)
                            geometry_cache[key] = geometry
                            # Pixel-size scans can change settings repeatedly;
                            # keep prepared model state bounded in a long run.
                            if len(geometry_cache) > geometry_cache_limit:
                                geometry_cache.popitem(last=False)
                        else:
                            geometry_cache.move_to_end(key)
                        overlap, distance = geometry.evaluate(request["pose"], pivot=request.get("pivot"))
                        result = (int(overlap), float(distance))
                    elif command == "generate_mrc":
                        from pdb2mrc_gpu_ver_fp32_v4 import generate_mrc

                        kwargs = dict(request["mrc_kwargs"])
                        kwargs["device"] = str(device)
                        result = generate_mrc(**kwargs)
                    elif command == 'search_batch_from_pdb':
                        from gisapr_batch_search import BatchSearchEngine
                        search_args = create_search_parser().parse_args(request['argv'])
                        search_args.gpuid = search_gpuid
                        options = request['options']
                        if batch_engine is None or batch_engine.options != options:
                            batch_engine = None
                            batch_engine = BatchSearchEngine(run_search.__globals__, device, options)
                        try:
                            result = batch_engine.run(search_args, request['models'],
                                request.get('orientation_rows'), request.get('calibrate', False))
                        except torch.cuda.OutOfMemoryError as exc:
                            # Drop retained tensors before reporting a recoverable
                            # request failure; never publish a partial candidate batch.
                            batch_engine = None
                            torch.cuda.empty_cache()
                            raise RuntimeError('Batch evaluation ran out of device memory. Reduce '
                                '--batch_candidates / --batch_template_mb / --batch_grid_cache_mb '
                                'and other cache budgets, or '
                                'use --evaluation_mode legacy.') from exc
                    elif command in ("search", "search_from_pdb"):
                        search_args = create_search_parser().parse_args(request["argv"])
                        search_args.gpuid = search_gpuid
                        settings = (getattr(search_args, 'search_cache_mb', 64.),
                                    getattr(search_args, 'ctf_cache_mb', 256.))
                        if settings != search_cache_settings:
                            search_cache = SearchCache(*settings)
                            search_cache_settings = settings
                        run_kwargs = {'session_cache': search_cache}
                        run_kwargs['calibrate'] = request.get('calibrate', False)
                        run_kwargs['orientation_rows'] = request.get('orientation_rows')
                        density_seconds = 0.
                        density_metrics = {}
                        volume = None
                        if command == "search_from_pdb":
                            kwargs = dict(request['model_kwargs'])
                            kwargs['device'] = str(device)
                            density_start = time.perf_counter()
                            budget = getattr(search_args, 'fixed_density_cache_mb', 128.)
                            if density_cache is None or density_cache_mb != budget:
                                from gisapr_density_cache_v1 import FixedDensityCache
                                density_cache = FixedDensityCache(budget)
                                density_cache_mb = budget
                            volume = density_cache.generate(**kwargs)
                            density_metrics = density_cache.last_metrics
                            if device.type == 'cuda':
                                torch.cuda.synchronize(device)
                            density_seconds = time.perf_counter() - density_start
                            run_kwargs['model_volume'] = volume
                        try:
                            result = run_search(search_args, **run_kwargs)
                        finally:
                            # Tensor lifetime is restricted to this request. Another
                            # candidate can never replace a pending search's input.
                            run_kwargs.clear()
                            del volume
                        if isinstance(result, dict):
                            result['density_s'] = density_seconds
                            result.update(density_metrics)
                    elif command == "ping":
                        result = {"pid": os.getpid(), "device": str(device), "geometry_cache_entries": len(geometry_cache)}
                        if batch_engine is not None:
                            result.update(batch_particle_cache_bytes=batch_engine.particles.bytes,
                                          batch_volume_cache_bytes=batch_engine.volumes.bytes)
                        if device.type == 'cuda':
                            result.update(cuda_peak_allocated_bytes=torch.cuda.max_memory_allocated(device),
                                          cuda_peak_reserved_bytes=torch.cuda.max_memory_reserved(device))
                        if search_cache is not None:
                            result.update(ctf_cache_bytes=search_cache.ctf.bytes,
                                          metadata_cache_bytes=search_cache.metadata.bytes,
                                          ctf_cache_entries=len(search_cache.ctf.entries))
                    else:
                        raise ValueError(f"Unknown worker command: {command!r}")
                response = {"ok": True, "result": result}
            except (Exception, SystemExit) as error:
                # argparse raises SystemExit on invalid job arguments.  Report
                # that job's failure without discarding the warmed-up worker.
                response = {
                    "ok": False,
                    "error": f"{type(error).__name__}: {error}",
                    "traceback": traceback.format_exc(),
                }
            try:
                sys.stdout.flush()
                sys.stderr.flush()
                connection.send(response)
            except (EOFError, ConnectionError, BrokenPipeError):
                break
