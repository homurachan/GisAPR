#!/usr/bin/env python3
"""Random prescreen -> lowest objectives -> independently calibrated local searches."""
import argparse
from concurrent.futures import ThreadPoolExecutor
from dataclasses import replace
import json
import os
from pathlib import Path
import sys
import time

import numpy as np

import func_v2 as runtime
from func_v2 import GisAPRObjective
from gisapr_multistart import random_points, select_top, evaluate_batch, fixed_pattern_search
from gisapr_runtime_v2 import worker_slots, resolve_script, SEARCH_SCRIPT
from orientation_bank_v1 import atomic_json, positive_int
from test_op_adaptive_pattern_search_v2 import (
    create_parser as base_parser, SearchOptions, parse_bounds, parse_vector, file_digest, run_signature)
from test_op_differential_evolution_v1 import validate_fixed_bank

VERSION='1.1.0'
SCHEMA='GisAPR_multistart_fixed_group_banks_v1'


def create_parser():
    parser=base_parser()
    parser.description=__doc__
    parser.add_argument('--n_rnd_points',type=positive_int,required=True,
                        help='Uniform random points inside Pattern_Bounds, including the calibration point.')
    parser.add_argument('--top_points',type=positive_int,required=True,
                        help='Number of smallest-objective samples to start independent searches.')
    parser.add_argument('--search_method',choices=('pattern','adaptive'),default='adaptive')
    parser.add_argument('--resume',action='store_true',help='Resume latest checkpoint up to Pattern_max_iter per group.')
    for action in parser._actions:
        if action.dest=='Pattern_Bounds':
            action.help='Bounds for random sampling ONLY. Local searches are unbounded.'
        elif action.dest=='Adaptive_max_evals':
            action.help='Per-group actual-call budget including its calibration; 0 unlimited. Prescreen is separate.'
    return parser


def save_checkpoint(path,state,signature):
    path=Path(path); temporary=path.with_name(path.name+'.tmp')
    payload=json.dumps(dict(schema=SCHEMA,version=VERSION,signature=signature,state=state),allow_nan=False)
    with temporary.open('wb') as handle:
        np.savez_compressed(handle,state_json=np.array(payload))
    os.replace(temporary,path)


def load_checkpoint(path,signature):
    with np.load(path,allow_pickle=False) as data:
        payload=json.loads(str(data['state_json'].item()))
    if payload.get('schema')!=SCHEMA or payload.get('version')!=VERSION:
        raise ValueError('Use a MultiStart v1.1.0 checkpoint')
    if payload['signature']!=signature:
        raise ValueError('Inputs/code/settings/output prefix differ from the multistart checkpoint')
    return payload['state']


def calibration(objective,pose,slot):
    result=objective.evaluate(pose,slot,None)
    return dict(fixed_orientations=result.bank,calibration=dict(pose=list(map(float,pose)),
                full_objective=result.value,calls=int(not result.cached),requested=1))


def truncate_history(path,state):
    if not path.exists():
        return
    lines=[]
    if state is not None:
        for line in path.read_text(encoding='utf-8').splitlines():
            try:
                row=json.loads(line)
            except json.JSONDecodeError:
                break
            local=state
            transition_ahead=(row['event']=='rotation_converged_start_translation'
                              and local.get('phase')=='rotation')
            if row['round']<=state['nit'] and not transition_ahead:
                lines.append(line)
    tmp=path.with_suffix('.tmp')
    tmp.write_text(''.join(line+'\n' for line in lines),encoding='utf-8')
    os.replace(tmp,path)


def summaries(directory,state):
    screen=state['prescreen']; rows=[]
    for group in state['groups']:
        local=group.get('search'); cal=group.get('calibration'); bank=group.get('fixed_orientations')
        rows.append(dict(rank=group['rank'],sample_index=group['sample_index']+1,
            starting_pose=group['initial_pose'],prescreen_objective=group['prescreen_objective'],
            initial_full_objective=None if cal is None else cal['full_objective'],
            initial_fixed_objective=None if local is None else local['initial_fun'],
            final_objective=None if local is None else local['fun'],
            final_pose=None if local is None else local['x'],
            rounds=0 if local is None else local['nit'],
            phase=None if local is None else local.get('phase','joint'),
            rotation_result=None if local is None else local.get('rotation_result'),
            objective_calls=local['nfev'] if local is not None else (cal['calls'] if cal else 0),
            bank_sha256=None if bank is None else bank['sha256'],
            stop_reason=group.get('status'),error=group.get('error'),
            directory=str(directory/f'group_{group["rank"]:03d}'),best_fit=group.get('best_fit')))
    atomic_json(directory/'groups_summary.json',dict(stage=state['stage'],groups=rows,
        prescreen_calls=screen['nfev'],total_calls=screen['nfev']+sum(r['objective_calls'] for r in rows),
        order='prescreen rank; group final scores use DIFFERENT fixed orientation banks'))


def main(argv=None):
    parser=create_parser(); args=parser.parse_args(argv); args.optimizer='MultiStart'
    try:
        if args.Pattern_dimensions!=6 or args.top_points>args.n_rnd_points:
            raise ValueError('Require Pattern_dimensions=6 and top_points<=n_rnd_points')
        if args.Pattern_given_initial:
            raise ValueError('This entry samples all starting points randomly; omit Pattern_given_initial')
        if args.resume and args.Pattern_continue:
            raise ValueError('Choose --resume or --Pattern_continue, not both')
        if args.Pattern_continue_more_rounds<0:
            raise ValueError('Additional rounds must be nonnegative')
        lb,ub=parse_bounds(args.Pattern_Bounds,6)
        scales=parse_vector(args.Adaptive_scales,6,'Adaptive_scales')
        mode=args.Adaptive_direction_mode
        if args.search_method=='pattern':
            mode='fixed'; scales=np.ones(6)
        if np.any(scales<=0):
            raise ValueError('Adaptive_scales must be positive')
        opt=SearchOptions(step_size=args.Pattern_stepsize,tol=args.Pattern_tol,shrink=args.Pattern_shrink,
            expand=args.Pattern_expand,max_iter=args.Pattern_max_iter,max_evals=args.Adaptive_max_evals,
            mode=mode,update_every=args.Adaptive_update_every,failure_repolls=args.Adaptive_failure_repolls,
            axis_poll_every=args.Adaptive_axis_poll_every,seed=args.Adaptive_seed,
            max_step=args.Adaptive_max_stepsize,max_workers=args.max_workers,
            rotation_then_translation=args.Pattern_rotation_then_translation)
        opt.validate()
        if opt.max_evals and opt.max_evals<2:
            raise ValueError('Adaptive_max_evals must cover a group calibration and initial fixed score (>=2)')
        for key in ('PDB_NAME','STAR_NAME','ang','fsc_file'):
            if getattr(args,key,None):
                path=Path(getattr(args,key)).expanduser().resolve()
                if not path.is_file():
                    raise ValueError(f'{key} does not exist: {path}')
                setattr(args,key,str(path))
        args.search_script=str(resolve_script(args.search_script))
        if file_digest(args.search_script)!=file_digest(SEARCH_SCRIPT):
            raise ValueError('Use the supplied DE-v1.2.0 v7 search script; omit an old search_script argument')
        root=Path(args.output_name_root).expanduser().resolve(); args.output_name_root=str(root)
        directory=root.with_name(root.name+'MultiStart_run'); slots=worker_slots(args.gpuid)
        signed=argparse.Namespace(**{k:v for k,v in vars(args).items() if k!='resume'})
        signature,provenance=run_signature(signed,runtime)
        resuming=args.resume or args.Pattern_continue
        if args.Pattern_continue_file and not resuming:
            raise ValueError('Pattern_continue_file requires --resume or --Pattern_continue')
        if resuming:
            state=load_checkpoint(args.Pattern_continue_file or directory/'latest.npz',signature)
            config=json.loads((directory/'run_config.json').read_text(encoding='utf-8'))
            if config['signature']!=signature:
                raise ValueError('Run directory signature mismatch')
        else:
            points=random_points((lb,ub),args.n_rnd_points,opt.seed)
            directory.mkdir(parents=True,exist_ok=False)
            atomic_json(directory/'run_config.json',dict(version=VERSION,signature=signature,provenance=provenance,
                argv=sys.argv if argv is None else argv,local_bounds=None,search_method=args.search_method))
            state=dict(stage='prescreen',points=points.tolist(),sampling_bounds=[lb.tolist(),ub.tolist()],
                prescreen=dict(fixed_orientations=None,calibration=None,values=[None]*len(points),
                               nfev=0,requested=0,memo_hits=0),selected_indices=None,groups=[])
        points=np.asarray(state['points'],dtype=float)
        if (points.shape!=(args.n_rnd_points,6) or not np.isfinite(points).all()
                or np.any(points<lb) or np.any(points>ub) or state['sampling_bounds']!=[lb.tolist(),ub.tolist()]):
            raise ValueError('Invalid saved sampling points/bounds')
        if len(state['prescreen']['values'])!=len(points):
            raise ValueError('Invalid saved prescreen values')
    except (ValueError,TypeError,OSError,ImportError) as exc:
        parser.error(str(exc))
    lock=directory/'RUNNING.lock'
    try:
        with lock.open('x',encoding='utf-8') as handle:
            handle.write(json.dumps(dict(pid=os.getpid(),started=time.time()))+'\n')
    except FileExistsError:
        parser.error(f'Run lock exists: {lock}. Verify the original process has stopped before removing a stale lock.')
    latest=directory/'latest.npz'
    def save():
        save_checkpoint(latest,state,signature)
    def progress(label):
        return lambda done,total,elapsed:print(f'{label}: completed={done}/{total}, elapsed={elapsed:.1f}s',flush=True)
    print(f'GisAPR MultiStart {VERSION}: random={args.n_rnd_points}, top={args.top_points}, '
          f'method={args.search_method}, K={args.keep_orientations}\n'
          f'Pattern_Bounds apply only to sampling. Local searches are unbounded.\nRun directory: {directory}',flush=True)
    try:
        save()
        runtime.prepare_workers(args)
        with ThreadPoolExecutor(max_workers=opt.max_workers) as executor:
            screen_dir=directory/'prescreen'; screen_dir.mkdir(exist_ok=True)
            objective=GisAPRObjective(args,screen_dir)
            screen=state['prescreen']
            try:
                if resuming and screen['calibration'] is not None and objective.compact and not objective.store.path.is_file():
                    raise ValueError('Keep prescreen/evaluation_cache.sqlite3 with the checkpoint')
                if screen['calibration'] is None:
                    print(f'Prescreen: calibrating once at random point 1: {points[0].tolist()}',flush=True)
                    cal=calibration(objective,points[0],slots[0]); screen.update(cal)
                    screen['nfev']+=cal['calibration']['calls']; screen['requested']+=1
                    screen['memo_hits']+=1-cal['calibration']['calls']; save()
                validate_fixed_bank(screen['fixed_orientations'],objective)
                bank=screen['fixed_orientations']
                atomic_json(screen_dir/'fixed_orientations.json',bank)
                missing=[i for i,v in enumerate(screen['values']) if v is None]
                for offset in range(0,len(missing),opt.max_workers):
                    ids=missing[offset:offset+opt.max_workers]
                    jobs={i:(points[i],slots[j%len(slots)]) for j,i in enumerate(ids)}
                    results=evaluate_batch(objective,jobs,bank,executor,progress('Prescreen'))
                    for i,result in results.items():
                        screen['values'][i]=result.value; screen['nfev']+=int(not result.cached)
                        screen['requested']+=1; screen['memo_hits']+=int(result.cached)
                    save()
                    print(f'Prescreen: scored={sum(v is not None for v in screen["values"])}/{len(points)}, '
                          f'total_calls={screen["nfev"]}',flush=True)
                selected=select_top(screen['values'],args.top_points)
                if state['selected_indices'] is not None and state['selected_indices']!=selected:
                    raise ValueError('Saved selected points disagree with prescreen ranking')
                if state['selected_indices'] is None:
                    state['selected_indices']=selected
                    state['groups']=[dict(rank=rank,sample_index=i,initial_pose=points[i].tolist(),
                        prescreen_objective=screen['values'][i],status='pending',calibration=None,
                        fixed_orientations=None,search=None,iteration_limit=opt.max_iter)
                        for rank,i in enumerate(selected,1)]
                if len(state['groups'])!=len(selected) or [g['sample_index'] for g in state['groups']]!=selected:
                    raise ValueError('Invalid selected-group checkpoint')
                order=select_top(screen['values'],len(points))
                lines=['rank\tsample_index\tselected\tobjective\trx\try\trz\ttx\tty\ttz\n']
                for rank,i in enumerate(order,1):
                    lines.append('\t'.join(map(str,[rank,i+1,int(i in selected),screen['values'][i],*points[i]]))+'\n')
                (screen_dir/'ranked_points.tsv').write_text(''.join(lines),encoding='utf-8')
                state['stage']='local_search'; save(); summaries(directory,state)
            finally:
                objective.close()
            for group in state['groups']:
                rank=group['rank']; label=f'Group {rank}/{len(state["groups"])}'
                group_dir=directory/f'group_{rank:03d}'; group_dir.mkdir(exist_ok=True)
                if group['status']=='invalid_calibration':
                    continue
                if args.Pattern_continue:
                    group['iteration_limit']=(group['search']['nit'] if group['search'] else 0)+args.Pattern_continue_more_rounds
                else:
                    group['iteration_limit']=max(group['iteration_limit'],opt.max_iter)
                group_opt=replace(opt,seed=opt.seed+rank,max_iter=group['iteration_limit'])
                objective=GisAPRObjective(args,group_dir)
                try:
                    if resuming and group['calibration'] is not None and objective.compact and not objective.store.path.is_file():
                        raise ValueError(f'Keep {group_dir}/evaluation_cache.sqlite3 with the checkpoint')
                    if group['calibration'] is None:
                        print(f'{label}: calibrating at selected point {group["sample_index"]+1}: '
                              f'{group["initial_pose"]}',flush=True)
                        group.update(calibration(objective,group['initial_pose'],slots[0])); save()
                    try:
                        validate_fixed_bank(group['fixed_orientations'],objective)
                    except ValueError as exc:
                        group['status']='invalid_calibration'; group['error']=str(exc)
                        save(); summaries(directory,state)
                        print(f'{label}: cannot start: {exc}',flush=True)
                        continue
                    bank=group['fixed_orientations']
                    atomic_json(group_dir/'fixed_orientations.json',bank)
                    history=group_dir/'rounds.jsonl'
                    truncate_history(history,group['search'])
                    def on_round(current,row):
                        group['search']=current; group['status']='running'; save()
                        if args.Adaptive_keep_checkpoints:
                            save_checkpoint(group_dir/f'round_{current["nit"]:06d}.npz',state,signature)
                        with history.open('a',encoding='utf-8') as handle:
                            handle.write(json.dumps(row,allow_nan=False)+'\n')
                        if row['event']=='rotation_converged_start_translation':
                            print(f'{label}: rotation converged at round {current["nit"]}; '
                                  f'starting translation with step={current["step"]:.6g}; fixed bank unchanged.',flush=True)
                            return
                        print(f'{label}, round {current["nit"]} [{row["phase"]}]: best={current["fun"]:.12g}, '
                              f'step={current["step"]:.6g}, called={row["called"]}, '
                              f'group_calls={current["nfev"]}, event={row["event"]}, wall={row["wall_s"]:.2f}s',flush=True)
                    cal=group['calibration']
                    local=fixed_pattern_search(objective,group['initial_pose'],bank,scales,group_opt,
                        slots=slots,state=group['search'],initial_calls=cal['calls'],initial_requests=cal['requested'],
                        executor=executor,on_round=on_round,on_progress=progress(label))
                    group['search']=local; group['status']=local['stop_reason']; save()
                    name='Pattern' if args.search_method=='pattern' else 'Adaptive'
                    objective.export_best(local,group_dir/'result_',name,bank=bank)
                    info=json.loads((group_dir/f'result_{name}_BEST_FIT.json').read_text(encoding='utf-8'))
                    group['best_fit']=info['best_fit_pdb']; save(); summaries(directory,state)
                finally:
                    objective.close()
        state['stage']='complete'; save(); summaries(directory,state)
        print(f'MultiStart finished. Per-group results: {directory}/groups_summary.json\n'
              'Groups have separate fixed orientation banks; summary order is prescreen rank.',flush=True)
    finally:
        try:
            runtime.shutdown_workers(args)
        finally:
            lock.unlink(missing_ok=True)


if __name__=='__main__':
    main()
