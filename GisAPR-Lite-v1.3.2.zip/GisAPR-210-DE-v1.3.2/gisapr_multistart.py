"""Uniform prescreening and unbounded, fixed-bank pattern polling (GPL-3.0).

Direction adaptation follows test_op_adaptive_pattern_search_v2; this variant
never performs full candidate verification, refreshes a bank, or clips a poll.
"""
from concurrent.futures import ThreadPoolExecutor, wait, FIRST_COMPLETED
from dataclasses import asdict
import copy
import math
import time

import numpy as np

from func_v2 import pose_key
from orientation_bank_v1 import check_bank
from test_op_adaptive_pattern_search_v2 import SearchOptions, choose_basis, poll_gradient
from gisapr_search_schedule import (initialize_schedule, validate_schedule,
                                    active_coordinates, phase_round, advance_to_translation)


def random_points(bounds, count, seed):
    lb,ub=(np.asarray(v,dtype=float) for v in bounds)
    if count < 1 or seed < 0 or lb.shape != (6,) or ub.shape != (6,):
        raise ValueError('Require n_rnd_points>=1, seed>=0 and six bounds')
    if not np.isfinite([lb,ub]).all() or np.any(lb>=ub) or not np.isfinite(ub-lb).all():
        raise ValueError('Sampling bounds must have finite, positive widths')
    return np.random.default_rng(seed).uniform(lb,ub,size=(count,6))


def select_top(values, count):
    values=np.asarray(values,dtype=float)
    if values.ndim != 1 or not np.isfinite(values).all() or not 1 <= count <= len(values):
        raise ValueError('Require finite prescreen objectives and 1<=top_points<=n_rnd_points')
    # Preserve sample order for exact score ties; no clustering or diversity filter.
    return np.argsort(values,kind='stable')[:count].tolist()


def evaluate_batch(objective, jobs, bank, executor, on_progress=None):
    """jobs maps a stable identifier to (pose, worker slot)."""
    futures={executor.submit(objective.evaluate,pose,slot,bank):key
             for key,(pose,slot) in jobs.items()}
    pending=set(futures); results={}; started=time.monotonic(); report_at=started+60.
    while pending:
        done,pending=wait(pending,timeout=max(0.,report_at-time.monotonic()),return_when=FIRST_COMPLETED)
        for future in done:
            result=future.result()
            if not math.isfinite(result.value):
                raise ValueError('Nonfinite candidate objective')
            results[futures[future]]=result
        if time.monotonic() >= report_at:
            if on_progress:
                on_progress(len(results),len(jobs),time.monotonic()-started)
            report_at=time.monotonic()+60.
    return {key:results[key] for key in jobs}


def search_signature(opt):
    values=asdict(opt)
    for key in ('max_iter','max_evals','max_workers'):
        values.pop(key)
    return values


def fixed_pattern_search(objective, x0, bank, scales, options=None, *, slots=None,
                         state=None, initial_calls=0, initial_requests=0,
                         executor=None, on_round=None, on_progress=None):
    """Unbounded joint 6D or sequential 3+3D search on ONE immutable bank.

    x0 is always relative to the original input PDB. An initial full calibration
    is performed by the caller; even x0 is then scored with the same bank as polls.
    """
    opt=options or SearchOptions()
    opt.validate()
    x0=np.asarray(x0,dtype=float); scales=np.asarray(scales,dtype=float)
    if x0.shape!=(6,) or scales.shape!=(6,) or not np.isfinite([x0,scales]).all() or np.any(scales<=0):
        raise ValueError('Require six finite initial coordinates and positive scales')
    if initial_calls<0 or initial_requests<initial_calls:
        raise ValueError('Invalid calibration counters')
    check_bank(bank,objective.context)
    if bank['pose']!=x0.tolist():
        raise ValueError('The group bank must be calibrated at this group starting point')
    bank=copy.deepcopy(bank)
    slots=slots or [None]
    rng=np.random.default_rng(opt.seed)
    if state is None:
        initial=objective.evaluate(x0,slots[0],bank)
        if not math.isfinite(initial.value):
            raise ValueError('Nonfinite starting objective')
        calls=initial_calls+int(not initial.cached)
        if opt.max_evals and calls>opt.max_evals:
            raise ValueError('Per-group budget must cover calibration and initial fixed score')
        state=dict(x=x0.tolist(),fun=initial.value,initial_pose=x0.tolist(),initial_fun=initial.value,
                   bank_sha256=bank['sha256'],bounds=None,scales=scales.tolist(),
                   step=opt.step_size,nit=0,nfev=calls,requested=initial_requests+1,
                   memo_hits=initial_requests+1-calls,basis=np.eye(6).tolist(),anchor=x0.tolist(),
                   accepted_in_stage=0,failed_at_step=0,rng=rng.bit_generator.state,
                   search_settings=search_signature(opt),score_scope='fixed_topk')
        initialize_schedule(state,opt)
        if on_round:
            on_round(state,dict(round=0,event='initial',fun=state['fun'],pose=state['x'],
                                phase=state.get('phase','joint'),phase_round=0,
                                called=int(not initial.cached),nfev=calls,step=state['step'],
                                bank_sha256=bank['sha256'],wall_s=0.))
    else:
        if (state['bounds'] is not None or state['initial_pose']!=x0.tolist()
                or state['bank_sha256']!=bank['sha256'] or state['scales']!=scales.tolist()
                or state['search_settings']!=search_signature(opt)):
            raise ValueError('Group checkpoint settings/bank/starting point mismatch')
        if (np.shape(state['x'])!=(6,) or np.shape(state['anchor'])!=(6,)
                or not np.isfinite([state['x'],state['anchor']]).all()
                or not math.isfinite(state['fun']) or not math.isfinite(state['step']) or state['step']<=0):
            raise ValueError('Invalid group checkpoint incumbent/step')
        validate_schedule(state,opt,6)
        size=len(active_coordinates(state,6))
        q=np.asarray(state['basis'])
        if q.shape!=(size,size) or not np.allclose(q@q.T,np.eye(size),atol=1e-10):
            raise ValueError('Invalid group checkpoint basis')
        if min(state['nit'],state['nfev'],state['requested'],state['memo_hits'])<0:
            raise ValueError('Invalid group checkpoint counters')
        rng.bit_generator.state=state['rng']
    owned=executor is None
    if owned:
        executor=ThreadPoolExecutor(max_workers=opt.max_workers)
    reason='iteration_limit'
    try:
        while True:
            advance_to_translation(state,opt,on_round)
            if state['step']<=opt.tol:
                reason='step_tolerance'; break
            if state['nit']>=opt.max_iter:
                break
            x=np.asarray(state['x']); step=state['step']; learned=np.asarray(state['basis'])
            active=active_coordinates(state,6)
            axis_poll=(opt.mode=='fixed' or (state['failed_at_step']==0 and opt.axis_poll_every>0
                                           and (phase_round(state)+1)%opt.axis_poll_every==0))
            basis=np.eye(len(active)) if axis_poll else learned
            # Deliberately unbounded: sampling Pattern_Bounds never enter here.
            candidates=np.tile(x,(2*len(active),1))
            candidates[:,active]=x[active]+step*np.vstack((basis,-basis))*scales[active]
            if not np.isfinite(candidates).all():
                raise ValueError('Unbounded poll overflow; reduce step/expansion or set Adaptive_max_stepsize')
            keys=[pose_key(p) for p in candidates]; current_key=pose_key(x)
            jobs={}
            for i,key in enumerate(keys):
                if key!=current_key and key not in jobs:
                    jobs[key]=(candidates[i].copy(),slots[i%len(slots)])
            if not jobs:
                reason='numerical_resolution'; break
            misses=sum(not objective.cached(p,bank) for p,_ in jobs.values())
            if opt.max_evals and state['nfev']+misses>opt.max_evals:
                reason='evaluation_limit_before_full_poll'; break
            started=time.monotonic()
            results=evaluate_batch(objective,jobs,bank,executor,on_progress)
            best_key=min(results,key=lambda key:results[key].value)
            old_fun=state['fun']; accepted=results[best_key].value<old_fun
            values=np.asarray([old_fun if key==current_key else results[key].value for key in keys])
            gradient=poll_gradient(x[active],candidates[:,active],values,basis,step,scales[active])
            hits=sum(r.cached for r in results.values()); calls=len(results)-hits
            state['nfev']+=calls; state['requested']+=len(results); state['memo_hits']+=hits
            direction_event='unchanged'
            if accepted:
                state['x']=jobs[best_key][0].tolist(); state['fun']=results[best_key].value
                state['step']*=opt.expand
                if opt.max_step:
                    state['step']=min(state['step'],opt.max_step)
                state['failed_at_step']=0; state['accepted_in_stage']+=1; event='accepted'
                if opt.mode!='fixed' and state['accepted_in_stage']>=opt.update_every:
                    displacement=((np.asarray(state['x'])-state['anchor'])/scales)[active]
                    new,direction_event=choose_basis(opt.mode,displacement,state['accepted_in_stage'],gradient,learned,rng)
                    state['basis']=new.tolist(); state['anchor']=state['x'].copy(); state['accepted_in_stage']=0
            elif opt.mode!='fixed' and state['failed_at_step']<opt.failure_repolls:
                displacement=((x-state['anchor'])/scales)[active]
                new,direction_event=choose_basis(opt.mode,displacement,state['accepted_in_stage'],gradient,learned,rng)
                state['basis']=new.tolist(); state['failed_at_step']+=1
                if direction_event.startswith(('success_displacement','gradient')):
                    state['anchor']=state['x'].copy(); state['accepted_in_stage']=0
                event='repoll_same_step'
            else:
                state['step']*=opt.shrink; state['failed_at_step']=0; event='shrink'
            if not math.isfinite(state['step']) or state['step']<=0:
                raise ValueError('Pattern step overflow/underflow')
            state['nit']+=1; state['rng']=rng.bit_generator.state
            state['stop_reason']=('rotation_converged' if opt.rotation_then_translation and state['phase']=='rotation'
                                  else 'step_tolerance') if state['step']<=opt.tol else 'iteration_limit'
            if on_round:
                on_round(state,dict(round=state['nit'],event=event,accepted=accepted,
                    phase=state.get('phase','joint'),phase_round=phase_round(state),active_coordinates=active.tolist(),
                    direction_update=direction_event,axis_poll=axis_poll,fun=state['fun'],
                    improvement=old_fun-state['fun'],pose=state['x'].copy(),evaluated_center=x.tolist(),
                    step_used=step,next_step=state['step'],called=calls,nfev=state['nfev'],memo_hits=hits,
                    bank_sha256=bank['sha256'],full_poll=False,wall_s=time.monotonic()-started))
        if state['step']<=opt.tol:
            reason='step_tolerance'
        state['stop_reason']=reason
        return state
    finally:
        if owned:
            executor.shutdown(wait=True)
