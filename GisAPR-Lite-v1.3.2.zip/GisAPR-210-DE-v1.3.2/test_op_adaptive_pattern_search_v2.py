#!/usr/bin/env python3
"""GisAPR fixed/adaptive pattern polling with per-particle Top-K projection screening.

Derived from the v210 adaptive orthogonal polling implementation (GPL-3.0).
Screen scores estimate poll directions. Only full scores can update the incumbent.
"""
from __future__ import annotations

import argparse
import ast
import concurrent.futures
import hashlib
import json
import math
import os
from pathlib import Path
import sys
import time
from dataclasses import dataclass

import numpy as np

from orientation_bank_v1 import atomic_json, check_bank, positive_int
from func_v2 import GisAPRObjective, pose_key, particles
from gisapr_search_schedule import (initialize_schedule, validate_schedule,
                                    active_coordinates, phase_round, advance_to_translation)

VERSION = '1.3.2'
SCHEMA = 'GisAPR_topk_poll_v1'

def create_legacy_parser():
	parser = argparse.ArgumentParser(description="Pattern Refine Execution")
	parser.add_argument("--max_workers", type=int, default=3)
	parser.add_argument("--PDB_NAME", type=str, required=True)
	parser.add_argument("--STAR_NAME", type=str, required=True)
	parser.add_argument("--rotate_chain", type=str, required=True)
	parser.add_argument("--output_name_root", type=str, default="output")
	parser.add_argument("--gpuid", type=str, default="0")
	parser.add_argument("--ang", type=str, default=os.path.join(os.path.dirname(os.path.abspath(__file__)), "c1_3deg_remove_rotLzero_200kV.star"))
	parser.add_argument("--boxsize", type=int, default=256)
	parser.add_argument("--apix", type=float, default=1.58)
	parser.add_argument("--apix_PDB", type=float, default=1.58)
	parser.add_argument("--newboxsize", type=int, default=160)
	parser.add_argument("--search_script", type=str, default=os.path.join(os.path.dirname(os.path.abspath(__file__)), "test1_with_isspa_weight_varingKK_search_translation_also_v7_torch_optimized_standalone.py"))
	parser.add_argument("--fsc_file", type=str, default=None, help="Optional FSC curve; omit to use uniform Fourier weights.")
	parser.add_argument("--skip_geometric_restraint", action="store_true", help="Skip geometric restraint calculation and its score penalty.")
	parser.add_argument("--transRange", type=int, default=0)
	parser.add_argument("--voltage", type=float, default=300.0)
	parser.add_argument("--cs", type=float, default=2.7)
	parser.add_argument("--psiStep", type=int, default=3)
	parser.add_argument("--kk", type=int, default=3)
	parser.add_argument("--do_local_search", action="store_true")
	parser.add_argument("--local_stepsize", type=float, default=30)
	parser.add_argument("--do_ignoreFSC", action="store_true")
	parser.add_argument("--yflip", action="store_true")
	parser.add_argument("--doEnableGpuProj", action='store_true')
	parser.add_argument("--doSplitDiffGpu", action='store_true', help="If enabled, wrap_to_search will use different gpuid. The inital gpuid is provided by --gpuid. default = False")
	parser.add_argument("--SplitParticles", type=int, default=1, help="Split the starfile into these sections. Default = 1")
	parser.add_argument("--do_run_CC", action="store_true")
	parser.add_argument("--do_simple_sum", action="store_true")
	parser.add_argument("--maskRadius", type=int, default=110)
	parser.add_argument("--Geometric_restrain_Scaling_Factor", type=float, default=1.0)
	parser.add_argument("--chain_MASS_in_residues", type=int, default=275)
	parser.add_argument("--MAXIUM_ALLOWED_overlapped_pixels", type=int, default=300)
	parser.add_argument("--MAX_MinDistance_Allowed", type=float, default=30.)
	parser.add_argument("--Pattern_Bounds", type=str, default="(-15,15),(-15,15),(-15,15),(-20,20),(-20,20),(-20,20)")
	parser.add_argument("--Pattern_dimensions", type=int, default=6)
	parser.add_argument("--Pattern_given_initial",action="store_true")
	parser.add_argument("--Pattern_initial",type=str, default="[10,10,10,10,10,10]")
	parser.add_argument("--Pattern_stepsize", type=float, default=1.0)
	parser.add_argument("--Pattern_tol", type=float, default=0.01)
	parser.add_argument("--Pattern_max_iter", type=int, default=500)
	parser.add_argument("--Pattern_shrink", type=float, default=0.5)
	parser.add_argument("--Pattern_expand", type=float, default=1.2)
	parser.add_argument("--Pattern_continue", "--continue_run", action="store_true")
	parser.add_argument("--Pattern_continue_file", "--continue_file", type=str, default=None)
	parser.add_argument("--Pattern_continue_more_rounds", "--continue_more_rounds", type=int, default=20, help="Additional completed poll iterations after the checkpoint.")
	from gisapr_options_v2 import add_runtime_options
	return add_runtime_options(parser)


def create_parser():
    parser = create_legacy_parser()
    parser.add_argument('--Pattern_rotation_then_translation', action='store_true',
                        help='Optimize rotations to Pattern_tol with translations fixed, then reset step/directions and optimize translations with rotations fixed. One pass; shared iteration/call budgets. Default: joint 6D.')
    parser.add_argument('--keep-orientations', type=positive_int, default=3,
                        help='Number of distinct rot/tilt directions per particle during screening (default 3).')
    parser.set_defaults(do_local_search=True)
    parser.description = __doc__
    g = parser.add_argument_group('Adaptive direction search (new options)')
    g.add_argument('--Adaptive_direction_mode', choices=['success', 'hybrid', 'gradient', 'random', 'fixed'], default='success',
                   help='success: cumulative accepted displacement; hybrid: displacement then gradient fallback; gradient: finite-difference direction; random: random bases; fixed: coordinate baseline.')
    g.add_argument('--Adaptive_update_every', type=int, default=4,
                   help='Update learned directions after this many accepted polls (default: 4).')
    g.add_argument('--Adaptive_failure_repolls', type=int, default=1,
                   help='Extra differently oriented polls at the same center/step before shrinking (default: 1; fixed mode always shrinks immediately). Each poll counts as a Pattern iteration.')
    g.add_argument('--Adaptive_scales', default='[1,1,1,1,1,1]',
                   help='Six positive physical units per normalized coordinate: three degrees, then three angstroms.')
    g.add_argument('--Adaptive_axis_poll_every', type=int, default=5,
                   help='Use physical coordinate axes every N polls for coverage, including boundaries; 0 disables (default: 5).')
    g.add_argument('--Adaptive_seed', type=int, default=0,
                   help='Reproducible initialization/rotation seed; RNG state is checkpointed.')
    g.add_argument('--Adaptive_max_evals', type=int, default=0,
                   help='Maximum cumulative calls to the objective, including initial point and geometry rejection; 0 means unlimited. Exact memo hits do not count. Never starts an unaffordable full poll.')
    g.add_argument('--Adaptive_max_stepsize', type=float, default=0.,
                   help='Optional upper cap on normalized step size; 0 means no cap.')
    g.add_argument('--Adaptive_keep_checkpoints', action='store_true',
                   help='Also keep a numbered checkpoint after every complete poll; latest.npz is always saved.')
    return parser


def parse_vector(text, n, name):
    try:
        values = np.asarray(ast.literal_eval(text), dtype=float)
    except (ValueError, SyntaxError, TypeError) as exc:
        raise ValueError(f'{name} must be a list of {n} finite numbers') from exc
    if values.shape != (n,) or not np.isfinite(values).all():
        raise ValueError(f'{name} must be a list of {n} finite numbers')
    return values


def parse_bounds(text, n):
    try:
        values = np.asarray(ast.literal_eval('[' + text + ']'), dtype=float)
    except (ValueError, SyntaxError, TypeError) as exc:
        raise ValueError('Pattern_Bounds must contain (lower,upper) pairs') from exc
    if values.shape == (1, 2):
        values = np.repeat(values, n, axis=0)
    if values.shape != (n, 2) or not np.isfinite(values).all():
        raise ValueError(f'Pattern_Bounds needs one or {n} finite pairs')
    if np.any(values[:, 0] >= values[:, 1]):
        raise ValueError('Every bound must have lower < upper')
    return values[:, 0], values[:, 1]


def save_checkpoint(path, state, signature):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + '.tmp')
    payload = json.dumps({'schema': SCHEMA, 'version': VERSION, 'signature': signature,
                          'state': state}, allow_nan=False, separators=(',', ':'))
    with temporary.open('wb') as handle:
        np.savez_compressed(handle, state_json=np.array(payload))
    os.replace(temporary, path)


def load_checkpoint(path, signature=None):
    with np.load(path, allow_pickle=False) as data:
        if 'state_json' not in data:
            raise ValueError('A Top-K v1 checkpoint is required. Use Pattern_initial to start from a legacy pose.')
        payload = json.loads(str(data['state_json'].item()))
    if payload.get('schema') != SCHEMA or payload.get('version') != VERSION:
        raise ValueError('Unsupported adaptive checkpoint schema/version')
    if signature is not None and payload['signature'] != signature:
        raise ValueError('Checkpoint inputs, scoring settings, output root, or adaptive settings differ. Reuse the original command and add continuation flags; only budgets/workers/logging may change.')
    return payload['state']


@dataclass
class SearchOptions:
    step_size: float = 1.
    tol: float = .01
    shrink: float = .5
    expand: float = 1.2
    max_iter: int = 500
    max_evals: int = 0
    mode: str = 'success'
    update_every: int = 4
    failure_repolls: int = 1
    axis_poll_every: int = 5
    seed: int = 0
    max_step: float = 0.
    max_workers: int = 3
    rotation_then_translation: bool = False

    def validate(self):
        if not all(math.isfinite(v) for v in [self.step_size, self.tol, self.shrink, self.expand, self.max_step]):
            raise ValueError('Step/tolerance factors must be finite')
        if self.step_size <= 0 or self.tol <= 0 or not 0 < self.shrink < 1 or self.expand < 1:
            raise ValueError('Require step>0, tol>0, 0<shrink<1 and expand>=1')
        if self.max_step < 0 or (self.max_step and self.max_step < self.step_size):
            raise ValueError('Adaptive_max_stepsize must be 0 or >= Pattern_stepsize')
        if self.max_iter < 0 or self.max_evals < 0 or self.max_workers < 1 or self.update_every < 1:
            raise ValueError('Budgets must be nonnegative; workers/update interval must be positive')
        if self.failure_repolls < 0 or self.axis_poll_every < 0 or self.seed < 0:
            raise ValueError('Repoll count, axis interval and seed must be nonnegative')
        if self.mode not in ['success', 'hybrid', 'gradient', 'random', 'fixed']:
            raise ValueError('Unknown direction mode')


def random_basis(n, rng):
    q, r = np.linalg.qr(rng.normal(size=(n, n)))
    signs = np.where(np.diag(r) < 0, -1., 1.)
    return (q * signs).T


def complete_basis(first, previous, rng):
    """Orthonormal ROW basis containing the requested first direction."""
    n = len(first)
    norm = np.linalg.norm(first)
    if not np.isfinite(norm) or norm < 1e-14:
        return random_basis(n, rng)
    rows = [np.asarray(first, dtype=float) / norm]
    for candidate in list(previous) + list(random_basis(n, rng)):
        v = np.array(candidate, dtype=float, copy=True)
        # Reorthogonalize to handle nearly dependent accumulated movements.
        for _ in range(2):
            for q in rows:
                v -= np.dot(v, q) * q
        norm = np.linalg.norm(v)
        if norm > 1e-10:
            rows.append(v / norm)
        if len(rows) == n:
            break
    if len(rows) != n:
        raise RuntimeError('Could not form a full-rank search basis')
    return np.asarray(rows)


def poll_gradient(center, candidates, values, basis, step, scales):
    """Optional central-difference MINIMIZATION gradient, at the OLD center.

    Require an entire symmetric, unclipped poll. Never infer a derivative from
    a boundary-clipped stencil. This is a finite-scale hint, not an exact gradient.
    """
    expected = center + step * np.vstack((basis, -basis)) * scales
    if not np.array_equal(candidates, expected):
        return None
    n = len(center)
    derivatives = (values[:n] - values[n:]) / (2 * step)
    g = derivatives @ basis
    return g if np.isfinite(g).all() and np.linalg.norm(g) > 1e-14 else None


def choose_basis(mode, displacement, accepted_count, gradient, old, rng):
    if mode == 'fixed':
        return np.eye(len(old)), 'fixed'
    if mode == 'random':
        return random_basis(len(old), rng), 'random'
    direction = None
    reason = 'random_fallback'
    if mode == 'gradient' and gradient is not None:
        direction, reason = -gradient, 'gradient'
    elif accepted_count >= 2 and np.linalg.norm(displacement) > 1e-12:
        direction, reason = displacement, 'success_displacement'
    elif mode == 'hybrid' and gradient is not None:
        direction, reason = -gradient, 'gradient_fallback'
    if direction is None:
        return random_basis(len(old), rng), reason
    new = complete_basis(direction, old, rng)
    # Reordering/sign-flipping the old axes is not a genuine new direction set.
    if np.all(np.max(np.abs(new @ old.T), axis=1) > 1 - 1e-10):
        new = complete_basis(direction, random_basis(len(old), rng), rng)
        reason += '+rotated_complement'
    return new, reason


def adaptive_search(objective, x0, bounds, scales, options=None, *, slots=None,
                    state=None, on_round=None, metrics=None):
    """Minimize objective(pose, slot). Resume state is mutated only by this thread.

    Callback runs at initialization and after complete polls. Cached evaluations
    keep their exact pose; candidate ordering is deterministic under parallelism.
    max_iter is a cumulative completed-poll limit, including failure repolls.
    """
    opt = options or SearchOptions()
    opt.validate()
    x0 = np.asarray(x0, dtype=float)
    n = len(x0)
    if opt.rotation_then_translation and n != 6:
        raise ValueError('Rotation-then-translation search requires a six-component pose')
    lb, ub = (np.asarray(b, dtype=float) for b in bounds)
    scales = np.asarray(scales, dtype=float)
    if any(a.shape != (n,) for a in (x0, lb, ub, scales)) or not all(np.isfinite(a).all() for a in (x0, lb, ub, scales)):
        raise ValueError('Initial pose, bounds and scales must be equally sized finite vectors')
    if np.any(lb >= ub) or np.any(scales <= 0):
        raise ValueError('Bounds must be ordered and scales strictly positive')
    slots = slots or [None]
    rng = np.random.default_rng(opt.seed)
    if state is None:
        x = np.clip(x0, lb, ub)
        initial = objective.evaluate(x, slots[0])
        state = dict(x=x.tolist(), fun=initial.value, orientations=initial.bank, step=opt.step_size,
                     nit=0, nfev=1, requested=1, memo_hits=0, basis=np.eye(n).tolist(),
                     anchor=x.tolist(), accepted_in_stage=0, failed_at_step=0, rng=rng.bit_generator.state,
                     bounds=[lb.tolist(), ub.tolist()], scales=scales.tolist())
        initialize_schedule(state, opt)
        if on_round:
            on_round(state, dict(round=0, event='initial', phase=state.get('phase', 'joint'),
                                 phase_round=0, fun=initial.value, pose=x.tolist(), nfev=1))
    else:
        if not np.array_equal(state['bounds'], [lb, ub]) or not np.array_equal(state['scales'], scales):
            raise ValueError('Checkpoint bounds/scales mismatch')
        if np.asarray(state['x']).shape != (n,) or not np.isfinite(state['fun']):
            raise ValueError('Invalid checkpoint incumbent')
        validate_schedule(state, opt, n)
        size = len(active_coordinates(state, n))
        q = np.asarray(state['basis'])
        if q.shape != (size, size) or not np.allclose(q @ q.T, np.eye(size), atol=1e-10):
            raise ValueError('Invalid checkpoint basis')
        rng.bit_generator.state = state['rng']
    if state['orientations'] is not None:
        check_bank(state['orientations'], objective.context)
        if state['orientations']['pose'] != state['x']:
            raise ValueError('Checkpoint bank belongs to another center')
    reason = 'iteration_limit'
    with concurrent.futures.ThreadPoolExecutor(max_workers=opt.max_workers) as executor:
        while True:
            advance_to_translation(state, opt, on_round)
            if state['step'] <= opt.tol:
                reason = 'step_tolerance'
                break
            if state['nit'] >= opt.max_iter:
                break
            x = np.asarray(state['x'])
            active = active_coordinates(state, n)
            step = state['step']
            learned = np.asarray(state['basis'])
            axis_poll = opt.mode == 'fixed' or (state['failed_at_step'] == 0 and opt.axis_poll_every > 0 and (phase_round(state) + 1) % opt.axis_poll_every == 0)
            basis = np.eye(len(active)) if axis_poll else learned
            candidates = np.tile(x, (2 * len(active), 1))
            candidates[:, active] = np.clip(x[active] + step * np.vstack((basis, -basis)) * scales[active], lb[active], ub[active])
            keys = [pose_key(p) for p in candidates]
            current_key = pose_key(x)
            jobs = {}
            for i, key in enumerate(keys):
                if key != current_key and key not in jobs:
                    jobs[key] = (candidates[i].copy(), slots[i % len(slots)])
            # A failed shrink crossing tolerance requires a full poll. Likewise,
            # a geometry-rejected center has no orientations with which to screen.
            last_repoll = opt.mode == 'fixed' or state['failed_at_step'] >= opt.failure_repolls
            certify = last_repoll and step * opt.shrink <= opt.tol
            bank = None if certify else state['orientations']
            if opt.max_evals:
                budget = sum(not objective.cached(pose, bank) for pose, _ in jobs.values())
                if bank is not None:
                    full_misses = sum(not objective.cached(pose, None) for pose, _ in jobs.values())
                    budget += min(2, full_misses)
                if state['nfev'] + budget > opt.max_evals:
                    reason = 'evaluation_limit_before_full_poll'
                    break
            before = metrics() if metrics else {}
            started = time.perf_counter()
            def batch(chosen, constraint):
                if getattr(objective, 'batch_enabled', False):
                    results = objective.evaluate_many([jobs[key][0] for key in chosen],
                                                      [jobs[key][1] for key in chosen], constraint)
                    return dict(zip(chosen, results))
                def evaluate(key):
                    pose, slot = jobs[key]
                    return objective.evaluate(pose, slot, constraint)
                return dict(zip(chosen, executor.map(evaluate, chosen)))

            first = batch(list(jobs), bank)
            shortlist = sorted(first, key=lambda key: first[key].value)[:2]
            verified = first if bank is None else batch(shortlist, None)
            best_key = min(verified, key=lambda key: verified[key].value) if verified else None
            old_fun = state['fun']
            accepted = best_key is not None and verified[best_key].value < old_fun
            # Form finite differences only from the internally consistent first pass.
            values = np.array([old_fun if key == current_key else first[key].value for key in keys])
            gradient = poll_gradient(x[active], candidates[:, active], values, basis, step, scales[active])
            calls = len(first) + (len(verified) if bank is not None else 0)
            hits = sum(r.cached for r in first.values())
            if bank is not None:
                hits += sum(r.cached for r in verified.values())
            state['nfev'] += calls - hits
            state['requested'] += calls
            state['memo_hits'] += hits
            direction_event = 'unchanged'
            if accepted:
                state['x'] = jobs[best_key][0].tolist()
                state['fun'] = verified[best_key].value
                state['orientations'] = verified[best_key].bank
                state['step'] *= opt.expand
                if opt.max_step:
                    state['step'] = min(state['step'], opt.max_step)
                state['failed_at_step'] = 0
                state['accepted_in_stage'] += 1
                event = 'accepted'
                if opt.mode != 'fixed' and state['accepted_in_stage'] >= opt.update_every:
                    displacement = ((np.asarray(state['x']) - state['anchor']) / scales)[active]
                    new, direction_event = choose_basis(opt.mode, displacement, state['accepted_in_stage'], gradient, learned, rng)
                    state['basis'] = new.tolist()
                    state['anchor'] = state['x'].copy()
                    state['accepted_in_stage'] = 0
            elif opt.mode != 'fixed' and state['failed_at_step'] < opt.failure_repolls:
                displacement = ((x - state['anchor']) / scales)[active]
                new, direction_event = choose_basis(opt.mode, displacement, state['accepted_in_stage'], gradient, learned, rng)
                state['basis'] = new.tolist()
                state['failed_at_step'] += 1
                # Failed polls/random fallbacks must not erase a single previous
                # success: otherwise sparse successes never form a joint direction.
                if direction_event.startswith(('success_displacement', 'gradient')):
                    state['anchor'] = state['x'].copy()
                    state['accepted_in_stage'] = 0
                event = 'repoll_same_step'
            else:
                state['step'] *= opt.shrink
                state['failed_at_step'] = 0
                event = 'shrink'
            state['nit'] += 1
            state['rng'] = rng.bit_generator.state
            after = metrics() if metrics else {}
            delta = {key: value - before.get(key, 0.) for key, value in after.items()}
            row = dict(round=state['nit'], event=event, accepted=accepted,
                       phase=state.get('phase', 'joint'), phase_round=phase_round(state),
                       active_coordinates=active.tolist(),
                       direction_update=direction_event, axis_poll=axis_poll,
                       fun=state['fun'], improvement=old_fun-state['fun'], pose=state['x'].copy(),
                       evaluated_center=x.tolist(), poll_basis=basis.tolist(),
                       step_used=step, next_step=state['step'],
                       requested=calls, called=calls-hits, memo_hits=hits, full_poll=bank is None,
                       tolerance_check=certify, screen_bank=bank['sha256'] if bank is not None else None,
                       poll=[dict(pose=jobs[k][0].tolist(), first_objective=v.value,
                                  full_objective=verified[k].value if k in verified else None)
                             for k,v in first.items()],
                       nfev=state['nfev'], wall_s=time.perf_counter()-started, metrics=delta)
            if on_round:
                on_round(state, row)
        if state['step'] <= opt.tol:
            reason = 'step_tolerance'
    state['stop_reason'] = reason
    return state


def file_digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def run_signature(args, module):
    # GPU slots and execution budgets may change when resuming; physical inputs,
    # score options, direction rules and exact code identity must remain fixed.
    ignored = {'Pattern_continue', 'Pattern_continue_file', 'Pattern_continue_more_rounds',
               'Pattern_max_iter', 'Adaptive_max_evals', 'Adaptive_keep_checkpoints',
               'verbose', 'max_workers', 'gpuid', 'ctf_cache_mb', 'search_cache_mb',
               '_round_batch_enabled'}
    settings = {k: v for k, v in vars(args).items() if k not in ignored}
    settings['resolved_evaluation_backend'] = ('round_batch'
        if getattr(args, '_round_batch_enabled', False) else 'legacy')
    identities = {}
    for key in ['PDB_NAME', 'STAR_NAME', 'ang', 'fsc_file', 'search_script']:
        value = getattr(args, key, None)
        if value:
            identities[key] = file_digest(value)
    identities['adaptive_script'] = file_digest(__file__)
    # Changes to any installed pipeline helper invalidate reuse across restarts.
    for path in sorted(Path(module.__file__).resolve().parent.glob('*.py')):
        identities['pipeline/' + path.name] = file_digest(path)
    # Stack files can be large. Bind the checkpoint to the image identities
    # and modification times using the same working-directory rule as the MRC reader.
    stack_paths = {image.split('@', 1)[1] for _, image in particles(args.STAR_NAME)}
    stack_stats = {}
    for filename in sorted(stack_paths):
        path = Path(filename).resolve()
        stat = path.stat()
        stack_stats[str(path)] = [stat.st_size, stat.st_mtime_ns]
    payload = dict(settings=settings, file_sha256=identities, image_stacks=stack_stats)
    digest = hashlib.sha256(json.dumps(payload, sort_keys=True).encode()).hexdigest()
    return digest, payload


def main(argv=None, *, fixed=False):
    parser = create_parser()
    args = parser.parse_args(argv)
    name = 'Pattern' if fixed else 'Adaptive'
    if fixed:
        args.Adaptive_direction_mode = 'fixed'
        args.Adaptive_scales = '[1,1,1,1,1,1]'
    args.optimizer = name
    if args.Pattern_dimensions != 6:
        parser.error('GisAPR rigid-body objective requires Pattern_dimensions=6')
    try:
        lb, ub = parse_bounds(args.Pattern_Bounds, 6)
        scales = parse_vector(args.Adaptive_scales, 6, 'Adaptive_scales')
        opt = SearchOptions(step_size=args.Pattern_stepsize, tol=args.Pattern_tol,
                            shrink=args.Pattern_shrink, expand=args.Pattern_expand,
                            max_iter=args.Pattern_max_iter, max_evals=args.Adaptive_max_evals,
                            mode=args.Adaptive_direction_mode, update_every=args.Adaptive_update_every,
                            failure_repolls=args.Adaptive_failure_repolls,
                            axis_poll_every=args.Adaptive_axis_poll_every, seed=args.Adaptive_seed,
                            max_step=args.Adaptive_max_stepsize, max_workers=args.max_workers,
                            rotation_then_translation=args.Pattern_rotation_then_translation)
        opt.validate()
        if np.any(scales <= 0):
            raise ValueError('Adaptive_scales must be strictly positive')
        if args.Pattern_continue_more_rounds < 0:
            raise ValueError('Pattern_continue_more_rounds must be nonnegative')
        if args.Pattern_given_initial:
            x0 = parse_vector(args.Pattern_initial, 6, 'Pattern_initial')
        else:
            seed = None if fixed else args.Adaptive_seed
            x0 = np.clip(np.round(np.random.default_rng(seed).uniform(-20, 20, 6)), lb, ub)
        import func_v2 as gisapr_func
        from gisapr_runtime_v2 import metrics_snapshot, resolve_script, worker_slots
        for option in ['PDB_NAME', 'STAR_NAME', 'ang', 'fsc_file']:
            value = getattr(args, option, None)
            if value:
                path = Path(value).expanduser().resolve()
                if not path.is_file():
                    raise ValueError(f'{option} does not exist: {path}')
                setattr(args, option, str(path))
        args.search_script = str(resolve_script(args.search_script))
        from gisapr_runtime_v2 import SEARCH_SCRIPT
        if file_digest(args.search_script) != file_digest(SEARCH_SCRIPT):
            raise ValueError('Use the v7 standalone search supplied in this package or omit --search_script')
        root = Path(args.output_name_root).expanduser().resolve()
        args.output_name_root = str(root)
        directory = root.with_name(root.name + name + '_run')
        slots = worker_slots(args.gpuid)
        objective = GisAPRObjective(args, directory)
        signature, provenance = run_signature(args, gisapr_func)
        state = None
        if args.Pattern_continue:
            if not args.Pattern_continue_file:
                raise ValueError('Pattern_continue requires Pattern_continue_file')
            state = load_checkpoint(args.Pattern_continue_file, signature)
            if not directory.is_dir():
                raise ValueError('Keep the original run directory and its evaluations when continuing')
            if objective.compact and not objective.store.path.is_file():
                raise ValueError('Keep evaluation_cache.sqlite3 together with the checkpoint')
            saved_run = json.loads((directory / 'run_config.json').read_text(encoding='utf-8'))
            if saved_run['signature'] != signature:
                raise ValueError('Run directory signature mismatch')
            opt.max_iter = state['nit'] + args.Pattern_continue_more_rounds
        else:
            directory.mkdir(parents=True, exist_ok=False)
            atomic_json(directory / 'run_config.json', dict(version=VERSION, signature=signature,
                        provenance=provenance, argv=sys.argv if argv is None else argv))
    except (ValueError, FileExistsError, FileNotFoundError, ImportError) as exc:
        parser.error(str(exc))
    latest = directory / 'latest.npz'
    history = directory / 'rounds.jsonl'
    # This exclusive per-run lock prevents two optimizers sharing the same state.
    lock_path = directory / 'RUNNING.lock'
    try:
        lock = lock_path.open('x', encoding='utf-8')
    except FileExistsError:
        parser.error(f'Run lock exists: {lock_path}. Check whether its process is still running before removing a stale lock.')
    with lock:
        lock.write(json.dumps(dict(pid=os.getpid(), started=time.time())) + '\n')
    def on_round(current, row):
        if row['event'] in ('initial', 'accepted'):
            if current['orientations'] is not None:
                atomic_json(directory / 'current_orientations.json', current['orientations'])
            else:
                (directory / 'current_orientations.json').unlink(missing_ok=True)
        save_checkpoint(latest, current, signature)
        if args.Adaptive_keep_checkpoints:
            save_checkpoint(directory / f'round_{current["nit"]:06d}.npz', current, signature)
        with history.open('a', encoding='utf-8') as log:
            log.write(json.dumps(row, allow_nan=False) + '\n')
        if row['event'] == 'rotation_converged_start_translation':
            print(f'{name}: rotation converged at round {current["nit"]}; '
                  f'starting translation with step={current["step"]:.6g}; no extra scoring.', flush=True)
            return
        if row['round'] == 0:
            print(f'Initial objective={current["fun"]:.10g}; phase={row["phase"]}; pose={current["x"]}', flush=True)
            return
        m = row['metrics']
        print(f'{name} round {current["nit"]} [{row["phase"]}]: best={current["fun"]:.10g}, step={current["step"]:.6g}, '
              f'event={row["event"]}, axes={row["direction_update"]}, wall={row["wall_s"]:.2f}s, '
              f'called={row["called"]}, memo={row["memo_hits"]}, computed={int(m.get("computed",0))}, '
              f'disk_reused={int(m.get("reused",0))}, rejected={int(m.get("rejected",0))}, '
              f'total_calls={current["nfev"]}', flush=True)
        if args.verbose:
            print(f'  pose={current["x"]}; used axes={row["poll_basis"]}', flush=True)
    schedule = 'rotation_then_translation' if opt.rotation_then_translation else 'joint_6d'
    print(f'{name} Top-K search {VERSION}: mode={opt.mode}, schedule={schedule}, scales={scales.tolist()}\n'
          f'Run directory: {directory}\nCheckpoint: {latest}', flush=True)
    try:
        if state is not None:
            # A saved numbered checkpoint may predate the latest completed poll.
            if history.exists():
                retained = []
                for line in history.read_text(encoding='utf-8').splitlines():
                    try:
                        item = json.loads(line)
                    except json.JSONDecodeError:
                        break  # interrupted append after a completed checkpoint
                    transition_ahead = (item['event'] == 'rotation_converged_start_translation'
                                        and state.get('phase') == 'rotation')
                    if item['round'] <= state['nit'] and not transition_ahead:
                        retained.append(line)
                tmp = history.with_suffix('.tmp')
                tmp.write_text(''.join(line+'\n' for line in retained), encoding='utf-8')
                os.replace(tmp, history)
            if state['orientations'] is not None:
                check_bank(state['orientations'], objective.context)
                atomic_json(directory / 'current_orientations.json', state['orientations'])
            else:
                (directory / 'current_orientations.json').unlink(missing_ok=True)
        gisapr_func.prepare_workers(args)
        state = adaptive_search(objective, x0, (lb, ub), scales, opt, slots=slots,
                                state=state, on_round=on_round, metrics=metrics_snapshot)
        save_checkpoint(latest, state, signature)
        print(f'{name} search finished: best={state["fun"]:.10g}, pose={state["x"]}, '
              f'rounds={state["nit"]}, calls={state["nfev"]}, phase={state.get("phase", "joint")}, reason={state["stop_reason"]}', flush=True)
        objective.export_best(state, root, name)
    finally:
        try:
            gisapr_func.shutdown_workers(args)
        finally:
            try:
                objective.close()
            finally:
                lock_path.unlink(missing_ok=True)


if __name__ == '__main__':
    main()
