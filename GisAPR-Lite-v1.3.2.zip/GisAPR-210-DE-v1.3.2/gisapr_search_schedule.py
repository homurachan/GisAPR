"""Optional rotation-then-translation schedule shared by both pattern engines.

The objective always receives a full six-component pose. Only the active
three-dimensional subspace is polled/adapted; no score or bank is changed here.
"""
import numpy as np


def initialize_schedule(state, options):
    if options.rotation_then_translation:
        state.update(search_schedule='rotation_then_translation', phase='rotation',
                     phase_start_nit=0, phase_start_pose=state['x'].copy(),
                     rotation_result=None, basis=np.eye(3).tolist())


def active_coordinates(state, dimensions):
    if state.get('phase') == 'rotation':
        return np.arange(3)
    if state.get('phase') == 'translation':
        return np.arange(3, 6)
    return np.arange(dimensions)


def phase_round(state):
    return state['nit'] - state.get('phase_start_nit', 0)


def validate_schedule(state, options, dimensions):
    if not options.rotation_then_translation:
        if 'search_schedule' in state:
            raise ValueError('Checkpoint uses rotation_then_translation; keep that option on resume')
        return
    if (dimensions != 6 or state.get('search_schedule') != 'rotation_then_translation'
            or state.get('phase') not in ('rotation', 'translation')):
        raise ValueError('Invalid rotation/translation checkpoint schedule')
    start = state.get('phase_start_nit')
    if not isinstance(start, int) or not 0 <= start <= state['nit']:
        raise ValueError('Invalid phase iteration counter')
    origin = np.asarray(state.get('phase_start_pose'), dtype=float)
    if origin.shape != (6,) or not np.isfinite(origin).all():
        raise ValueError('Invalid phase starting pose')
    frozen = np.setdiff1d(np.arange(6), active_coordinates(state, 6))
    if not np.array_equal(np.asarray(state['x'])[frozen], origin[frozen]):
        raise ValueError('Checkpoint changed coordinates frozen during this phase')
    rotation = state.get('rotation_result')
    if state['phase'] == 'rotation':
        if rotation is not None or start != 0:
            raise ValueError('Invalid rotation phase checkpoint')
    elif (not isinstance(rotation, dict) or rotation.get('pose') != origin.tolist()
          or rotation.get('rounds') != start or rotation.get('stop_reason') != 'step_tolerance'):
        raise ValueError('Translation checkpoint must follow a converged rotation phase')


def advance_to_translation(state, options, on_round=None):
    """Transition only at the rotation step tolerance, never at a budget stop.

    Called before checking remaining budgets, so a just-converged rotation is
    recorded even if no translation poll can yet be afforded. Resuming starts
    translation directly. There is exactly one rotation -> translation pass.
    """
    if not (options.rotation_then_translation and state['phase'] == 'rotation'
            and state['step'] <= options.tol):
        return False
    state['rotation_result'] = dict(pose=state['x'].copy(), objective=state['fun'],
        rounds=state['nit'], calls=state['nfev'], step=state['step'], stop_reason='step_tolerance')
    state.update(phase='translation', phase_start_nit=state['nit'],
                 phase_start_pose=state['x'].copy(), step=options.step_size,
                 basis=np.eye(3).tolist(), anchor=state['x'].copy(),
                 accepted_in_stage=0, failed_at_step=0, stop_reason='iteration_limit')
    if on_round:
        on_round(state, dict(round=state['nit'], phase='translation', phase_round=0,
            event='rotation_converged_start_translation', fun=state['fun'], pose=state['x'].copy(),
            step=state['step'], called=0, nfev=state['nfev'], wall_s=0.))
    return True
