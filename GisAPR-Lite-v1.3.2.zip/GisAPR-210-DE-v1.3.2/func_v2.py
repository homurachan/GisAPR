"""Top-K/full local objectives for fixed and adaptive pattern searches."""
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass
import hashlib
import json
import math
import os
from pathlib import Path
import shutil

import numpy as np
from gisapr_runtime_v2 import (candidate_shard_slots, configured_worker_slots, get_worker,
                              prepare_workers, record_metrics, shutdown_workers)
from gisapr_star import find_star_loop, read_text_lines
from new_method_to_fit_the_2nd_Gaussian_PEAK_v5 import run_this
from orientation_bank_v1 import atomic_json, check_bank, pack_bank, settings
from pdb_text import write_transformed_chain
from gisapr_result_store import ResultStore


def pose_key(pose):
    values = np.asarray(pose, dtype='<f8').copy()
    if values.shape != (6,) or not np.isfinite(values).all():
        raise ValueError('A pose must consist of six finite coordinates')
    values[values == 0] = 0.0
    return values.tobytes().hex()


def candidate_id(pose):
    return hashlib.sha256(bytes.fromhex(pose_key(pose))).hexdigest()[:24]


def particles(path):
    loop = find_star_loop(read_text_lines(path), ('_rlnImageName', '_rlnAngleRot', '_rlnAngleTilt'))
    index = loop.labels['_rlnImageName']
    required = max(index, loop.labels['_rlnAngleRot'], loop.labels['_rlnAngleTilt'])
    return [(i, row[index]) for i in loop.data_line_indices if len(row := loop.tokens(i)) > required]


@dataclass
class Evaluation:
    value: float
    bank: dict | None
    cached: bool = False


class GisAPRObjective:
    def __init__(self, args, directory):
        self.args = args
        self.directory = Path(directory)
        self.context = settings(args.STAR_NAME, args.ang, args.keep_orientations,
                                args.do_local_search, args.local_stepsize, args.psiStep)
        records = particles(args.STAR_NAME)
        count = min(len(records), args.SplitParticles)
        if count <= 0:
            raise ValueError('SplitParticles and the number of STAR particles must be positive')
        self.groups = []
        start = 0
        for j in range(count):
            size = len(records) // count + int(j < len(records) % count)
            self.groups.append([i for i, _ in records[start:start + size]])
            start += size
        self.slots = configured_worker_slots(args)
        self.compact = not (getattr(args, 'keep_intermediates', False) or args.write_model_mrc)
        self.store = ResultStore(directory) if self.compact else None
        from gisapr_batch_objective import configure_batch
        configure_batch(self, len(records))

    def location(self, pose, bank):
        parent = self.directory / 'evaluations' if bank is None else self.directory / 'screen' / bank['sha256'][:24]
        return parent / candidate_id(pose)

    def cached(self, pose, bank):
        if self.compact:
            return not self.args.no_result_cache and self.store.contains(pose_key(pose), bank)
        return not self.args.no_result_cache and (self.location(pose, bank) / 'pose.json').is_file()

    def evaluate(self, pose, slot, bank=None):
        if self.batch_enabled:
            return self.evaluate_many([pose], [slot], bank)[0]
        args = self.args
        pose = list(map(float, pose))
        if bank is not None:
            check_bank(bank, self.context)
        if self.compact and not args.no_result_cache:
            saved = self.store.get(pose_key(pose), bank)
            if saved is not None:
                ranked = saved['ranked']
                if ranked is not None:
                    check_bank(ranked, self.context)
                    if ranked['pose'] != pose:
                        raise ValueError('Cached orientation bank belongs to another pose')
                record_metrics(reused=1)
                return Evaluation(saved['meta']['objective'], ranked, True)
        directory = self.store.workspace() if self.compact else self.location(pose, bank)
        directory.mkdir(exist_ok=True, parents=True)
        manifest = directory / 'pose.json'
        bank_path = directory / 'orientations.json'
        identity = dict(pose_hex=pose_key(pose), source_bank=None if bank is None else bank['sha256'])
        if not self.compact and manifest.is_file():
            saved = json.loads(manifest.read_text(encoding='utf-8'))
            if any(saved[k] != v for k, v in identity.items()):
                raise ValueError(f'Candidate identity mismatch in {manifest}')
            if not args.no_result_cache:
                ranked = None
                if saved['has_score_result']:
                    result = Path(saved['result'])
                    if not result.is_file() or float(result.read_text().splitlines()[1].split()[0]) != -saved['objective']:
                        raise ValueError(f'Missing or inconsistent score result in {directory}')
                if bank is None and saved.get('bank_sha256'):
                    ranked = json.loads(bank_path.read_text(encoding='utf-8'))
                    check_bank(ranked, self.context)
                    if ranked['sha256'] != saved['bank_sha256'] or ranked['pose'] != pose:
                        raise ValueError(f'Calibration differs from {manifest}')
                record_metrics(reused=1)
                return Evaluation(saved['objective'], ranked, True)
            manifest.unlink()
        worker = get_worker(slot, args.search_script)
        model = directory / 'candidate.pdb'
        result = directory / 'ReSuLt_candidate.pdb.txt'
        meta = dict(**identity, pose=pose, pdb=None, result=str(result), has_score_result=False,
                    phase='full' if bank is None else 'screen')
        if not args.skip_geometric_restraint:
            overlap, distance = worker.request('geometry', geometry_kwargs=dict(pdb_path=args.PDB_NAME,
                chain_id=args.rotate_chain, boxsize=256, apix=1.5, threshold=1.), pose=pose)
            if overlap >= args.MAXIUM_ALLOWED_overlapped_pixels or distance >= args.MAX_MinDistance_Allowed:
                penalty = float(overlap + args.MAX_MinDistance_Allowed)
                rejected = dict(**meta, objective=penalty, overlap=overlap, distance=distance)
                if self.compact:
                    self.store.put(pose_key(pose), bank, rejected, None, None)
                else:
                    atomic_json(manifest, rejected)
                record_metrics(rejected=1)
                return Evaluation(penalty, None)
        volume = dict(pdb_path=str(model), boxsize=args.boxsize, apix=args.apix_PDB,
                      res=2.*args.apix_PDB, do_yflip=args.yflip)
        mrc = directory / 'model.mrc'
        if args.write_model_mrc or (bank is None and not self.compact):
            write_transformed_chain(args.PDB_NAME, args.rotate_chain, pose, str(model))
            meta['pdb'] = str(model)
        if args.write_model_mrc:
            worker.request('generate_mrc', mrc_kwargs=dict(**volume, output=str(mrc)))
        else:
            volume.update(source_pdb=args.PDB_NAME, chain_id=args.rotate_chain, pose=pose)
        slots = candidate_shard_slots(args, slot, self.slots)
        pairs = list(enumerate(self.groups))
        def search_group(pair):
            j, group = pair
            target = get_worker(slots[j % len(slots)], args.search_script)
            shard = directory / f'shard_{j}.txt'
            values = dict(i=args.ang, ang=args.ang, p=args.STAR_NAME, mrc=mrc, o=shard,
                start=group[0], end=group[-1]+1, oriboxsize=args.boxsize, newboxsize=args.newboxsize,
                apix=args.apix, voltage=args.voltage, cs=args.cs, kk=args.kk, psiStep=args.psiStep,
                maskRadius=args.maskRadius, localRange=args.local_stepsize, transRange=args.transRange,
                ctf_cache_mb=args.ctf_cache_mb, search_cache_mb=args.search_cache_mb,
                fixed_density_cache_mb=args.fixed_density_cache_mb, projection_mode=args.projection_mode)
            if args.fsc_file:
                values['FSC'] = args.fsc_file
            argv = [part for k,v in values.items() for part in ('--'+k, str(v))]
            argv.extend(['--keep-orientations', str(args.keep_orientations)])
            for flag, enabled in [('ignoreFSC', args.do_ignoreFSC), ('doLocalSearch', args.do_local_search),
                                  ('verbose', args.verbose)]:
                if enabled:
                    argv.append('--'+flag)
            rows = None if bank is None else {str(i): bank['rows'][str(i)] for i in group}
            payload = dict(argv=argv, calibrate=bank is None, orientation_rows=rows)
            if args.write_model_mrc:
                metrics = target.request('search', **payload)
            else:
                metrics = target.request('search_from_pdb', model_kwargs=volume, **payload)
            top = metrics.pop('orientation_rows')
            if bank is None and set(top) != {str(i) for i in group}:
                raise ValueError('Incomplete particle calibration from worker')
            record_metrics(**metrics)
            return shard, top, metrics

        if len(pairs) == 1:
            shards = [search_group(pairs[0])]
        else:
            with ThreadPoolExecutor(max_workers=min(len(slots), len(pairs))) as pool:
                shards = list(pool.map(search_group, pairs))
        merged = directory / 'search_v7_candidate.txt'
        with (directory/'search.tmp').open('wb') as out:
            for filename, _, _ in shards:
                with filename.open('rb') as stream:
                    shutil.copyfileobj(stream, out)
        os.replace(directory/'search.tmp', merged)
        for filename, _, _ in shards:
            filename.unlink()
        score = float(run_this(str(merged), verbose=False)[-1])
        if math.isinf(score) or not merged.stat().st_size:
            raise ValueError(f'Infinite score or empty search result in {merged}')
        valid = not math.isnan(score)
        if not valid:
            # Match v210 aggregate-score handling. An unrankable center must
            # keep doing full local polls until it has a valid calibration.
            score = 0.0
            meta['score_status'] = 'nan_as_zero'
        ranked = None
        if bank is None and valid:
            rows = {i:row for _, part, _ in shards for i,row in part.items()}
            ranked = pack_bank(self.context, rows, pose=pose)
            if not self.compact:
                atomic_json(bank_path, ranked)
            meta['bank_sha256'] = ranked['sha256']
        if not self.compact:
            result.write_text(f'{merged.name}\n{score} 0.0 0.0\n', encoding='utf-8')
        meta.update(objective=-score, has_score_result=True, shard_metrics=[s[2] for s in shards])
        if self.compact:
            meta.update(result=None, pdb=None)
            self.store.put(pose_key(pose), bank, meta, ranked, merged.read_text(encoding='utf-8'))
        else:
            atomic_json(manifest, meta)  # publication marker after every referenced file is complete
        record_metrics(computed=1)
        return Evaluation(-score, ranked)

    def evaluate_many(self, poses, slots=None, bank=None):
        if self.batch_enabled:
            from gisapr_batch_objective import evaluate_many
            return evaluate_many(self, poses, bank)
        slots = slots or self.slots
        with ThreadPoolExecutor(max_workers=self.args.max_workers) as pool:
            return list(pool.map(lambda item: self.evaluate(item[1], slots[item[0] % len(slots)], bank),
                                 enumerate(poses)))

    def export_best(self, state, root, name, *, bank=None):
        pose = state['x']
        directory = self.location(pose, bank)
        info = dict(pose=pose, objective=state['fun'], rounds=state['nit'], objective_calls=state['nfev'],
                    candidate_directory=str(directory), stop_reason=state['stop_reason'], best_fit_pdb=None)
        info['score_scope'] = 'fixed_topk' if bank is not None else 'full_local'
        if bank is not None:
            check_bank(bank, self.context)
            info.update(orientation_bank_sha256=bank['sha256'], calibration_pose=bank['pose'])
        if self.compact:
            saved = self.store.get(pose_key(pose), bank)
            if saved is None:
                raise ValueError('Best evaluation is missing from the run cache for this orientation bank')
            meta = saved['meta']
            info.update(candidate_directory=None, evaluation_cache=str(self.store.path))
        else:
            meta = json.loads((directory/'pose.json').read_text(encoding='utf-8'))
        if meta['objective'] != state['fun']:
            raise ValueError('Checkpoint and cached score result disagree')
        if meta['has_score_result']:
            if self.compact:
                merged = self.directory / 'best_search.txt'
                merged.write_text(saved['search_text'], encoding='utf-8')
                result = self.directory / 'best_score.txt'
                result.write_text(f'{merged.name}\n{-state["fun"]} 0.0 0.0\n', encoding='utf-8')
            else:
                result = directory/'ReSuLt_candidate.pdb.txt'
            if float(result.read_text().splitlines()[1].split()[0]) != -state['fun']:
                raise ValueError('Checkpoint and cached score result disagree')
            best = Path(str(root)+name+'_BEST_FIT.pdb')
            write_transformed_chain(self.args.PDB_NAME, self.args.rotate_chain, pose, str(best))
            info.update(score=-state['fun'], best_fit_pdb=str(best), result_file=str(result),
                        score_status=meta.get('score_status', 'finite'))
            print(f'Greatest {info["score_scope"]} score: {-state["fun"]}\nBEST_FIT PDB: {best}', flush=True)
        atomic_json(str(root)+name+'_BEST_FIT.json', info)

    def close(self):
        if self.store is not None:
            self.store.close()
