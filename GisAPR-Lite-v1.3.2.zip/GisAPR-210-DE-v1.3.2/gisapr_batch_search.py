"""Memory-bounded round evaluation in a single persistent process per device.

All candidate projections in a bounded group are generated before particle
search. Each particle is prepared once for that group; correlation batches the
candidate x orientation dimension, but maxima/sums remain per candidate.
"""
from collections import OrderedDict
from concurrent.futures import ThreadPoolExecutor
from types import SimpleNamespace
import time

import numpy as np
import torch
import torch.nn.functional as F

from gisapr_cache import file_key
from gisapr_batch_density import RigidDensityCache
from gisapr_projection_cache import ProjectionGridCache, ProjectionFilterCache
from orientation_bank_v1 import restricted_indices, ranked_row


class TensorCache:
    """Bounded device tensors; no hidden unbounded CUDA cache of inputs."""
    def __init__(self, max_mb):
        self.limit = max(0, int(max_mb * 1024 ** 2))
        self.entries = OrderedDict()
        self.bytes = 0

    def get(self, key):
        value = self.entries.get(key)
        if value is not None:
            self.entries.move_to_end(key)
        return value

    def put(self, key, value, evict=True):
        size = value.numel() * value.element_size()
        if size > self.limit or not self.limit:
            return False
        if not evict and key not in self.entries and self.bytes + size > self.limit:
            return False
        old = self.entries.pop(key, None)
        if old is not None:
            self.bytes -= old.numel() * old.element_size()
        while self.entries and self.bytes + size > self.limit:
            _, old = self.entries.popitem(last=False)
            self.bytes -= old.numel() * old.element_size()
        self.entries[key] = value
        self.bytes += size
        return True

    def clear(self):
        self.entries.clear()
        self.bytes = 0


class FastProjector:
    def __init__(self, api, reference, grid_cache_mb=1024., filter_cache_mb=128.):
        self.api = api
        self.__dict__.update(reference.__dict__)
        n = self.original_box
        self.image_shape = (2 * n,) * 3
        self.dft_shape = (2 * n, 2 * n, n + 1)
        self.base_grid = api.build_projection_base_grid(self.image_shape, self.device)
        self.whitening = api.ProjectionWhitening(n, self.device)
        self.grids = ProjectionGridCache(grid_cache_mb)
        self.filter_cache = ProjectionFilterCache(n, self.device, filter_cache_mb)
        self.last_cache_metrics = {}

    def _grid_chunks(self, angles, selected):
        chunks = []
        for start in range(0, len(selected), self.batch_size):
            indices = selected[start:start + self.batch_size]
            matrices = np.ascontiguousarray(angles.rotation_matrices_t[indices])
            key = (matrices.dtype.str, matrices.shape, matrices.tobytes())
            chunks.append((start, indices, matrices, key))
        return chunks

    def retain_grids(self, angles, selected):
        return self.grids.retain_only({chunk[3] for chunk in self._grid_chunks(angles, selected)})

    def build_templates(self, volume, angles, orientation_indices=None):
        selected = (list(range(len(angles.rot))) if orientation_indices is None
                    else sorted(set(map(int, orientation_indices))))
        if any(i < 0 or i >= len(angles.rot) for i in selected):
            raise ValueError('Projection orientation index is outside the angle table')
        if (volume.shape != (self.original_box,) * 3 or volume.dtype != torch.float32
                or volume.device != self.device):
            raise ValueError('Model tensor must match box, device and float32 dtype')
        self.last_orientation_count = self.last_slice_count = len(selected)
        self.last_cache_metrics = dict(projection_grid_cache_hits=0,
            projection_grid_builds=0, projection_filter_cache_hits=0)
        templates = torch.empty((len(selected), self.new_box, self.layout.rfft_size),
                                dtype=torch.complex64, device=self.device)
        if not selected:
            return templates
        n = self.original_box
        pad = n // 2
        padded = F.pad(volume, [pad] * 6)
        _, filter_hit = self.filter_cache.apply(padded, self.api.apply_sinc2_filter_inplace_3d)
        self.last_cache_metrics['projection_filter_cache_hits'] = int(filter_hit)
        dft = torch.fft.fftshift(padded, dim=(-3, -2, -1))
        del padded
        dft = torch.fft.rfftn(dft, dim=(-3, -2, -1))
        dft = torch.fft.fftshift(dft, dim=(-3, -2))
        dft_real = torch.view_as_real(dft).permute(3, 0, 1, 2).unsqueeze(0)
        low = n // 2 - self.new_box // 2
        high = low + self.new_box
        # Matrix content and exact batch shape bind even a mutated angle table.
        chunks = self._grid_chunks(angles, selected)
        protected = {chunk[3] for chunk in chunks}
        for start, indices, matrices, key in chunks:
            pair = self.grids.get(key)
            if pair is None:
                pair = self.api.rotated_grid_to_grid_sample(self.base_grid,
                    torch.from_numpy(matrices).to(self.device), self.image_shape, self.dft_shape)
                self.grids.put(key, pair, protected)
                self.last_cache_metrics['projection_grid_builds'] += len(indices)
            else:
                self.last_cache_metrics['projection_grid_cache_hits'] += len(indices)
            grid, conjugate = pair
            sampled = F.grid_sample(dft_real, grid.unsqueeze(0), mode='bilinear',
                                    padding_mode='border', align_corners=True)
            sampled = torch.view_as_complex(sampled.squeeze(0).permute(1, 2, 3, 0).contiguous())
            sampled = torch.where(conjugate, torch.conj(sampled), sampled)
            projection = torch.fft.ifftshift(sampled, dim=(-2,))
            projection = torch.fft.irfftn(projection, dim=(-2, -1))
            projection = torch.fft.ifftshift(projection, dim=(-2, -1))[:, pad:-pad, pad:-pad]
            projection = self.whitening(projection)
            if self.real_space_mask is not None:
                projection = projection * self.real_space_mask
            centered = torch.fft.fftshift(torch.fft.fft2(projection), dim=(-2, -1))
            if self.new_box != n:
                centered = centered[:, low:high, low:high]
            packed = self.layout.centered_full_to_packed(centered) * self.packed_fsc
            norm = torch.linalg.vector_norm(packed.reshape(len(indices), -1), dim=1)
            packed = packed / norm[:, None, None]
            templates[start:start + len(indices)] = self.layout.pre_shift_for_correlation(packed)
        # No empty_cache here: allocator reuse is useful for the next candidate.
        return templates


class BatchSearchEngine:
    def __init__(self, search_globals, device, options):
        self.api = SimpleNamespace(**search_globals)
        self.device = device
        self.options = dict(options)
        self.particles = TensorCache(options['batch_particle_cache_mb'])
        self.volumes = TensorCache(options['batch_volume_cache_mb'] if options['retain_volumes'] else 0.)
        self.density = RigidDensityCache()
        self.context = None

    def sync(self):
        if self.device.type == 'cuda':
            torch.cuda.synchronize(self.device)

    def _context(self, args):
        api = self.api
        runtime = {'o', 'mrc', 'i', 'gpuid', 'verbose', 'orientations_in', 'orientations_out'}
        key = (tuple(sorted((k, v) for k, v in vars(args).items() if k not in runtime)),
               file_key(args.ang), file_key(args.p), file_key(args.FSC) if args.FSC else None)
        if self.context is not None and key == self.context.key:
            if tuple(file_key(p) for p in self.context.stack_paths) == self.context.stack_keys:
                return self.context
        self.context = None
        self.particles.clear()
        torch.set_num_threads(max(1, int(args.torchThreads)))
        original, new = int(args.oriboxsize), int(args.newboxsize)
        if original <= 0 or original % 2 or new > original or args.psiStep <= 0:
            raise ValueError('Invalid original/new box or psiStep')
        layout = api.PackedFourierLayout(new, int(args.ccgCropSize), self.device)
        angles = api.read_model_angles(args.ang)
        table = api.read_particle_table(args.p)
        records = api.select_particle_records(table, args.start, args.end)
        if not records:
            raise ValueError('No particles selected for batch evaluation')
        if args.doLocalSearch:
            local = {row[0]: row[1:] for row in api.build_local_orientation_entries(
                table.records, angles.rot, angles.tilt, float(args.localRange))}
        else:
            local = {rec.line_index: list(range(len(angles.rot))) for rec in records}
        mask = None if args.discardMask else torch.from_numpy(api.generate_soft_mask(
            (original, original), int(args.maskRadius), int(args.maskEdge))).to(self.device)
        fsc = torch.from_numpy(api.read_fsc_map(args.FSC, original, new, bool(args.ignoreFSC))).to(self.device)
        reference = api.IntegratedProjector(device=self.device, original_box=original,
            new_box=new, layout=layout, real_space_mask=mask,
            packed_fsc=layout.centered_full_to_packed(fsc), projection_batch_size=args.projectionBatchSize)
        projector = (reference if self.options['batch_projection_mode'] == 'legacy'
                     else FastProjector(api, reference,
                         self.options.get('batch_grid_cache_mb', 1024.),
                         self.options.get('batch_filter_cache_mb', 128.)))
        psi = {rec.line_index: api.psi_sampling_for_record(rec.psi, float(args.psiStep),
               bool(args.doLocalSearch), float(args.localRange)) for rec in records}
        unique = list(dict.fromkeys(float(np.round(a, 6)) for _, effective in psi.values() for a in effective))
        grid_bank = api.PsiGridBank(original, self.device, unique, int(args.psiGridBuildBatch))
        preparer = api.ParticleFourierPreparer(original, new, self.device, layout, mask, grid_bank)
        new_apix = original / new * float(args.apix)
        ctf_type = api.PackedCTFTorch if args.ctfBackend == 'torch' else api.PackedCTFNumPy
        ctf_kwargs = dict(size=new, pixel_size=new_apix, cs=float(args.cs), voltage=float(args.voltage), kk=float(args.kk))
        if args.ctfBackend == 'torch':
            ctf_kwargs['device'] = self.device
        stack_paths = sorted({rec.image_name.split('@', 1)[1] for rec in records})
        self.context = SimpleNamespace(key=key, args=args, layout=layout, angles=angles, table=table,
            records=records, local=local, projector=projector, psi=psi, preparer=preparer,
            ctf=ctf_type(**ctf_kwargs), trans_scale=float(args.apix) / new_apix,
            stack_paths=stack_paths, stack_keys=tuple(file_key(p) for p in stack_paths))
        return self.context

    def run(self, args, models, orientation_rows=None, calibrate=False):
        if calibrate and orientation_rows is not None:
            raise ValueError('Cannot calibrate from restricted directions')
        self.sync()
        started = time.perf_counter()
        ctx = self._context(args)
        local = ctx.local
        if orientation_rows is not None:
            local = {rec.line_index: restricted_indices(orientation_rows.get(str(rec.line_index)),
                rec, ctx.local[rec.line_index], ctx.angles, args.keep_orientations) for rec in ctx.records}
        needed = (sorted({i for rec in ctx.records for i in local.get(rec.line_index, [])})
                  if args.projection_mode == 'needed' else None)
        if (orientation_rows is not None and not self.options['retain_volumes']
                and needed is not None and isinstance(ctx.projector, FastProjector)):
            # Fixed-bank PSO/DE never revisit the broad calibration bank. Avoid
            # retaining ~1 GiB of unused grids for the following 500 rounds.
            released = ctx.projector.retain_grids(ctx.angles, needed)
            if released >= 128*1024**2 and self.device.type == 'cuda':
                torch.cuda.empty_cache()  # only a large bank transition, not per model
        lookup = None if needed is None else {v: i for i, v in enumerate(needed)}
        directions = len(ctx.angles.rot) if needed is None else len(needed)
        per_model = max(1, directions * args.newboxsize * ctx.layout.rfft_size * 8)
        budget = self.options['batch_template_mb'] * 1024 ** 2
        capacity = min(self.options['batch_candidates'], max(1, int(budget // per_model)))
        self.sync()
        setup_s = time.perf_counter() - started
        results = []
        for offset in range(0, len(models), capacity):
            group = models[offset:offset + capacity]
            results.extend(self._group(ctx, group, local, needed, lookup, calibrate,
                                       setup_s / max(1, len(models))))
        return results

    def _group(self, ctx, models, local, needed, lookup, calibrate, setup_per_model):
        # One CPU-only lookahead. No CUDA work or cache mutation in the thread.
        enabled = (self.device.type == 'cuda' and
                   self.options.get('batch_coordinate_prefetch', 'on') == 'on')
        if enabled:
            with ThreadPoolExecutor(max_workers=1, thread_name_prefix='coordinates') as executor:
                return self._group_impl(ctx, models, local, needed, lookup, calibrate,
                                        setup_per_model, executor)
        return self._group_impl(ctx, models, local, needed, lookup, calibrate, setup_per_model)

    def _group_impl(self, ctx, models, local, needed, lookup, calibrate, setup_per_model, executor=None):
        api, args = self.api, ctx.args
        templates, rows, texts, raw, metrics = [], [], [], [], []
        prepared_future = None
        plans = []
        for model in models:
            kwargs = dict(model, device=str(self.device))
            key = (file_key(kwargs.get('source_pdb') or kwargs['pdb_path']),
                   tuple(sorted((k, tuple(v) if isinstance(v, list) else v)
                                for k, v in kwargs.items() if k != 'pdb_path')))
            plans.append((kwargs, key))
        for model_index, (kwargs, key) in enumerate(plans):
            t0 = time.perf_counter()
            volume = self.volumes.get(key)
            reused = volume is not None
            prepared = None
            wait_s = 0.
            if prepared_future is not None:
                wait_started = time.perf_counter()
                prepared = prepared_future.result()
                wait_s = time.perf_counter() - wait_started
                prepared_future = None
            if volume is None:
                volume = self.density.generate(kwargs, args.fixed_density_cache_mb,
                                              self.options['batch_density_mode'],
                                              self.options.get('density_backend', 'auto'),
                                              prepared=prepared)
            self.sync()
            density_s = time.perf_counter() - t0
            density_metrics = (dict(fixed_density_hits=0, fixed_density_cached_atoms=0)
                               if reused else self.density.last_metrics.copy())
            density_metrics['density_prefetch_wait_s'] = wait_s
            if executor is not None and model_index+1 < len(plans):
                next_kwargs, next_key = plans[model_index+1]
                if self.volumes.get(next_key) is None:
                    job = self.density.coordinate_job(next_kwargs, args.fixed_density_cache_mb,
                        self.options['batch_density_mode'], self.options.get('density_backend', 'auto'))
                    if job is not None:
                        prepared_future = executor.submit(job)
            t0 = time.perf_counter()
            templates.append(ctx.projector.build_templates(volume, ctx.angles, needed))
            self.sync()
            projection_s = time.perf_counter() - t0
            if not reused:
                self.volumes.put(key, volume)
            del volume
            metrics.append(dict(density_s=density_s, projection_s=projection_s,
                setup_s=setup_per_model, template_directions=ctx.projector.last_orientation_count,
                sampled_directions=ctx.projector.last_slice_count, volume_cache_hits=int(reused),
                **density_metrics, **getattr(ctx.projector, 'last_cache_metrics', {})))
            rows.append({})
            texts.append([])
            raw.append([])

        # Model templates are all ready. The experimental particle is now the
        # outer loop, and its Fourier tensor is shared by every candidate.
        search_started = time.perf_counter()
        prepared_count = hits = 0
        reader = api.ParticleMRCReader(int(args.oriboxsize), self.device)
        workspace = api.CorrelationWorkspace(self.device)
        try:
            for records in api.chunks(ctx.records, max(1, int(args.ctfBatchSize))):
                ctf_batch = None
                for rec_index, rec in enumerate(records):
                    indices = local.get(rec.line_index, [])
                    if not indices:
                        if calibrate:
                            for row in rows:
                                row[str(rec.line_index)] = dict(image=rec.image_name, directions=[])
                        continue
                    fake, effective = ctx.psi[rec.line_index]
                    particle = self.particles.get(rec.line_index)
                    if particle is None:
                        if ctf_batch is None:
                            ctf_batch = ctx.ctf.batch(records, ctx.table.has_ctf)
                            if isinstance(ctf_batch, np.ndarray):
                                ctf_batch = torch.from_numpy(ctf_batch).to(self.device)
                        particle = ctx.preparer.prepare(reader.read(rec.image_name), effective, ctf_batch[rec_index])
                        # Stable subset rather than cyclic eviction for large inputs.
                        self.particles.put(rec.line_index, particle, evict=False)
                        prepared_count += 1
                    else:
                        hits += 1
                    index = torch.tensor(indices if lookup is None else [lookup[i] for i in indices],
                                         dtype=torch.long, device=self.device)
                    combined = torch.cat([bank.index_select(0, index) for bank in templates], dim=0)
                    scores, ys, xs = api.correlate_templates_and_particle(combined, particle, ctx.layout,
                        workspace, chunk_size_a=max(1, int(args.chunkSizeA)), chunk_size_b=max(1, int(args.chunkSizeB)))
                    width = len(indices)
                    for i in range(len(models)):
                        view = slice(i * width, (i + 1) * width)
                        if calibrate:
                            rows[i][str(rec.line_index)] = ranked_row(rec, indices, ctx.angles,
                                                                    scores[view], args.keep_orientations)
                        records_out = api.make_result_records(rec, fake, ctx.angles.rot, ctx.angles.tilt,
                            indices, scores[view], ys[view], xs[view], ctx.layout.crop_size, ctx.trans_scale)
                        texts[i].extend(str(row) + '\n' for row in records_out)
                        raw[i].append(records_out[-1][-1])
                    del particle, combined, index
                del ctf_batch
        finally:
            reader.close()
        self.sync()
        search_s = time.perf_counter() - search_started
        result = []
        for i, metric in enumerate(metrics):
            metric.update(search_s=search_s / len(models), batch_requests=1. / len(models),
                          particle_preparations=prepared_count / len(models),
                          particle_cache_hits=hits / len(models))
            metric['execution_s'] = metric['setup_s'] + metric['projection_s'] + metric['search_s']
            score = float(np.sum(np.exp(np.asarray(raw[i], dtype=np.float64) / 1024.)))
            result.append(dict(score=score, orientation_rows=rows[i] if calibrate else None,
                               search_text=''.join(texts[i]), metrics=metric))
        return result
