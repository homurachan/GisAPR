"""GisAPR v5 scoring: always sum exp(rawCC / 1024), without fitting.

The two legacy score-mode arguments are accepted but ignored. Keep this file
named new_method_to_fit_the_2nd_Gaussian_PEAK_v4.py when replacing the scorer
used by an existing func.py import. Only NumPy and the standard library are
required. The result format and four-value run_this return contract are kept;
obsolete threshold/peak fields are zero.
"""

import argparse
from pathlib import Path

import numpy as np

__version__ = "5.0.0"


def run_this(results_file, do_run_CC=None, do_simple_sum=None, verbose=True):
    """Read raw CC values and return (0, 0, 0, sum(exp(CC_data))).

    Search records store rawCC multiplied by 1024. Preserve their order and
    the original scaling. No fitting, filtering, clipping or score-mode branch
    is applied. NumPy's normal handling of empty/nonfinite arrays is retained.
    """
    raw_CC_array = []
    with open(results_file, "r") as handle:
        for line in handle:
            fields = line.split(",")
            if fields[0] == "['rawCC: '":
                rawCC = float(fields[-1].split("]")[0]) / 1024.0
                raw_CC_array.append(rawCC)

    CC_data = np.asarray(raw_CC_array, dtype=np.float64)
    total_estimated_sum_cc = np.sum(np.exp(CC_data))
    if verbose:
        print(results_file)
        print("total_estimated_sum_cc =", total_estimated_sum_cc)
    return 0.0, 0.0, 0.0, total_estimated_sum_cc


def score_index(results_file, do_run_CC, do_simple_sum, output_filename,
                verbose=True, base_dir=None):
    """Keep the existing index-file, path-resolution and two-line output API.

    Each index line is a complete search filename, including any spaces.
    Without base_dir, relative paths remain relative to the current directory,
    matching the original CLI. Optimizers can supply base_dir without changing
    the working directory of a multithreaded process.
    """
    with open(results_file, "r") as handle:
        filenames = handle.readlines()
    with open(output_filename, "w") as output:
        for entry in filenames:
            filename = entry.strip()
            source = Path(filename)
            if base_dir is not None and not source.is_absolute():
                source = Path(base_dir) / source
            _, _, _, total_estimated_sum_cc = run_this(
                str(source), do_run_CC, do_simple_sum, verbose=verbose)
            output.write(filename + "\n")
            output.write(str(total_estimated_sum_cc) + " 0.0 0.0\n")


def parse_command_line():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--version", action="version", version=__version__)
    parser.add_argument("results_file", help="Index file listing search-result filenames")
    parser.add_argument("do_run_CC", help="Ignored legacy score-mode argument")
    parser.add_argument("do_simple_sum", help="Ignored legacy aggregation argument")
    parser.add_argument("output_filename", help="Output score file")
    args = parser.parse_args()
    return args.results_file, args.do_run_CC, args.do_simple_sum, args.output_filename


def main():
    score_index(*parse_command_line())


if __name__ == "__main__":
    main()
