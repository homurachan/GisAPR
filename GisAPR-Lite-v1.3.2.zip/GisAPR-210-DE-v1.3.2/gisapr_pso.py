"""PSO ver622 dynamics ported to the DE-v1.2.0 objective/runtime (GPL-3.0).

Preserves linear inertia, personal/global attraction, pivot boundary response,
optional Gaussian velocity noise and MLP guidance. Final positions are now
clamped after ALL forces/noise. Only real scores update personal/global bests.
"""
from concurrent.futures import ThreadPoolExecutor, wait, FIRST_COMPLETED
import copy
from dataclasses import dataclass, asdict
import math
import time

import numpy as np

from func_v2 import pose_key
from orientation_bank_v1 import check_bank


@dataclass
class PSOOptions:
    particles: int = 3
    iterations: int = 30
    wmax: float = .9
    wmin: float = .4
    c1: float = 2.
    c2: float = 2.
    seed: int = 0
    max_workers: int = 3
    max_evals: int = 0
    converge_velocities: float = 0.
    add_noise: bool = False
    noise_strength: float = 1.
    noise_decay: float = .99
    skip_geometry: bool = False
    geometry_threshold: int = 300
    use_surrogate: bool = False
    surrogate_start: int = 5
    surrogate_every: int = 5
    surrogate_min_points: int = 20
    surrogate_weight: float = .5
    surrogate_hidden: tuple = (128,128,64)
    surrogate_seed: int = 0
    surrogate_skip_threshold: float = 1.
    progress_interval: float = 60.

    def validate(self):
        if not math.isfinite(self.converge_velocities) or self.converge_velocities < 0:
            raise ValueError('PSO_converge_velocities must be finite and >= 0; 0 disables velocity convergence')
        if self.particles < 1 or self.iterations < 1 or self.max_workers < 1 or self.max_evals < 0 or self.seed < 0:
            raise ValueError('Require PSO particles/iterations/workers>=1 and budget/seed>=0')
        if self.seed > 2**32-1 or not 0 <= self.surrogate_seed <= 2**32-1:
            raise ValueError('PSO and surrogate random seeds must be in [0, 2**32-1]')
        values = [self.wmax,self.wmin,self.c1,self.c2,self.noise_strength,self.noise_decay,
                  self.surrogate_weight,self.surrogate_skip_threshold,self.progress_interval]
        if not all(math.isfinite(v) and v >= 0 for v in values) or self.wmax < self.wmin or self.progress_interval <= 0:
            raise ValueError('PSO factors must be finite/nonnegative; wmax>=wmin; progress interval>0')
        if self.surrogate_start < 0 or self.surrogate_every < 1 or self.surrogate_min_points < 2 or self.surrogate_seed < 0:
            raise ValueError('Invalid surrogate training schedule/seed')
        if not self.surrogate_hidden or any(x < 1 for x in self.surrogate_hidden):
            raise ValueError('Surrogate hidden-layer sizes must be positive')


def dynamics_signature(opt):
    data = asdict(opt)
    for key in ('max_workers','max_evals','progress_interval','converge_velocities'):
        data.pop(key)
    data['surrogate_hidden'] = list(data['surrogate_hidden'])
    return data


def pack_rng(rng):
    name,keys,position,has_gauss,cached = rng.get_state()
    return dict(name=name,keys=keys.tolist(),position=position,has_gauss=has_gauss,cached=cached)


def restore_rng(rng, saved):
    rng.set_state((saved['name'],np.asarray(saved['keys'],dtype=np.uint32),
                   int(saved['position']),int(saved['has_gauss']),float(saved['cached'])))


def inertia_weight(iteration, opt):
    if opt.iterations <= 1 or iteration >= opt.iterations:
        return opt.wmin
    return opt.wmax-(opt.wmax-opt.wmin)*iteration/(opt.iterations-1)


def advance(positions, velocities, pbests, gbest, gbest_score, scores, lb, ub, pivot, opt, iteration, sigma, rng, model=None):
    r1 = rng.uniform(size=positions.shape)
    r2 = rng.uniform(size=positions.shape)
    velocity = (inertia_weight(iteration,opt)*velocities
                + opt.c1*r1*(pbests-positions) + opt.c2*r2*(gbest-positions))
    guided = False
    if model is not None and np.max(np.abs(velocity)) >= opt.surrogate_skip_threshold:
        from gisapr_pso_surrogate import predict_model
        trial = positions+velocity
        predicted = predict_model(model,trial)
        if np.isfinite(predicted).all() and predicted.min() < gbest_score:
            target = trial[int(np.argmin(predicted))]
            velocity += opt.surrogate_weight*rng.uniform(size=positions.shape)*(target-positions)
            guided = True
    trial = positions+velocity
    for d in range(6):
        hits = (trial[:,d] <= lb[d]) | (trial[:,d] >= ub[d])
        # Preserve ver622's RNG draws even when no component hits a bound.
        magnitudes = rng.uniform(.1,.2,size=len(positions))
        velocity[hits,d] = (pivot[d]-positions[hits,d])*magnitudes[hits]
    if not opt.skip_geometry:
        for i,score in enumerate(scores):
            if score >= opt.geometry_threshold:
                velocity[i] += rng.uniform(.1,.2,size=6)*(pivot-positions[i])
    if opt.add_noise:
        velocity += rng.normal(0.,sigma,size=velocity.shape)
    proposed = positions+velocity
    if not np.isfinite(proposed).all():
        raise ValueError('PSO produced a nonfinite position; check velocity/noise factors')
    moved = np.clip(proposed,lb,ub)
    clipped = int(np.any(moved != proposed,axis=1).sum())
    # Keep exact legacy velocity where no clipping occurred (no subtract-roundoff).
    changed = moved != proposed
    velocity[changed] = (moved-positions)[changed]
    return moved,velocity,guided,clipped


def pso_search(objective, bounds, options=None, *, pivot=None, x0=None, slots=None,
               state=None, fixed_bank=None, initial_calls=0, initial_requests=0,
               total_rounds=None, reset_velocities=False, on_round=None, on_progress=None, metrics=None):
    opt = options or PSOOptions()
    opt.validate()
    limit = opt.iterations if total_rounds is None else int(total_rounds)
    if limit < 0 or initial_calls < 0 or initial_requests < initial_calls:
        raise ValueError('Invalid round limit or calibration counters')
    lb,ub = (np.asarray(v,dtype=float) for v in bounds)
    pivot = np.zeros(6) if pivot is None else np.asarray(pivot,dtype=float)
    if lb.shape != (6,) or ub.shape != (6,) or pivot.shape != (6,) or not np.isfinite([lb,ub,pivot]).all() or np.any(lb>=ub):
        raise ValueError('PSO requires six finite ordered bounds and a finite six-value pivot')
    if not np.isfinite(ub-lb).all():
        raise ValueError('PSO bound widths must be finite')
    if x0 is not None:
        x0 = np.asarray(x0,dtype=float)
        if x0.shape != (6,) or not np.isfinite(x0).all() or np.any(x0<lb) or np.any(x0>ub):
            raise ValueError('PSO_initial must be inside PSO_Bounds')
    slots = slots or [None]
    rng = np.random.RandomState(opt.seed)
    history_x,history_y,model = [],[],None
    trained_points = 0
    if state is None:
        if reset_velocities:
            raise ValueError('Velocity reset requires an initialized PSO checkpoint')
        positions = rng.uniform(lb,ub,size=(opt.particles,6))
        if x0 is not None:
            positions[0] = x0
        shape = (opt.particles, 1)
        magnitudes = rng.uniform(0.1, 0.2, size=shape)
        signs = rng.choice([-1.0, 1.0], size=shape)
        velocities = magnitudes * signs
        pbests = positions.copy()
        pbest_scores = np.full(opt.particles,np.inf)
        gbest,gbest_score,best_bank = None,float('inf'),None
        nit,nfev,requested,hits_total = 0,initial_calls,initial_requests,initial_requests-initial_calls
        sigma = opt.noise_strength
    else:
        if state['dynamics'] != dynamics_signature(opt) or not np.array_equal(state['bounds'],[lb,ub]) or not np.array_equal(state['pivot'],pivot):
            raise ValueError('PSO checkpoint dynamics/bounds/pivot mismatch')
        saved_bank = state.get('fixed_orientations')
        if fixed_bank is not None and fixed_bank != saved_bank:
            raise ValueError('Cannot change fixed orientations during PSO resume')
        fixed_bank = saved_bank
        positions = np.asarray(state['positions'],dtype=float)
        velocities = np.asarray(state['velocities'],dtype=float)
        pbests = np.asarray(state['pbest_positions'],dtype=float)
        pbest_scores = np.asarray(state['pbest_scores'],dtype=float)
        for array in (positions,velocities,pbests):
            if array.shape != (opt.particles,6) or not np.isfinite(array).all():
                raise ValueError('Invalid PSO checkpoint swarm arrays')
        if np.any(positions<lb) or np.any(positions>ub) or np.any(pbests<lb) or np.any(pbests>ub):
            raise ValueError('PSO checkpoint positions exceed bounds')
        if pbest_scores.shape != (opt.particles,) or not np.isfinite(pbest_scores).all():
            raise ValueError('Invalid PSO checkpoint personal-best scores')
        gbest,gbest_score = np.asarray(state['x']),float(state['fun'])
        if gbest.shape != (6,) or gbest_score != float(pbest_scores.min()) or not np.any(np.all(pbests==gbest,axis=1)&(pbest_scores==gbest_score)):
            raise ValueError('PSO global best does not match personal bests')
        nit,nfev,requested,hits_total = (int(state[k]) for k in ('nit','nfev','requested','memo_hits'))
        sigma = float(state['sigma'])
        if min(nit,nfev,requested,hits_total)<0 or not math.isfinite(sigma) or sigma<0:
            raise ValueError('Invalid PSO counters/noise state')
        restore_rng(rng,state['rng'])
        best_bank = state.get('orientations')
        history_x,history_y = copy.deepcopy(state['history_x']),list(state['history_y'])
        model = copy.deepcopy(state.get('surrogate_model'))
        trained_points = int(state.get('surrogate_trained_points',0))
        if model is not None:
            from gisapr_pso_surrogate import validate_model
            validate_model(model)
    if fixed_bank is not None:
        check_bank(fixed_bank,objective.context)
        fixed_bank = copy.deepcopy(fixed_bank)
    if best_bank is not None:
        check_bank(best_bank,objective.context)
        if best_bank['pose'] != gbest.tolist():
            raise ValueError('PSO best orientation bank belongs to another pose')

    def velocity_status():
        # Native pose units: rotation-vector degrees and translation angstroms.
        # Use the final velocity, including guidance/noise and bound correction.
        maximum = float(np.max(np.abs(velocities)))
        return dict(max_abs_velocity=maximum,converge_velocities=opt.converge_velocities,
                    velocity_converged=opt.converge_velocities > 0 and maximum < opt.converge_velocities)

    def snapshot():
        return dict(stage='swarm',positions=positions.tolist(),velocities=velocities.tolist(),
                    pbest_positions=pbests.tolist(),pbest_scores=pbest_scores.tolist(),
                    x=gbest.tolist(),fun=float(gbest_score),orientations=best_bank,fixed_orientations=fixed_bank,
                    nit=nit,nfev=nfev,requested=requested,memo_hits=hits_total,sigma=sigma,rng=pack_rng(rng),
                    bounds=[lb.tolist(),ub.tolist()],pivot=pivot.tolist(),dynamics=dynamics_signature(opt),
                    history_x=history_x,history_y=history_y,surrogate_model=model,surrogate_trained_points=trained_points,
                    **velocity_status())

    if reset_velocities:
        proposed = positions+rng.uniform(-1.,1.,size=positions.shape)
        moved = np.clip(proposed,lb,ub)
        velocities,positions = moved-positions,moved
        state = snapshot()
        if on_round:
            on_round(state,dict(round=nit,event='velocity_reset',called=0,nfev=nfev,fun=gbest_score,wall_s=0.))
    reason = 'iteration_limit'
    # A resumed completed swarm may already satisfy the current threshold.
    # Fresh swarms and explicit velocity resets must complete a scored round.
    if state is not None and not reset_velocities and velocity_status()['velocity_converged']:
        reason = 'velocity_convergence'
    with ThreadPoolExecutor(max_workers=opt.max_workers) as executor:
        while nit < limit and reason != 'velocity_convergence':
            jobs = {pose_key(p):p.copy() for p in positions}
            misses = sum(not objective.cached(p,fixed_bank) for p in jobs.values())
            if opt.max_evals and nfev+misses > opt.max_evals:
                if state is None:
                    raise ValueError('PSO budget cannot cover the first complete swarm evaluation')
                reason = 'evaluation_limit_before_full_swarm'
                break
            before = metrics() if metrics else {}
            started = time.monotonic()
            batched = getattr(objective, 'batch_enabled', False)
            if batched:
                futures = {executor.submit(objective.evaluate_many, list(jobs.values()),
                           [slots[i % len(slots)] for i in range(len(jobs))], fixed_bank): None}
            else:
                futures = {executor.submit(objective.evaluate,p,slots[i%len(slots)],fixed_bank):key
                           for i,(key,p) in enumerate(jobs.items())}
            pending,results = set(futures),{}
            report_at = started+opt.progress_interval
            while pending:
                done,pending = wait(pending,timeout=max(0.,report_at-time.monotonic()),return_when=FIRST_COMPLETED)
                for future in done:
                    value = future.result()
                    if batched:
                        if len(value) != len(jobs) or any(not math.isfinite(v.value) for v in value):
                            raise ValueError('PSO batch returned invalid scores')
                        results.update(zip(jobs, value))
                        continue
                    if not math.isfinite(value.value):
                        raise ValueError('PSO objective returned a nonfinite score')
                    results[futures[future]] = value
                heartbeat = time.monotonic() >= report_at
                if on_progress:
                    on_progress(nit+1,len(results),len(jobs),time.monotonic()-started,heartbeat)
                if heartbeat:
                    report_at = time.monotonic()+opt.progress_interval
            ordered = [results[pose_key(p)] for p in positions]
            scores = np.asarray([r.value for r in ordered])
            hits = sum(r.cached for r in results.values())
            calls = len(results)-hits
            nfev += calls
            requested += len(positions)
            hits_total += hits
            evaluated = positions.copy()
            if opt.use_surrogate:
                history_x.extend(positions.tolist()); history_y.extend(scores.tolist())
                if nit >= opt.surrogate_start and (nit-opt.surrogate_start)%opt.surrogate_every == 0 and len(history_y)>=opt.surrogate_min_points:
                    from gisapr_pso_surrogate import train_model
                    model = train_model(history_x,history_y,opt.surrogate_hidden,opt.surrogate_seed)
                    trained_points = len(history_y)
            improved = scores < pbest_scores
            pbests[improved] = positions[improved]
            pbest_scores[improved] = scores[improved]
            best = int(np.argmin(scores))
            old_best = gbest_score
            if scores[best] < gbest_score:
                gbest,gbest_score,best_bank = positions[best].copy(),float(scores[best]),ordered[best].bank
            positions,velocities,guided,clipped = advance(positions,velocities,pbests,gbest,gbest_score,
                scores,lb,ub,pivot,opt,nit,sigma,rng,model)
            weight = inertia_weight(nit,opt)
            nit += 1
            sigma *= opt.noise_decay
            if not math.isfinite(sigma):
                raise ValueError('PSO noise strength overflowed')
            state = snapshot()
            if state['velocity_converged']:
                reason = 'velocity_convergence'
                # Persist the reason in the round checkpoint before the callback.
                state['stop_reason'] = reason
            after = metrics() if metrics else {}
            if on_round:
                on_round(state,dict(round=nit,event='iteration',fun=gbest_score,pose=gbest.tolist(),
                    improvement=None if not math.isfinite(old_best) else old_best-gbest_score,
                    pbest_improved=int(improved.sum()),called=calls,nfev=nfev,memo_hits=hits,
                    w=weight,sigma=sigma,clipped_particles=clipped,surrogate_guided=guided,
                    surrogate_trained_points=trained_points,energy_std=float(scores.std()),
                    population_std=((evaluated-lb)/(ub-lb)).std(axis=0).tolist(),
                    score_scope='fixed_topk' if fixed_bank is not None else 'full_local',
                    **velocity_status(),stop_reason=reason if state['velocity_converged'] else None,
                    wall_s=time.monotonic()-started,metrics={k:v-before.get(k,0.) for k,v in after.items()}))
    if state is None:
        raise ValueError('PSO requires at least one complete swarm evaluation')
    state.update(velocity_status())
    state['stop_reason'] = reason
    return state
