"""Optional ver622 MLP guidance, checkpointed as numeric JSON (no pickle).

Only training requires scikit-learn. Predictions use the saved scalers and
ReLU weights, so resume needs no retraining or unrelated result-file scan.
"""
import numpy as np


def require_sklearn():
    try:
        from sklearn.neural_network import MLPRegressor
    except ImportError as exc:
        raise ImportError('PSO_use_surrogate requires scikit-learn; install requirements_pso_surrogate.txt') from exc


def train_model(x, y, hidden, seed):
    from sklearn.pipeline import Pipeline
    from sklearn.preprocessing import StandardScaler
    from sklearn.neural_network import MLPRegressor
    from sklearn.compose import TransformedTargetRegressor
    model = TransformedTargetRegressor(regressor=Pipeline([
        ('x_scaler', StandardScaler()),
        ('mlp', MLPRegressor(hidden_layer_sizes=tuple(hidden), activation='relu',
                             solver='adam', alpha=1e-4, learning_rate_init=3e-4,
                             max_iter=3000, early_stopping=False, random_state=seed))]),
        transformer=StandardScaler())
    model.fit(np.asarray(x, dtype=float), np.asarray(y, dtype=float))
    pipeline = model.regressor_
    scaler, mlp = pipeline.named_steps['x_scaler'], pipeline.named_steps['mlp']
    saved = dict(x_mean=scaler.mean_.tolist(), x_scale=scaler.scale_.tolist(),
                 y_mean=model.transformer_.mean_.tolist(), y_scale=model.transformer_.scale_.tolist(),
                 weights=[w.tolist() for w in mlp.coefs_], biases=[b.tolist() for b in mlp.intercepts_])
    validate_model(saved)
    return saved


def validate_model(saved):
    mean = np.asarray(saved['x_mean'])
    scale = np.asarray(saved['x_scale'])
    if mean.shape != (6,) or scale.shape != (6,) or not np.isfinite([mean,scale]).all() or np.any(scale <= 0):
        raise ValueError('Invalid surrogate input scaler')
    if (np.shape(saved['y_mean']) != (1,) or np.shape(saved['y_scale']) != (1,)
            or not np.isfinite([saved['y_mean'],saved['y_scale']]).all() or saved['y_scale'][0] <= 0):
        raise ValueError('Invalid surrogate output scaler')
    if not saved['weights'] or len(saved['weights']) != len(saved['biases']):
        raise ValueError('Invalid surrogate layers')
    width = 6
    for w,b in zip(saved['weights'], saved['biases']):
        w,b = np.asarray(w),np.asarray(b)
        if w.ndim != 2 or w.shape[0] != width or b.shape != (w.shape[1],) or not np.isfinite(w).all() or not np.isfinite(b).all():
            raise ValueError('Invalid surrogate weights')
        width = w.shape[1]
    if width != 1:
        raise ValueError('Surrogate requires a scalar output')


def predict_model(saved, x):
    a = (np.asarray(x,dtype=float)-saved['x_mean'])/saved['x_scale']
    for i,(w,b) in enumerate(zip(saved['weights'],saved['biases'])):
        a = a @ np.asarray(w) + b
        if i < len(saved['weights'])-1:
            np.maximum(a,0,out=a)
    return a[:,0]*saved['y_scale'][0]+saved['y_mean'][0]
