# GisAPR-210-DE v1.3.2：少颗粒 PSO / APS 加速

在 v1.3.1 大链密度加速基础上，优化重复投影准备、CPU/GPU 重叠和结果存储。PSO / adaptive 的搜索策略、候选数量、迭代上限、方向选择和评分公式保持原样。默认开启新优化，不需要修改原命令的搜索参数。

## 使用

独立解压为 `GisAPR-210-DE-v1.3.2`，将原命令中的程序目录改为此版本，并使用新的输出前缀。不能直接恢复旧代码的检查点。PSO 完成后仍将导出的 BEST_FIT.pdb 作为 APS 输入，以零 pose 开始；两个阶段各自使用原来的命令，APS 仍重新校准方向。

启动时可见：

```text
Projection cache: grids=1024 MiB, filter=128 MiB; coordinate prefetch=on.
Density backend: fused CUDA on cuda:0 ...
```

第二行沿用 v1.3.1 密度后端：需要可加载的 NVRTC；默认 auto 不可用时警告并回退 torch，也可用 `--density_backend cuda` 要求必须启用。没有新增安装依赖。

| 新参数 | 默认 | 说明 |
|---|---:|---|
| `--batch_grid_cache_mb` | 1024 | 每设备投影网格和共轭掩码的缓存上限，0 禁用 |
| `--batch_filter_cache_mb` | 128 | 三维滤波系数缓存上限；box256实际使用64 MiB，0 禁用 |
| `--batch_coordinate_prefetch` | on | 用一个CPU线程提前准备下一个候选坐标；off关闭 |

这些是缓存上限，不会预分配全部容量，也不是整张GPU的总显存上限。FFT、模板、颗粒和三维密度另有显存需求。默认1024 MiB网格预算能容纳本次10颗粒的完整局部方向网格与Top-K网格；更多方向或更大box可能只能部分命中。

同时运行其他程序、希望压低显存占用时，可设：

```text
--batch_grid_cache_mb 128
```

本机该设置下APS对照约0.826秒/轮，默认1024 MiB约0.567秒/轮；PSO方向少，128 MiB通常足够本次数据。参数属于运行签名，调整时使用新输出前缀。

自动批处理条件沿用v1.3.1：CUDA、颗粒数≤128、SplitParticles=1、精简输出。`--evaluation_mode legacy`保持旧路径。更多参数见 [v1.3.1说明](README_v1.3.1_zh.md)。

## 实现

1. **滤波系数复用。** 按原算法的完整平面形状和8切片分块计算sinc²系数，只保存可能含模型数据的中央区域。CPU和CUDA的系数应用已与参考路径逐位比较通过。
2. **投影网格复用。** 缓存键包含旋转矩阵内容、数据类型和批次形状，避免角度表变化后错误命中。保持原投影批大小8，未改变插值、白化或FFT数学流程。超预算时保留稳定子集，避免大方向集循环导致缓存全部失效。
3. **CPU/GPU重叠。** 在GPU计算当前候选时，一个CPU线程只提前准备下一个候选的坐标变换和PDB精度量化。线程不调用CUDA、不修改密度缓存；主线程使用前校验输入身份和pose，失效时重新计算。
4. **批量事务。** 每个设备请求的候选结果一次提交SQLite，保持rollback journal和synchronous=FULL。序列化失败不写入，事务失败回滚；提交完成后才返回结果供优化器推进检查点。典型PSO轮为1次提交，APS筛选/复核为2次。

固定方向PSO/DE进入筛选阶段时，会释放不再使用的初始化方向网格。本次PSO常驻网格约44–46 MiB、滤波系数64 MiB；不会为了500轮固定方向计算长期保留约1 GiB的初始化网格。APS仍可保留完整局部方向的网格用于复核。

## 实测结果

模型为用户指定的 `7zta_fit_into_7k00_remove_merged_AB.pdb`，移动B链密度原子90,040个，固定主体51,843个。使用10个抽样EMPIAR-11241颗粒、构造的约3°均匀方向表、box256/newbox160、apix1.58、200kV、localRange20、Top-K=3。硬件为本机RTX5070Ti，Windows，PyTorch2.10.0+cu128。

独立进程前后顺序复测；每次48个不同姿态，排除首轮预热。各版本、各任务均取6个完整轮次计时，禁用评分缓存。

| 任务 | v1.3.1 | v1.3.2 | 耗时减少 |
|---|---:|---:|---:|
| PSO：12候选，固定Top-K | 0.592秒 | 0.370秒 | 37.5% |
| APS式：12候选＋相同2候选完整复核 | 1.082秒 | 0.567秒 | 47.6% |

仅按该短测均值加权，500轮PSO＋80轮APS的迭代时间约从383秒降至231秒，减少约40%。这是估算，不是两版完整长程搜索的实测比较；启动、校准、检查点、缓存命中和搜索轨迹会影响实际总时长。RTX4090服务器仍需独立测试。

关闭坐标预准备时，APS式对照为0.644秒/轮；网格预算128 MiB时为0.826秒/轮。

两组新旧对照中筛选候选排序全部一致，跨版评分最大绝对差异小于7.6e-5。CUDA原子累加及白化归约存在浮点波动，因此不承诺逐位相同或长期轨迹一致。

完整验证与长测结果见 [VALIDATION_zh.txt](VALIDATION_zh.txt) 和 `validation/v132/`。历史validation文件只代表对应旧版测试。

## 计时和诊断

新增metrics：

- `projection_grid_cache_hits` / `projection_grid_builds`：本轮复用/重建的方向数量之和。
- `projection_filter_cache_hits`：复用已生成滤波系数的候选次数。
- `density_prefetch_hits`：实际使用预准备坐标的候选数；一组12个新候选通常为11。
- `density_prefetch_wait_s`：主线程等待预准备任务的时间。
- `result_batch_commits`：本轮结果批量提交次数，多个设备分别计数。

`density_transform_s`和`density_quantize_s`保留CPU工作耗时，但现在可与投影重叠，不能再与`density_s`或`projection_s`直接相加。`density_s`是主线程密度阶段经过的时间；`execution_s`仍仅包含setup、projection和search。比较总速度使用`wall_s`；CLI整程耗时还包含初始化、检查点写入和最终导出。

## 对照复现

```bash
python -m unittest discover -s tests -v
```

`benchmarks/compare_density_rounds.py`沿用共同bank、不同姿态和相同复核候选的对照方法。新增`--screen-only`模拟PSO：不做完整复核、不保留候选三维体。默认模拟APS的12＋2流程。先运行参考版本，再以`--reference old.json`运行新版。完整命令保存在`validation/v132/*_command.json`，跨机器需替换数据和程序路径，并在STAR的相对MRC路径可解析的目录运行。

新增检查覆盖网格预算与淘汰、矩阵变化失效、滤波逐位一致、预准备身份校验、CUDA预准备前后评分、数据库批提交与回滚。Linux GPU实际执行、物理多GPU和结构科学准确率不在本次验证范围内。
