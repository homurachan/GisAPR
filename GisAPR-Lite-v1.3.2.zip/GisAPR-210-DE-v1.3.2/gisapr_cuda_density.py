"""Fused atom deposition on PyTorch's current CUDA stream, using NVRTC.

No CuPy, Triton, nvcc, or C++ host compiler is required. NVRTC is discovered
in the active CUDA/PyTorch environment. Compilation failures allow the caller
to use the reference PyTorch implementation; launch failures are never hidden.
The module owns only compiled code, not tensors or numerical result caches.
"""
import ctypes as C
import ctypes.util
import os
from pathlib import Path
import sys
import threading
import warnings

_kernels = {}
_unavailable = {}
_lock = threading.Lock()

_SOURCE = r'''
extern "C" __global__ void deposit(const float *xyz, const float *numbers,
    float *volume, int n, int box, int width, double apix, double rp, double kn) {
    int atom = blockIdx.x;
    if (atom >= n || numbers[atom] == 0.0f) return;
    __shared__ float pos[3];
    __shared__ int lo[3], span[3];
    if (threadIdx.x == 0) {
        for (int k = 0; k < 3; ++k) {
            // Match the reference double division then float32 positions.
            float p = (float)((double)xyz[3*atom+k] / apix + (box / 2));
            pos[k] = p;
            float l = p - (float)width, u = p + (float)width;
            double lower = copysign(floor(fabs((double)l) + 0.5), (double)l);
            double upper = copysign(floor(fabs((double)u) + 0.5), (double)u);
            // The old code clips to box-1 and EXCLUDES the upper voxel.
            double a = fmax(0.0, fmin((double)box, lower));
            double b = fmax(0.0, fmin((double)(box-1), upper));
            lo[k] = (int)a;
            span[k] = (int)fmax(0.0, b-a);
        }
    }
    __syncthreads();
    long long count = (long long)span[0]*span[1]*span[2];
    for (long long i = threadIdx.x; i < count; i += blockDim.x) {
        int x = lo[0] + i % span[0];
        long long yz = i / span[0];
        int y = lo[1] + yz % span[1];
        int z = lo[2] + yz / span[1];
        float dx = (float)x-pos[0], dy = (float)y-pos[1], dz = (float)z-pos[2];
        float radius = sqrtf((dx*dx + dy*dy) + dz*dz);
        float exponent = (float)(-(double)radius * rp);
        float value = (float)(((double)numbers[atom] * kn) * (double)expf(exponent));
        atomicAdd(volume + x + (long long)box*(y + (long long)box*z), value);
    }
}
'''


def _bind(lib, name, args):
    fn = getattr(lib, name)
    fn.argtypes, fn.restype = args, C.c_int
    return fn


def _nvrtc_library():
    import torch
    roots = [Path(torch.__file__).parent/'lib', Path(sys.prefix)/'lib',
             Path(sys.prefix)/'Library'/'bin']
    for item in sys.path:
        if item:
            roots.extend([Path(item)/'nvidia'/'cuda_nvrtc'/'lib',
                          Path(item)/'nvidia'/'cu13'/'lib'])
    for key in ('CUDA_PATH', 'CUDA_HOME'):
        if os.environ.get(key):
            roots.extend(Path(os.environ[key])/d for d in ('bin', 'lib64'))
    roots.extend(Path(p) for p in os.environ.get('LD_LIBRARY_PATH', '').split(os.pathsep) if p)
    pattern = 'nvrtc64_*.dll' if os.name == 'nt' else 'libnvrtc.so*'
    candidates = []
    for root in dict.fromkeys(roots):
        if root.is_dir():
            candidates.extend(str(p) for p in sorted(root.glob(pattern)) if '.alt.' not in p.name)
    found = ctypes.util.find_library('nvrtc')
    if found:
        candidates.append(found)
    if os.name != 'nt':
        candidates.extend(['libnvrtc.so', 'libnvrtc.so.12', 'libnvrtc.so.11.2', 'libnvrtc.so.13'])
    errors = []
    for name in dict.fromkeys(candidates):
        try:
            return C.CDLL(name)
        except OSError as exc:
            errors.append(str(exc))
    raise RuntimeError('NVRTC library not found in the active CUDA environment' +
                       (': ' + errors[-1] if errors else ''))


class _Kernel:
    def __init__(self, device):
        import torch
        p, i, u = C.c_void_p, C.c_int, C.c_uint
        self.driver = (C.WinDLL('nvcuda.dll') if os.name == 'nt' else C.CDLL('libcuda.so.1'))
        self.nvrtc = rtc = _nvrtc_library()
        self.error_name = _bind(self.driver, 'cuGetErrorName', [i, C.POINTER(C.c_char_p)])
        self.launch = _bind(self.driver, 'cuLaunchKernel', [p, u, u, u, u, u, u, u, p,
                                                          C.POINTER(p), C.POINTER(p)])
        load = _bind(self.driver, 'cuModuleLoadData', [C.POINTER(p), p])
        get_function = _bind(self.driver, 'cuModuleGetFunction', [C.POINTER(p), p, C.c_char_p])
        unload = _bind(self.driver, 'cuModuleUnload', [p])
        create = _bind(rtc, 'nvrtcCreateProgram', [C.POINTER(p), C.c_char_p, C.c_char_p, i, p, p])
        compile_program = _bind(rtc, 'nvrtcCompileProgram', [p, i, C.POINTER(C.c_char_p)])
        destroy = _bind(rtc, 'nvrtcDestroyProgram', [C.POINTER(p)])
        get_size = _bind(rtc, 'nvrtcGetPTXSize', [p, C.POINTER(C.c_size_t)])
        get_ptx = _bind(rtc, 'nvrtcGetPTX', [p, p])
        log_size = _bind(rtc, 'nvrtcGetProgramLogSize', [p, C.POINTER(C.c_size_t)])
        get_log = _bind(rtc, 'nvrtcGetProgramLog', [p, p])
        major, minor = torch.cuda.get_device_capability(device)
        arch = major*10 + minor
        if hasattr(rtc, 'nvrtcGetSupportedArchs'):
            count = i()
            self.check_rtc(_bind(rtc, 'nvrtcGetNumSupportedArchs', [C.POINTER(i)])(C.byref(count)))
            supported = (i*count.value)()
            self.check_rtc(_bind(rtc, 'nvrtcGetSupportedArchs', [C.POINTER(i)])(supported))
            choices = [a for a in supported if a <= arch]
            if not choices:
                raise RuntimeError('NVRTC does not support this GPU architecture')
            arch = max(choices)
        options = [f'--gpu-architecture=compute_{arch}'.encode(), b'--std=c++11',
                   b'--fmad=false', b'--ftz=false', b'--prec-div=true', b'--prec-sqrt=true']
        program = p()
        self.check_rtc(create(C.byref(program), _SOURCE.encode(), b'gisapr_density.cu', 0, None, None))
        try:
            status = compile_program(program, len(options), (C.c_char_p*len(options))(*options))
            if status:
                size = C.c_size_t()
                self.check_rtc(log_size(program, C.byref(size)))
                log = C.create_string_buffer(size.value)
                self.check_rtc(get_log(program, log))
                raise RuntimeError('NVRTC density compilation failed: ' + log.value.decode(errors='replace'))
            size = C.c_size_t()
            self.check_rtc(get_size(program, C.byref(size)))
            ptx = C.create_string_buffer(size.value)
            self.check_rtc(get_ptx(program, ptx))
        finally:
            destroy(C.byref(program))
        self.module, self.function = p(), p()
        self.check(load(C.byref(self.module), ptx))
        try:
            self.check(get_function(C.byref(self.function), self.module, b'deposit'))
        except Exception:
            unload(self.module)
            raise
        # Keep the loaded module alive until the worker exits; no tensor cache.
        print(f'Density backend: fused CUDA on {device} (compute_{arch})', flush=True)

    @staticmethod
    def check_rtc(code):
        if code:
            raise RuntimeError(f'NVRTC error {code}')

    def check(self, code):
        if code:
            name = C.c_char_p()
            self.error_name(code, C.byref(name))
            raise RuntimeError(f'CUDA density error {code}: {name.value!r}')

    def run(self, xyz, numbers, volume, width, apix, rp, kn):
        import torch
        args = [C.c_void_p(xyz.data_ptr()), C.c_void_p(numbers.data_ptr()),
                C.c_void_p(volume.data_ptr()), C.c_int(len(xyz)), C.c_int(volume.shape[0]),
                C.c_int(width), C.c_double(apix), C.c_double(rp), C.c_double(kn)]
        pointers = (C.c_void_p*len(args))(*(C.cast(C.byref(a), C.c_void_p) for a in args))
        stream = torch.cuda.current_stream(volume.device)
        self.check(self.launch(self.function, len(xyz), 1, 1, 256, 1, 1, 0,
                               C.c_void_p(stream.cuda_stream), pointers, None))


def accumulate(xyz, numbers, volume, width, apix, rp, kn, required=False):
    """Return True if launched; False only when the backend is unavailable."""
    import torch
    if volume.device.type != 'cuda':
        if required:
            raise RuntimeError('--density_backend cuda requires a CUDA device')
        return False
    # Device context and stream belong to PyTorch, including non-default streams.
    with torch.cuda.device(volume.device):
        device = volume.device.index
        with _lock:
            if device not in _kernels and device not in _unavailable:
                try:
                    _kernels[device] = _Kernel(volume.device)
                except (OSError, RuntimeError, AttributeError) as exc:
                    _unavailable[device] = str(exc)
                    if not required:
                        warnings.warn('Fused density unavailable; using PyTorch: ' + str(exc), RuntimeWarning)
        if device in _unavailable:
            if required:
                raise RuntimeError(_unavailable[device])
            return False
        _kernels[device].run(xyz, numbers, volume, width, apix, rp, kn)
    return True
