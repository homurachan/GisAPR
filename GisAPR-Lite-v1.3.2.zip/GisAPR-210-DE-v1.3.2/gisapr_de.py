"""Checkpointable DE/rand/1/bin with deferred, parallel score evaluation.

Mutation/crossover operate in normalized bound coordinates. Each target uses
three distinct donors excluding itself. Out-of-bound mutant coordinates are
resampled uniformly. No gradients, score surrogate, or local polish is used.
"""
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass
import copy
import math
import time

import numpy as np
from scipy.stats import qmc

from func_v2 import pose_key


@dataclass
class DEOptions:
    population: int = 128
    generations: int = 300
    mutation: tuple = (.5, 1.)
    crossover: float = .7
    init: str = 'sobol'
    seed: int = 0
    max_workers: int = 3
    max_evals: int = 0
    tol: float = 0.
    atol: float = 0.

    def validate(self):
        if self.population < 4 or self.generations < 0 or self.max_workers < 1 or self.max_evals < 0 or self.seed < 0:
            raise ValueError('Require population>=4, workers>=1 and nonnegative budgets/seed')
        if (len(self.mutation) != 2 or not all(math.isfinite(x) for x in self.mutation)
                or not 0 < self.mutation[0] <= self.mutation[1] < 2):
            raise ValueError('DE_mutation requires 0 < F_min <= F_max < 2')
        if not math.isfinite(self.crossover) or not 0 <= self.crossover <= 1:
            raise ValueError('DE_crossover must be in [0,1]')
        if not all(math.isfinite(x) and x >= 0 for x in (self.tol, self.atol)):
            raise ValueError('DE_tol and DE_atol must be finite and nonnegative')
        if self.init not in ('sobol', 'latinhypercube', 'random'):
            raise ValueError('Unknown DE initialization')

    @property
    def size(self):
        return 2 ** (self.population - 1).bit_length() if self.init == 'sobol' else self.population


def trial_population(population, rng, mutation, crossover):
    """Input/output are normalized populations; no in-generation replacement."""
    size, dimensions = population.shape
    factor = rng.uniform(*mutation) if mutation[0] != mutation[1] else mutation[0]
    trial = np.empty_like(population)
    indices = np.arange(size)
    for i in range(size):
        a, b, c = rng.choice(indices[indices != i], size=3, replace=False)
        mutant = population[a] + factor * (population[b] - population[c])
        outside = (mutant < 0) | (mutant > 1)
        mutant[outside] = rng.random(np.count_nonzero(outside))
        cross = rng.random(dimensions) < crossover
        cross[rng.integers(dimensions)] = True
        trial[i] = np.where(cross, mutant, population[i])
    return trial


def differential_evolution(objective, bounds, options=None, *, x0=None, slots=None,
                           state=None, on_round=None, metrics=None, fixed_bank=None,
                           initial_calls=0, initial_requests=0):
    opt = options or DEOptions()
    opt.validate()
    lb, ub = (np.asarray(x, dtype=float) for x in bounds)
    if (lb.shape != (6,) or ub.shape != (6,) or not np.isfinite([lb, ub]).all()
            or np.any(lb >= ub) or not np.isfinite(ub - lb).all()):
        raise ValueError('DE requires six finite, ordered bounds with finite widths')
    if x0 is not None:
        x0 = np.asarray(x0, dtype=float)
        if x0.shape != (6,) or not np.isfinite(x0).all() or np.any(x0 < lb) or np.any(x0 > ub):
            raise ValueError('Pattern_initial must be a finite six-vector inside Pattern_Bounds')
    slots = slots or [None]
    rng = np.random.default_rng(opt.seed)
    width = ub - lb
    if state is not None:
        saved_bank = state.get('fixed_orientations')
        if fixed_bank is not None and fixed_bank != saved_bank:
            raise ValueError('Cannot change the fixed orientation bank while resuming DE')
        fixed_bank = saved_bank
    if fixed_bank is not None:
        from orientation_bank_v1 import check_bank
        check_bank(fixed_bank, objective.context)
        fixed_bank = copy.deepcopy(fixed_bank)
    if initial_calls < 0 or initial_requests < initial_calls:
        raise ValueError('Invalid calibration call counters')

    def count_misses(points):
        unique = {pose_key(p): p for p in points}
        return sum(not objective.cached(p, fixed_bank) for p in unique.values())

    with ThreadPoolExecutor(max_workers=opt.max_workers) as executor:
        def evaluate(points):
            # Exact duplicate poses share one call, including no-cache mode.
            unique = {pose_key(p): p for p in points}
            items = list(unique.items())
            def job(item):
                index, (key, pose) = item
                result = objective.evaluate(pose, slots[index % len(slots)], fixed_bank)
                if not math.isfinite(result.value):
                    raise ValueError('DE objective returned a nonfinite value')
                return key, result
            if getattr(objective, 'batch_enabled', False):
                values = objective.evaluate_many([p for _, p in items],
                    [slots[i % len(slots)] for i in range(len(items))], fixed_bank)
                if any(not math.isfinite(v.value) for v in values):
                    raise ValueError('DE objective returned a nonfinite value')
                results = dict(zip(unique, values))
            else:
                results = dict(executor.map(job, enumerate(items)))
            hits = sum(r.cached for r in results.values())
            return [results[pose_key(p)] for p in points], len(items) - hits, hits

        if state is None:
            if opt.init == 'sobol':
                population = qmc.Sobol(6, scramble=True, seed=opt.seed).random_base2(int(math.log2(opt.size)))
            elif opt.init == 'latinhypercube':
                population = qmc.LatinHypercube(6, seed=opt.seed).random(opt.size)
            else:
                population = rng.random((opt.size, 6))
            population = lb + population * width
            if x0 is not None:
                population[0] = x0
            if opt.max_evals and initial_calls + count_misses(population) > opt.max_evals:
                raise ValueError('DE evaluation budget cannot cover the initial population')
            started = time.perf_counter()
            results, calls, hits = evaluate(population)
            values = np.array([r.value for r in results])
            best = int(np.argmin(values))
            state = dict(population=population.tolist(), energies=values.tolist(),
                         x=population[best].tolist(), fun=float(values[best]),
                         orientations=results[best].bank, bounds=[lb.tolist(), ub.tolist()],
                         fixed_orientations=fixed_bank, stage='population',
                         nit=0, nfev=initial_calls+calls, requested=initial_requests+len(population),
                         memo_hits=hits+initial_requests-initial_calls,
                         rng=rng.bit_generator.state)
            if on_round:
                on_round(state, dict(round=0, event='initial', fun=state['fun'], pose=state['x'],
                                     nfev=state['nfev'], called=calls,
                                     score_scope='fixed_topk' if fixed_bank is not None else 'full_local',
                                     wall_s=time.perf_counter()-started))
        else:
            population = np.asarray(state['population'], dtype=float)
            values = np.asarray(state['energies'], dtype=float)
            if (population.shape != (opt.size, 6) or values.shape != (opt.size,)
                    or not np.isfinite(population).all() or not np.isfinite(values).all()
                    or np.any(population < lb) or np.any(population > ub)
                    or not np.array_equal(state['bounds'], [lb, ub])):
                raise ValueError('Invalid DE checkpoint population/bounds')
            matches = np.all(population == state['x'], axis=1) & (values == state['fun'])
            if not np.any(matches) or state['fun'] != float(values.min()):
                raise ValueError('DE checkpoint incumbent does not match population')
            if state['orientations'] is not None and state['orientations']['pose'] != state['x']:
                raise ValueError('DE checkpoint orientation bank belongs to another pose')
            if state['nit'] < 0 or state['nfev'] < 0:
                raise ValueError('Invalid DE checkpoint counters')
            rng.bit_generator.state = state['rng']

        reason = 'generation_limit'
        while state['nit'] < opt.generations:
            if ((opt.tol > 0 or opt.atol > 0) and
                    np.std(values) <= opt.atol + opt.tol * abs(np.mean(values))):
                reason = 'energy_tolerance'
                break
            # Preserve RNG at the last completed generation on budget stop.
            previous_rng = rng.bit_generator.state
            unit = trial_population((population - lb) / width, rng, opt.mutation, opt.crossover)
            trials = np.clip(lb + unit * width, lb, ub)
            if opt.max_evals and state['nfev'] + count_misses(trials) > opt.max_evals:
                rng.bit_generator.state = previous_rng
                reason = 'evaluation_limit_before_full_generation'
                break
            before = metrics() if metrics else {}
            started = time.perf_counter()
            results, calls, hits = evaluate(trials)
            scores = np.asarray([r.value for r in results])
            accepted = scores <= values
            population[accepted] = trials[accepted]
            values[accepted] = scores[accepted]
            old_fun = state['fun']
            best = int(np.argmin(values))
            # Keep the saved incumbent on ties unless its pose was replaced.
            if values[best] < old_fun or not np.any(np.all(population == state['x'], axis=1) & (values == old_fun)):
                state['x'] = population[best].tolist()
                state['fun'] = float(values[best])
                if accepted[best]:
                    state['orientations'] = results[best].bank
                else:
                    # A tied previous member may become best after a tied swap.
                    state['orientations'] = None
            state.update(population=population.tolist(), energies=values.tolist(),
                         nit=state['nit']+1, nfev=state['nfev']+calls,
                         requested=state['requested']+len(trials), memo_hits=state['memo_hits']+hits,
                         rng=rng.bit_generator.state)
            after = metrics() if metrics else {}
            if on_round:
                on_round(state, dict(round=state['nit'], event='generation', fun=state['fun'],
                                     score_scope='fixed_topk' if fixed_bank is not None else 'full_local',
                                     pose=state['x'], improvement=old_fun-state['fun'],
                                     accepted=int(accepted.sum()), called=calls, memo_hits=hits,
                                     nfev=state['nfev'], energy_std=float(values.std()),
                                     population_std=((population-lb)/width).std(axis=0).tolist(),
                                     wall_s=time.perf_counter()-started,
                                     metrics={k: v-before.get(k, 0.) for k,v in after.items()}))
        state['stop_reason'] = reason
        return state
