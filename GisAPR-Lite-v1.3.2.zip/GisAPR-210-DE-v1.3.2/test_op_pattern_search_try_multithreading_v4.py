#!/usr/bin/env python3
"""Coordinate-axis Pattern Search with Top-K particle orientation screening."""
from test_op_adaptive_pattern_search_v2 import main


if __name__ == '__main__':
    main(fixed=True)
