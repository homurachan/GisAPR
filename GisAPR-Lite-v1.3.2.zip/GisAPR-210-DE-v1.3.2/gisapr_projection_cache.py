"""Bounded reuse of geometry-only projection data; never cache model values."""
from collections import OrderedDict

import torch


class ProjectionGridCache:
    def __init__(self, max_mb):
        self.limit = max(0, int(float(max_mb) * 1024**2))
        self.entries = OrderedDict()
        self.bytes = 0

    def get(self, key):
        pair = self.entries.get(key)
        if pair is not None:
            self.entries.move_to_end(key)
        return pair

    def retain_only(self, keys):
        before = self.bytes
        for key in list(self.entries):
            if key not in keys:
                self.bytes -= self.size(self.entries.pop(key))
        return before - self.bytes

    @staticmethod
    def size(pair):
        return sum(x.numel() * x.element_size() for x in pair)

    def put(self, key, pair, protected):
        """Keep a stable subset when the current direction set exceeds budget.

        Evict only entries outside the current request. Otherwise cycling a
        large direction set through a small LRU would give zero reuse.
        """
        size = self.size(pair)
        if not self.limit or size > self.limit or key in self.entries:
            return False
        for old_key in list(self.entries):
            if self.bytes + size <= self.limit:
                break
            if old_key not in protected:
                self.bytes -= self.size(self.entries.pop(old_key))
        if self.bytes + size > self.limit:
            return False
        self.entries[key] = pair
        self.bytes += size
        return True


class ProjectionFilterCache:
    def __init__(self, box, device, max_mb):
        self.box = int(box)
        self.device = device
        self.limit = max(0, int(float(max_mb) * 1024**2))
        self.filter = None

    def apply(self, padded, fallback):
        """Return (used, hit); padded zeros need no multiplication.

        Build with the original full-plane shapes and 8-slice chunks, then
        retain only the central region that can contain model density.
        """
        n = self.box
        if n**3 * 4 > self.limit:
            fallback(padded, z_chunk=8)
            return False, False
        hit = self.filter is not None
        pad = n // 2
        if not hit:
            f = torch.fft.fftshift(torch.fft.fftfreq(2*n, device=self.device, dtype=torch.float32))
            fy2, fx2 = f.view(1, 2*n, 1)**2, f.view(1, 1, 2*n)**2
            self.filter = torch.empty((n, n, n), dtype=torch.float32, device=self.device)
            # Align chunks with the reference even if n//2 is not divisible by 8.
            for z0 in range((pad//8)*8, pad+n, 8):
                z1 = min(z0+8, 2*n)
                radius = torch.sqrt(f[z0:z1].view(-1, 1, 1)**2 + fy2 + fx2)
                value = torch.sinc(radius).square_()
                a, b = max(z0, pad), min(z1, pad+n)
                self.filter[a-pad:b-pad] = value[a-z0:b-z0, pad:pad+n, pad:pad+n]
        padded[pad:pad+n, pad:pad+n, pad:pad+n].mul_(self.filter)
        return True, hit
