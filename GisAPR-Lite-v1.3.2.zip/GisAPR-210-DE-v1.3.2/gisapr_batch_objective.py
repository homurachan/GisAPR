"""Controller-side round batching; no torch import or CUDA state here."""
from concurrent.futures import ThreadPoolExecutor
import math

from gisapr_runtime_v2 import batch_worker_slots, get_worker, record_metrics
from orientation_bank_v1 import check_bank, pack_bank


def configure_batch(objective, particle_count):
    args = objective.args
    mode = getattr(args, 'evaluation_mode', 'auto')
    supported = (objective.compact and int(args.SplitParticles) == 1
                 and getattr(args, 'optimizer', '') != 'MultiStart')
    if mode == 'batch' and not supported:
        raise ValueError('Batch evaluation supports PSO, DE and Pattern/Adaptive with '
                         'SplitParticles=1 and compact in-memory output; '
                         'remove keep_intermediates/write_model_mrc or use evaluation_mode legacy.')
    devices = batch_worker_slots(args)
    objective.batch_enabled = supported and (mode == 'batch' or
        (mode == 'auto' and particle_count <= 128 and all(s[0] != 'cpu' for s in devices)))
    args._round_batch_enabled = objective.batch_enabled
    objective.batch_slots = devices


def search_arguments(args):
    # mrc/o are compatibility placeholders; the batch worker never opens them.
    values = dict(i=args.ang, ang=args.ang, p=args.STAR_NAME, mrc='unused.mrc', o='unused.txt',
        start=-1, end=-1, oriboxsize=args.boxsize, newboxsize=args.newboxsize,
        apix=args.apix, voltage=args.voltage, cs=args.cs, kk=args.kk, psiStep=args.psiStep,
        maskRadius=args.maskRadius, localRange=args.local_stepsize, transRange=args.transRange,
        ctf_cache_mb=args.ctf_cache_mb, search_cache_mb=args.search_cache_mb,
        fixed_density_cache_mb=args.fixed_density_cache_mb, projection_mode=args.projection_mode,
        **{'keep-orientations': args.keep_orientations})
    if args.fsc_file:
        values['FSC'] = args.fsc_file
    result = [part for k, v in values.items() for part in ('--' + k, str(v))]
    for flag, enabled in [('ignoreFSC', args.do_ignoreFSC), ('doLocalSearch', args.do_local_search)]:
        if enabled:
            result.append('--' + flag)
    return result


def evaluate_many(objective, poses, bank):
    from func_v2 import Evaluation, pose_key
    args = objective.args
    if bank is not None:
        check_bank(bank, objective.context)
    unique = {pose_key(p): list(map(float, p)) for p in poses}
    results, pending = {}, []
    for key, pose in unique.items():
        saved = None if args.no_result_cache else objective.store.get(key, bank)
        if saved is not None:
            ranked = saved['ranked']
            if ranked is not None:
                check_bank(ranked, objective.context)
                if ranked['pose'] != pose:
                    raise ValueError('Cached orientation bank belongs to another pose')
            results[key] = Evaluation(saved['meta']['objective'], ranked, True)
            record_metrics(reused=1)
        else:
            pending.append((key, pose))
    if not pending:
        return [results[pose_key(p)] for p in poses]

    groups = [[] for _ in objective.batch_slots]
    for i, item in enumerate(pending):
        groups[i % len(groups)].append(item)
    options = {name: getattr(args, name) for name in (
        'batch_candidates', 'batch_template_mb', 'batch_particle_cache_mb',
        'batch_volume_cache_mb', 'batch_density_mode', 'batch_projection_mode')}
    options['density_backend'] = getattr(args, 'density_backend', 'auto')
    for name, default in [('batch_grid_cache_mb', 1024.), ('batch_filter_cache_mb', 128.),
                          ('batch_coordinate_prefetch', 'on')]:
        options[name] = getattr(args, name, default)
    options['retain_volumes'] = getattr(args, 'optimizer', '') not in ('PSO', 'DE')

    def group_job(item):
        slot, group = item
        if not group:
            return {}
        worker = get_worker(slot, args.search_script)
        found, accepted, metas, writes = {}, [], [], []
        for key, pose in group:
            meta = dict(pose_hex=key, source_bank=None if bank is None else bank['sha256'],
                        pose=pose, pdb=None, result=None, has_score_result=False,
                        phase='full' if bank is None else 'screen', evaluation_backend='round_batch')
            if not args.skip_geometric_restraint:
                overlap, distance = worker.request('geometry', geometry_kwargs=dict(
                    pdb_path=args.PDB_NAME, chain_id=args.rotate_chain, boxsize=256,
                    apix=1.5, threshold=1.), pose=pose)
                if overlap >= args.MAXIUM_ALLOWED_overlapped_pixels or distance >= args.MAX_MinDistance_Allowed:
                    penalty = float(overlap + args.MAX_MinDistance_Allowed)
                    meta.update(objective=penalty, overlap=overlap, distance=distance)
                    writes.append((key, bank, meta, None, None))
                    found[key] = Evaluation(penalty, None)
                    record_metrics(rejected=1)
                    continue
            accepted.append((key, pose))
            metas.append(meta)
        if not accepted:
            objective.store.put_many(writes)
            record_metrics(result_batch_commits=1)
            return found
        models = [dict(pdb_path=args.PDB_NAME, source_pdb=args.PDB_NAME,
                       chain_id=args.rotate_chain, pose=pose, boxsize=args.boxsize,
                       apix=args.apix_PDB, res=2. * args.apix_PDB, do_yflip=args.yflip)
                  for _, pose in accepted]
        reply = worker.request('search_batch_from_pdb', argv=search_arguments(args),
            models=models, options=options, calibrate=bank is None,
            orientation_rows=None if bank is None else bank['rows'])
        if len(reply) != len(accepted):
            raise ValueError('Incomplete candidate batch returned by worker')
        for (key, pose), meta, result in zip(accepted, metas, reply):
            score = float(result['score'])
            if math.isinf(score) or not result['search_text']:
                raise ValueError('Infinite score or empty batch search result')
            valid = not math.isnan(score)
            if not valid:
                score = 0.
                meta['score_status'] = 'nan_as_zero'
            ranked = None
            if bank is None:
                rows = result['orientation_rows']
                if set(rows) != {str(i) for group in objective.groups for i in group}:
                    raise ValueError('Incomplete particle calibration from batch worker')
                if valid:
                    ranked = pack_bank(objective.context, rows, pose=pose)
                    meta['bank_sha256'] = ranked['sha256']
            metrics = result['metrics']
            meta.update(objective=-score, has_score_result=True, shard_metrics=[metrics])
            writes.append((key, bank, meta, ranked, result['search_text']))
            found[key] = Evaluation(-score, ranked)
            record_metrics(computed=1, **metrics)
        objective.store.put_many(writes)
        record_metrics(result_batch_commits=1)
        return found

    with ThreadPoolExecutor(max_workers=len(groups)) as pool:
        for found in pool.map(group_job, zip(objective.batch_slots, groups)):
            results.update(found)
    return [results[pose_key(p)] for p in poses]
