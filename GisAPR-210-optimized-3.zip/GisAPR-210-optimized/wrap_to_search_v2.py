"""Split particles across configured permanent workers, then merge in STAR order."""
import argparse
from concurrent.futures import ThreadPoolExecutor
from functools import lru_cache
import os
from pathlib import Path
import shlex
import shutil
import subprocess
import sys
import tempfile
import threading
from types import SimpleNamespace

_range_lock = threading.Lock()


def create_SEARCH_parser():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('script', 'i', 'ang', 'mrc', 'p', 'o'):
        parser.add_argument('--' + name, required=True)
    parser.add_argument('--FSC', default=None, help='Optional; omitted means unit FSC weights')
    parser.add_argument('--gpuid', default='0', help='Candidate starting CUDA IDs; repeats create independent workers, e.g. 0:0:0.')
    for name, default in [('kk', 0.), ('apix', 1.42), ('voltage', 300.), ('cs', 2.7),
                          ('psiStep', 15.), ('localRange', 20.)]:
        parser.add_argument('--' + name, type=float, default=default)
    for name, default in [('oriboxsize', 256), ('newboxsize', 256), ('transRange', 0),
                          ('maskRadius', 110), ('maskEdge', 6), ('SplitParticles', 1)]:
        parser.add_argument('--' + name, type=int, default=default)
    for name in ('ignoreFSC', 'discardMask', 'doLocalSearch', 'doSplitDiffGpu'):
        parser.add_argument('--' + name, action='store_true')
    from gisapr_options import nonnegative_mb, add_split_gpu_options
    add_split_gpu_options(parser)
    parser.add_argument('--verbose', action='store_true')
    parser.add_argument('--ctf_cache_mb', type=nonnegative_mb, default=256.)
    parser.add_argument('--search_cache_mb', type=nonnegative_mb, default=64.)
    return parser


def test_length(starfile_name):
    # start/end refer to original STAR line indices, exactly as in v209.
    with open(starfile_name) as handle:
        return sum(1 for _ in handle)


@lru_cache(maxsize=16)
def _particle_line_ranges(identity, count):
    from gisapr_star import find_star_loop, read_text_lines
    required = ('_rlnImageName', '_rlnAngleRot', '_rlnAngleTilt')
    table = find_star_loop(read_text_lines(identity[0]), required)
    required_max = max(table.labels[label] for label in required)
    indices = [i for i in table.data_line_indices if len(table.tokens(i)) > required_max]
    if not indices:
        raise ValueError(f'No valid particle rows in {identity[0]}')
    # Balance actual particles, not headers/comments/optics rows. Keep original
    # line indices for local-map lookup and the three search-output records.
    count = min(count, len(indices))
    quotient, remainder = divmod(len(indices), count)
    ranges = []
    offset = 0
    for i in range(count):
        size = quotient + int(i < remainder)
        ranges.append((indices[offset], indices[offset + size - 1] + 1))
        offset += size
    return tuple(ranges)


def particle_line_ranges(starfile_name, count):
    from gisapr_cache import file_key
    count = int(count)
    if count < 1:
        raise ValueError('SplitParticles must be >= 1')
    # PSO's first concurrent candidates should parse a large STAR only once.
    with _range_lock:
        return _particle_line_ranges(file_key(starfile_name), count)


def assigned_slots(args, available_gpu_ids=None, candidate_worker=None, available_slots=None):
    from gisapr_runtime import configured_worker_slots, normalize_slot, candidate_shard_slots, split_gpu_mode
    if available_slots is None:
        config = args
        if available_gpu_ids is not None:
            config = SimpleNamespace(gpuid=':'.join(map(str, available_gpu_ids)),
                                     SplitParticles=args.SplitParticles, doSplitDiffGpu=args.doSplitDiffGpu,
                                     split_gpu_mode=split_gpu_mode(args))
        available_slots = configured_worker_slots(config)
    candidate = normalize_slot(candidate_worker if candidate_worker is not None else available_slots[0])
    return candidate_shard_slots(args, candidate, available_slots)


def search_argv(args, start, end, serial_number):
    argv = []
    for name in ('i', 'p', 'oriboxsize', 'newboxsize', 'apix', 'transRange', 'voltage',
                 'cs', 'maskRadius', 'maskEdge', 'psiStep', 'kk', 'mrc', 'ang'):
        argv.extend(['--' + name, str(getattr(args, name))])
    if args.FSC and str(args.FSC).strip():
        argv.extend(['--FSC', str(args.FSC)])
    for name in ('ignoreFSC', 'discardMask', 'doLocalSearch'):
        if getattr(args, name):
            argv.append('--' + name)
    if args.doLocalSearch:
        argv.extend(['--localRange', str(args.localRange)])
    # The worker assigns the actual device after parsing this compatibility value.
    argv.extend(['--gpuid', '0', '--start', str(start), '--end', str(end)])
    filename = str(args.o) + '_tmp' + str(serial_number)
    argv.extend(['--o', filename])
    if getattr(args, 'verbose', False):
        argv.append('--verbose')
    for name in ('ctf_cache_mb', 'search_cache_mb'):
        if hasattr(args, name):
            argv.extend(['--' + name, str(getattr(args, name))])
    return argv, filename


def generate_command(args, start, end, serial_number):
    argv, filename = search_argv(args, start, end, serial_number)
    from gisapr_runtime import resolve_script
    slots = assigned_slots(args)
    gpuid = slots[serial_number % len(slots)][0]
    argv[argv.index('--gpuid') + 1] = '0' if gpuid == 'cpu' else gpuid
    return shlex.join([sys.executable, str(resolve_script(args.script)), *argv]), filename


def run_command(command):
    # Kept as a public helper for callers of earlier versions.
    subprocess.run(shlex.split(command), check=True)
    return 0


def run_searches(args, available_gpu_ids=None, model_kwargs=None, *,
                 candidate_worker=None, available_slots=None):
    from gisapr_runtime import get_worker, record_metrics
    ranges = particle_line_ranges(args.p, args.SplitParticles)
    slots = assigned_slots(args, available_gpu_ids, candidate_worker, available_slots)
    selected = [slots[i % len(slots)] for i in range(len(ranges))]
    workers = {slot: get_worker(slot, args.script) for slot in dict.fromkeys(selected)}
    jobs = []
    filenames = []
    for i, (start, end) in enumerate(ranges):
        argv, filename = search_argv(args, start, end, i)
        jobs.append((workers[selected[i]], argv))
        filenames.append(filename)
    if getattr(args, 'verbose', False):
        print(f'Particle shards: {len(ranges)}; workers (device, slot): {selected}', flush=True)
    def execute(job):
        worker, argv = job
        if model_kwargs is None:
            metrics = worker.request('search', argv=argv)
        else:
            metrics = worker.request('search_from_pdb', argv=argv, model_kwargs=model_kwargs)
        if isinstance(metrics, dict):
            record_metrics(**metrics)
    # Only requests to the SAME slot serialize. No request holds another slot's
    # lock, so concurrent PSO candidates can safely share this bounded pool.
    with ThreadPoolExecutor(max_workers=len(workers)) as executor:
        list(executor.map(execute, jobs))
    Path(args.o).parent.mkdir(parents=True, exist_ok=True)
    # Publish only a complete ordered result, preserving an old output if any
    # shard or the merge fails. Score the merged file once, never per shard.
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(mode='wb', dir=Path(args.o).parent,
                                         prefix=Path(args.o).name + '.merge-', delete=False) as output:
            temporary = output.name
            for filename in filenames:
                with open(filename, 'rb') as source:
                    shutil.copyfileobj(source, output)
        os.replace(temporary, args.o)
        temporary = None
        for filename in filenames:
            os.remove(filename)
    finally:
        if temporary is not None:
            os.remove(temporary)
    return args.o


def main():
    from gisapr_runtime import shutdown_workers
    args = create_SEARCH_parser().parse_args()
    try:
        run_searches(args)
    finally:
        shutdown_workers()


if __name__ == '__main__':
    main()
