"""Bounded, host-only caches. No CUDA allocation is kept by this module."""
from collections import OrderedDict
import os
from pathlib import Path
import sys
import threading


def file_key(path):
    path = Path(path).expanduser().resolve()
    stat = path.stat()
    return str(path), stat.st_size, stat.st_mtime_ns, stat.st_ctime_ns


def available_memory():
    try:
        if sys.platform.startswith('linux'):
            with open('/proc/meminfo') as handle:
                for line in handle:
                    if line.startswith('MemAvailable:'):
                        return int(line.split()[1]) * 1024
        elif os.name == 'nt':
            import ctypes
            class MemoryStatus(ctypes.Structure):
                _fields_ = [('length', ctypes.c_ulong), ('load', ctypes.c_ulong),
                            *[(name, ctypes.c_ulonglong) for name in
                              ('total', 'available', 'page', 'free_page', 'virtual',
                               'free_virtual', 'extended')]]
            status = MemoryStatus()
            status.length = ctypes.sizeof(status)
            if ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(status)):
                return int(status.available)
    except (OSError, ValueError, AttributeError):
        pass
    return None


def object_bytes(value, seen=None):
    """Conservative resident-payload estimate, with shared references counted once."""
    seen = set() if seen is None else seen
    if id(value) in seen:
        return 0
    seen.add(id(value))
    size = sys.getsizeof(value)
    if hasattr(value, 'numel') and hasattr(value, 'element_size'):
        return size + value.numel() * value.element_size()
    if hasattr(value, 'nbytes'):
        return size + int(value.nbytes)
    if isinstance(value, dict):
        return size + sum(object_bytes(k, seen) + object_bytes(v, seen) for k, v in value.items())
    if isinstance(value, (list, tuple, set)):
        return size + sum(object_bytes(v, seen) for v in value)
    if hasattr(value, '__dict__'):
        return size + object_bytes(vars(value), seen)
    return size


class HostCache:
    def __init__(self, max_bytes, max_entries=128):
        self.max_bytes = max(0, int(max_bytes))
        self.max_entries = max(0, int(max_entries))
        self.entries = OrderedDict()
        self.bytes = 0
        self.hits = self.misses = 0
        self.lock = threading.RLock()

    def get(self, key):
        with self.lock:
            entry = self.entries.get(key)
            if entry is None:
                self.misses += 1
                return None
            self.hits += 1
            self.entries.move_to_end(key)
            return entry[0]

    def put(self, key, value, evict=True):
        with self.lock:
            size = object_bytes(value) + object_bytes(key)
            available = available_memory()
            # Retain at most 10% of current available RAM in addition to the
            # explicitly configured ceiling. This is a cache, not required state.
            limit = self.max_bytes if available is None else min(self.max_bytes, available // 10)
            if not self.max_entries or size > limit:
                return False
            if not evict and key not in self.entries and (
                    self.bytes + size > limit or len(self.entries) >= self.max_entries):
                return False
            old = self.entries.pop(key, None)
            if old is not None:
                self.bytes -= old[1]
            while self.entries and (self.bytes + size > limit or len(self.entries) >= self.max_entries):
                _, (_, count) = self.entries.popitem(last=False)
                self.bytes -= count
            self.entries[key] = (value, size)
            self.bytes += size
            return True

    def can_store_bytes(self, size, evict=True):
        available = available_memory()
        limit = self.max_bytes if available is None else min(self.max_bytes, available // 10)
        return (self.max_entries > 0 and 0 < size <= limit
                and (evict or (self.bytes + size <= limit and len(self.entries) < self.max_entries)))

    def clear(self):
        with self.lock:
            self.entries.clear()
            self.bytes = 0

    def get_or_build(self, key, factory):
        # Also prevent duplicate first-use parsing in the controller's threads.
        with self.lock:
            value = self.get(key)
            if value is None:
                value = factory()
                self.put(key, value)
            return value


class SearchCache:
    def __init__(self, metadata_mb=64, ctf_mb=256):
        self.metadata = HostCache(float(metadata_mb) * 1024 ** 2, max_entries=32)
        self.ctf = HostCache(float(ctf_mb) * 1024 ** 2, max_entries=256)
        self.ctf_context = None

    def prepare_ctf(self, context):
        if self.ctf_context != context:
            self.ctf.clear()
            self.ctf_context = context
        return self.ctf
