"""Shared v210 STAR parser; no NumPy or PyTorch imports in the controller."""
from dataclasses import dataclass
from typing import Dict, List, Sequence


@dataclass
class StarLoop:
    lines: List[str]
    labels: Dict[str, int]
    data_line_indices: List[int]
    data_start: int

    def tokens(self, line_index: int) -> List[str]:
        return self.lines[line_index].split()


def _parse_label_index(tokens: Sequence[str], fallback: int) -> int:
    for token in tokens[1:]:
        if token.startswith("#"):
            try:
                return int(token[1:]) - 1
            except ValueError:
                pass
    return fallback


def find_star_loop(lines: List[str], required_labels: Sequence[str]) -> StarLoop:
    """Find the loop containing all requested RELION labels."""
    required = set(required_labels)
    n = len(lines)
    i = 0
    while i < n:
        stripped = lines[i].strip()
        if stripped.lower() != "loop_":
            i += 1
            continue

        labels: Dict[str, int] = {}
        j = i + 1
        fallback = 0
        while j < n:
            s = lines[j].strip()
            if not s or s.startswith("#"):
                j += 1
                continue
            if not s.startswith("_"):
                break
            tokens = s.split()
            labels[tokens[0]] = _parse_label_index(tokens, fallback)
            fallback += 1
            j += 1

        if not required.issubset(labels):
            i = max(j, i + 1)
            continue

        data_indices: List[int] = []
        k = j
        data_start = -1
        while k < n:
            s = lines[k].strip()
            lower = s.lower()
            if lower == "loop_" or lower.startswith("data_") or s.startswith("_"):
                if data_indices:
                    break
                k += 1
                continue
            if not s or s.startswith("#"):
                k += 1
                continue
            if data_start < 0:
                data_start = k
            data_indices.append(k)
            k += 1

        if data_start < 0:
            raise ValueError(
                "Found a STAR loop with the required labels but no data rows: "
                + ", ".join(required_labels)
            )
        return StarLoop(lines=lines, labels=labels, data_line_indices=data_indices, data_start=data_start)

    raise ValueError("Cannot find a STAR loop containing: " + ", ".join(required_labels))


def read_text_lines(filename: str) -> List[str]:
    with open(filename, "r", encoding="utf-8", errors="replace") as handle:
        return handle.readlines()


