"""Lightweight controller: one long-lived search process per configured slot.

This module intentionally never imports torch. GPU workers are initialized
sequentially; only their requests run concurrently (important on slow NFS).
"""
import atexit
import os
import secrets
import subprocess
import sys
import threading
import time
from multiprocessing.connection import Listener
from pathlib import Path

SEARCH_SCRIPT = Path(__file__).resolve().with_name(
    "test1_with_isspa_weight_varingKK_search_translation_also_v606_torch_optimized_standalone.py"
)
_workers = {}
_registry_lock = threading.RLock()
_metric_lock = threading.Lock()
_metrics = {}


def record_metrics(**values):
    with _metric_lock:
        for key, value in values.items():
            _metrics[key] = _metrics.get(key, 0.) + float(value)


def metrics_snapshot():
    with _metric_lock:
        return dict(_metrics)


def resolve_script(path=None):
    if not path:
        return SEARCH_SCRIPT
    path = Path(path).expanduser()
    if path.is_file():
        return path.resolve()
    sibling = SEARCH_SCRIPT.parent / path.name
    if not path.is_absolute() and sibling.is_file():
        return sibling
    raise FileNotFoundError(f"Search script not found: {path}")


def worker_slots(value):
    """Repeated IDs explicitly request independent workers on the same device."""
    ids = [part.strip() for part in str(value).split(":") if part.strip()]
    if not ids or any(x != "cpu" and not x.isdigit() for x in ids):
        raise ValueError("--gpuid must be cpu or colon-separated logical CUDA IDs, e.g. 0:1")
    counts = {}
    slots = []
    for gpuid in ids:
        gpuid = gpuid if gpuid == "cpu" else str(int(gpuid))
        slot_id = counts.get(gpuid, 0)
        slots.append((gpuid, slot_id))
        counts[gpuid] = slot_id + 1
    return slots


def device_ids(value):
    """Unique physical IDs; do not use this to size the worker pool."""
    return list(dict.fromkeys(gpuid for gpuid, _ in worker_slots(value)))


def normalize_slot(value):
    if isinstance(value, (tuple, list)) and len(value) == 2:
        gpuid, slot_id = value
    else:
        gpuid, slot_id = value, 0
    parsed = worker_slots(str(gpuid))
    if len(parsed) != 1 or int(slot_id) < 0:
        raise ValueError(f"Invalid worker slot: {value!r}")
    return parsed[0][0], int(slot_id)


def split_gpu_mode(args):
    mode = getattr(args, "split_gpu_mode", "consecutive")
    if mode not in ("consecutive", "pool"):
        raise ValueError("split_gpu_mode must be consecutive or pool")
    return mode


def consecutive_worker_slots(candidate, count):
    """Expand one candidate's starting GPU, preserving its replica number."""
    gpuid, replica = normalize_slot(candidate)
    count = int(count)
    if count < 1:
        raise ValueError("SplitParticles must be >= 1")
    if gpuid == "cpu":
        raise ValueError("CPU workers have no consecutive CUDA device IDs")
    return [(str(int(gpuid) + i), replica) for i in range(count)]


def configured_worker_slots(args):
    slots = worker_slots(args.gpuid)
    count = int(getattr(args, "SplitParticles", 1))
    if count < 1:
        raise ValueError("SplitParticles must be >= 1")
    if getattr(args, "doSplitDiffGpu", False):
        if split_gpu_mode(args) == "consecutive":
            expanded = []
            for slot in slots:
                # CPU diagnostics keep their opt2 shared-pool semantics.
                expanded.extend([slot] if slot[0] == "cpu" else consecutive_worker_slots(slot, count))
            slots = list(dict.fromkeys(expanded))
        elif len(slots) == 1 and slots[0][0] != "cpu":
            # The optional pool mode exactly retains opt2's single-ID fallback.
            slots = consecutive_worker_slots(slots[0], count)
    return slots


def candidate_shard_slots(args, candidate, available_slots=None):
    candidate = normalize_slot(candidate)
    pool = configured_worker_slots(args) if available_slots is None else list(map(normalize_slot, available_slots))
    if candidate not in pool:
        raise ValueError(f"Candidate worker {candidate} is outside the configured pool")
    if not getattr(args, "doSplitDiffGpu", False):
        return [candidate]
    if split_gpu_mode(args) == "pool" or candidate[0] == "cpu":
        return shard_worker_slots(pool, candidate)
    group = consecutive_worker_slots(candidate, args.SplitParticles)
    missing = [slot for slot in group if slot not in pool]
    if missing:
        raise ValueError(f"Consecutive GPU group for {candidate} is missing workers: {missing}")
    return group


def shard_worker_slots(slots, candidate=None):
    """Visit distinct devices before replicas, starting with this candidate."""
    slots = list(dict.fromkeys(normalize_slot(slot) for slot in slots))
    if not slots:
        raise ValueError("At least one worker slot is required")
    device_order = list(dict.fromkeys(slot[0] for slot in slots))
    replica_start = 0
    if candidate is not None:
        candidate = normalize_slot(candidate)
        if candidate not in slots:
            raise ValueError(f"Candidate worker {candidate} is outside the configured pool")
        start = device_order.index(candidate[0])
        device_order = device_order[start:] + device_order[:start]
        replica_start = candidate[1]
    groups = []
    for device in device_order:
        group = sorted(slot for slot in slots if slot[0] == device)
        start = next((i for i, slot in enumerate(group) if slot[1] >= replica_start), 0)
        groups.append(group[start:] + group[:start])
    return [group[i] for i in range(max(map(len, groups))) for group in groups if i < len(group)]


class PermanentWorker:
    def __init__(self, script, gpuid, startup_timeout=900, worker_id=0):
        self.lock = threading.RLock()
        self.process = None
        self.connection = None
        self.gpuid = str(gpuid)
        self.worker_id = int(worker_id)
        self.slot = (self.gpuid, self.worker_id)
        authkey = secrets.token_bytes(32)
        listener = Listener(("127.0.0.1", 0), family="AF_INET", authkey=authkey)
        accepted = []
        error = []

        def accept():
            try:
                accepted.append(listener.accept())
            except Exception as exc:
                error.append(exc)

        thread = threading.Thread(target=accept, daemon=True)
        thread.start()
        host, port = listener.address
        command = [sys.executable, "-u", str(script), "--worker-connect", host,
                   str(port), "--worker-auth", authkey.hex(), "--worker-gpuid", self.gpuid]
        # Inherit CUDA_VISIBLE_DEVICES from SLURM; gpuid indexes that visible set.
        env = os.environ.copy()
        env.setdefault("OMP_NUM_THREADS", "4")
        env.setdefault("MKL_NUM_THREADS", "4")
        print(f"Starting permanent worker: device={self.gpuid}, slot={self.worker_id} ...", flush=True)
        try:
            self.process = subprocess.Popen(command, env=env)
            deadline = time.monotonic() + float(startup_timeout)
            while not accepted:
                if error:
                    raise RuntimeError(f"Worker connection failed: {error[0]}")
                if self.process.poll() is not None:
                    raise RuntimeError(f"Worker on {self.gpuid}, slot={self.worker_id} exited with code {self.process.returncode}")
                if time.monotonic() >= deadline:
                    raise TimeoutError(f"Worker initialization exceeded {startup_timeout}s on {self.gpuid}")
                thread.join(0.1)
            self.connection = accepted[0]
            while not self.connection.poll(0.1):
                if self.process.poll() is not None or time.monotonic() >= deadline:
                    raise RuntimeError(f"Worker on {self.gpuid}, slot={self.worker_id} did not become ready")
            ready = self.connection.recv()
            if not ready.get("ok") or ready.get("event") != "ready":
                raise RuntimeError(f"Invalid worker greeting: {ready}")
            print(f"Permanent worker ready: device={self.gpuid}, slot={self.worker_id}, pid={ready.get('pid')}", flush=True)
        except BaseException:
            self.close()
            raise
        finally:
            listener.close()

    def request(self, command, **payload):
        with self.lock:
            if self.process.poll() is not None:
                raise RuntimeError(f"Worker on {self.gpuid}, slot={self.worker_id} exited with code {self.process.returncode}")
            self.connection.send({"command": command, "cwd": os.getcwd(), **payload})
            while not self.connection.poll(0.5):
                if self.process.poll() is not None:
                    raise RuntimeError(f"Worker on {self.gpuid}, slot={self.worker_id} died during {command}")
            try:
                response = self.connection.recv()
            except EOFError as exc:
                raise RuntimeError(f"Worker on {self.gpuid}, slot={self.worker_id} disconnected during {command}") from exc
            if not response.get("ok"):
                raise RuntimeError(f"Worker {self.gpuid}, slot={self.worker_id}: {response.get('error')}\n{response.get('traceback', '')}")
            return response.get("result")

    def close(self):
        # Cleanup also works after partially completed initialization.
        if self.connection is not None:
            try:
                if self.process is not None and self.process.poll() is None:
                    self.connection.send({"command": "shutdown"})
            except (OSError, EOFError):
                pass
        if self.process is not None:
            try:
                self.process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                self.process.terminate()
                try:
                    self.process.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    self.process.kill()
                    self.process.wait()
        if self.connection is not None:
            self.connection.close()


def get_worker(gpuid, script=None, startup_timeout=900):
    script = resolve_script(script)
    gpuid, worker_id = normalize_slot(gpuid)
    key = (str(script), gpuid, worker_id)
    with _registry_lock:
        if key not in _workers:
            _workers[key] = PermanentWorker(script, gpuid, startup_timeout, worker_id=worker_id)
        return _workers[key]


def prepare_workers(args):
    slots = configured_worker_slots(args)
    if getattr(args, "doSplitDiffGpu", False) and int(args.SplitParticles) > 1:
        groups = [f"{base}: {candidate_shard_slots(args, base, slots)[:int(args.SplitParticles)]}"
                  for base in worker_slots(args.gpuid)]
        print(f"Particle split mode={split_gpu_mode(args)}; candidate groups: " + "; ".join(groups), flush=True)
    try:
        for slot in slots:
            get_worker(slot, getattr(args, "search_script", None), getattr(args, "worker_startup_timeout", 900))
    except BaseException:
        shutdown_workers()
        raise
    return slots


def shutdown_workers(args=None):
    with _registry_lock:
        workers = list(_workers.values())
        _workers.clear()
    for worker in workers:
        worker.close()


atexit.register(shutdown_workers)
